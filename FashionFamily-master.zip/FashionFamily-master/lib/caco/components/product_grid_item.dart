import 'package:flutter/material.dart';
import 'package:fashion/caco/constants.dart';
import 'package:fashion/caco/home/components/home_featured_list_item.dart';
import 'package:fashion/caco/size_config.dart';
import 'package:fashion/models/entities/product.dart';
import 'package:fashion/common/constants/route_list.dart';
import 'package:fashion/common/constants/general.dart';
import 'package:fashion/models/index.dart'
    show AppModel, RecentModel, CartModel, Product;
import 'package:provider/provider.dart';

class ProductGridItem extends StatelessWidget {
  final Product product;

  const ProductGridItem({
    Key key,
    this.product,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        if (product.imageFeature == '') return;
        Provider.of<RecentModel>(context, listen: false)
            .addRecentProduct(product);
        //Load update product detail screen for FluxBuilder
        eventBus.fire('detail');
        Navigator.of(
          context,
          // rootNavigator: !isBigScreen(context), // Push in tab for tablet (IPad)
        ).pushNamed(
          RouteList.productDetail,
          arguments: product,
        );
      },
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: getProportionateScreenWidth(8),
          vertical: getProportionateScreenHeight(6),
        ),
        child: Card(
          elevation: 5,
          shadowColor: kCardBackgroundColor,
          margin: EdgeInsets.all(0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                height: 135,
                clipBehavior: Clip.antiAliasWithSaveLayer,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Stack(
                  children: [
                    Image.asset(
                      product.images[0],
                      fit: BoxFit.cover,
                      width: double.infinity,
                      height: double.infinity,
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 5, left: 5, right: 5),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        product.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 17,
                        ),
                      ),
                      SizedBox(height: getProportionateScreenHeight(6)),
                      Row(
                        children: [
                          Text(
                            '\ج.م${product.price}',
                            style: TextStyle(
                              fontSize: 15,
                              color: kSecondaryColor,
                            ),
                          ),
                          product.salePrice != 0.0
                              ? SizedBox(
                                  width: getProportionateScreenWidth(8),
                                )
                              : Container(),
                          product.salePrice != 0.0
                              ? Text(
                                  '\$${product.salePrice}',
                                  style: TextStyle(
                                    fontSize: 15,
                                    color: Colors.grey,
                                    decoration: TextDecoration.lineThrough,
                                  ),
                                )
                              : Container(),
                          Spacer(),
                          Expanded(
                            child: GestureDetector(
                              onTap: () => null,
                              child: Icon(
                                Icons.add_shopping_cart,
                                color: kPrimaryColor,
                                size: 21,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

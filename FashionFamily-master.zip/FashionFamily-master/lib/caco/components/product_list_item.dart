import 'package:flutter/material.dart';
import 'package:fashion/caco/constants.dart';
import 'package:fashion/caco/size_config.dart';
import 'package:fashion/models/entities/product.dart';
import 'package:provider/src/provider.dart';
import 'package:fashion/common/constants/route_list.dart';
import 'package:fashion/common/constants/general.dart';
import 'package:fashion/common/tools.dart';
import 'package:flutter_widget_from_html/src/html_widget.dart';
import 'package:fashion/widgets/product/heart_button.dart';
import 'package:fashion/screens/detail/review.dart';
import 'package:fashion/screens/detail/product_variant.dart';
import 'package:fashion/screens/detail/product_title.dart';
import 'package:fashion/widgets/common/start_rating.dart';
import 'package:fashion/screens/detail/product_description.dart';
import 'package:fashion/models/index.dart'
    show AppModel, RecentModel, CartModel, Product;

class ProductListItem extends StatelessWidget {
  final Product product;
  final Function removeFunction;

  const ProductListItem({
    Key key,
    this.product,
    this.removeFunction,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final String currency = Provider.of<AppModel>(context).currency;
    final Map<String, dynamic> currencyRate =
        Provider.of<AppModel>(context).currencyRate;
    return InkWell(
      onTap: () {
        if (product.imageFeature == '') return;
        Provider.of<RecentModel>(context, listen: false)
            .addRecentProduct(product);
        Navigator.of(
          context,
          rootNavigator: true,
          // rootNavigator: !isBigScreen(context),
          // Push in tab for tablet (IPad)
        ).pushNamed(
          RouteList.productDetail,
          arguments: product,
        );
        // _showSheet(context, product);
      },
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3), // changes position of shadow
              ),
            ],
            borderRadius: BorderRadius.circular(10)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              height: 150,
              width: 100,
              margin: EdgeInsets.symmetric(horizontal: 5, vertical: 5),
              child: Padding(
                padding: const EdgeInsets.all(2.0),
                child: ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: Image.network(
                      product.imageFeature,
                      fit: BoxFit.cover,
                      width: double.infinity,
                      height: double.infinity,
                    )),
              ),
            ),
            Expanded(
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            product.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.start,
                            style: const TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                          ),
                        ),
                        HeartButton(
                          product: product,
                          size: 18.0,
                        ),
                      ],
                    ),
                    // const SizedBox(
                    //   height: 5,
                    // ),
                    // Column(
                    //   crossAxisAlignment: CrossAxisAlignment.start,
                    //   mainAxisAlignment: MainAxisAlignment.start,
                    //   children: [
                    //     HtmlWidget(
                    //       product.description
                    //           .replaceAll('src="//', 'src="https://'),
                    //       webView: false,
                    //       textStyle: TextStyle(
                    //         fontSize: 13,
                    //       ),
                    //     ),
                    //   ],
                    // ),
                    const SizedBox(
                      height: 5,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          product.price + " جنية ",
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.w600,
                            fontSize: 15,
                          ),
                        ),
                        Directionality(
                          textDirection: TextDirection.rtl,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                product.averageRating.toString(),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w300,
                                  fontSize: 11,
                                ),
                              ),
                              SmoothStarRating(
                                  label: const Text(''),
                                  allowHalfRating: true,
                                  starCount: 5,
                                  rating: product.averageRating,
                                  size: 12.0,
                                  color: Colors.amber,
                                  borderColor: Colors.amber,
                                  spacing: 0.0),
                            ],
                          ),
                        ),
                      ],
                    )
                    // HtmlWidget(
                    //     value.productsList[index].description.replaceAll('src="//', 'src="https://'),
                    //     webView: false,
                    //
                    //
                    //
                    //     textStyle: TextStyle(fontSize: 13,),
                    //     )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showSheet(context, product) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20), topRight: Radius.circular(20)),
      ),
      builder: (context) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: .7,
          maxChildSize: .9,
          builder: (context, controller) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Container(
                //   height: 100,
                //   width: 100,
                //   margin: EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                //   child: Padding(
                //     padding: const EdgeInsets.all(2.0),
                //     child: ClipRRect(
                //         borderRadius: BorderRadius.circular(6),
                //         child: Image.network(
                //           product.imageFeature,
                //           fit: BoxFit.cover,
                //           width: double.infinity,
                //           height: double.infinity,
                //         )),
                //   ),
                // ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    width: 90,
                    height: 10,
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [],
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Expanded(
                  child: Center(
                    child: ListView(
                      controller: controller,
                      physics: BouncingScrollPhysics(),
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: ProductTitle(product),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 20),
                              child: ProductDescription(product),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 20),
                              child: ProductVariant(product),
                            ),
                            Reviews(product.id),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}

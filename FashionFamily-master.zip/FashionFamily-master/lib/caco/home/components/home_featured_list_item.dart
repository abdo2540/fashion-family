import 'package:flutter/material.dart';
import 'package:fashion/caco/constants.dart';
import 'package:fashion/caco/size_config.dart';
import 'package:fashion/models/entities/product.dart';
import 'package:fashion/common/tools.dart';
import 'package:fashion/common/constants/route_list.dart';
import 'package:fashion/common/constants/general.dart';
import 'package:fashion/models/index.dart'
    show AppModel, CartModel, Product, ProductModel, RecentModel;
import 'package:provider/provider.dart';
import 'package:fashion/widgets/product/heart_button.dart';
import 'package:shimmer/shimmer.dart';

class HomeFeaturedListItem extends StatefulWidget {
  final Product product;

  const HomeFeaturedListItem({
    Key key,
    this.product,
  }) : super(key: key);

  @override
  _HomeFeaturedListItemState createState() => _HomeFeaturedListItemState();
}

class _HomeFeaturedListItemState extends State<HomeFeaturedListItem> {
  bool isFavorite = false;
  int sale = 0;
  @override
  Widget build(BuildContext context) {
    // print(widget.product.regularPrice);
    if (widget.product.regularPrice.isNotEmpty &&
        double.parse(widget.product.regularPrice) > 0)
      sale = (100 -
              (double.parse(widget.product.price) /
                      double.parse(widget.product.regularPrice)) *
                  100)
          .toInt();
    final String currency = Provider.of<AppModel>(context).currency;
    final Map<String, dynamic> currencyRate =
        Provider.of<AppModel>(context).currencyRate;
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10),
      child: InkWell(
        onTap: () {
          Navigator.of(
            context,
            rootNavigator: true,
            // rootNavigator: !isBigScreen(context),
            // Push in tab for tablet (IPad)
          ).pushNamed(
            RouteList.productDetail,
            arguments: widget.product,
          );
        },
        child: SizedBox(
          width: getProportionateScreenWidth(110),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.max,
            children: [
              AspectRatio(
                aspectRatio: 1 / 1.2,
                child: Card(
                  clipBehavior: Clip.antiAliasWithSaveLayer,
                  margin: EdgeInsets.symmetric(horizontal: 0, vertical: 10),
                  elevation: 0,
                  shadowColor: kCardBackgroundColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Stack(
                    children: [
                      GestureDetector(
                        onTap: () {
                          if (widget.product.imageFeature == '') return;
                          Provider.of<RecentModel>(context, listen: false)
                              .addRecentProduct(widget.product);
                          //Load update product detail screen for FluxBuilder
                          eventBus.fire('detail');
                          Navigator.of(
                            context,
                            // rootNavigator: !isBigScreen(context), // Push in tab for tablet (IPad)
                          ).pushNamed(
                            RouteList.productDetail,
                            arguments: widget.product,
                          );
                        },
                        child: Stack(
                          children: [
                            Image.network(
                              widget.product.imageFeature,
                              fit: BoxFit.cover,
                              width: double.infinity,
                              height: double.infinity,
                            ),
                            (widget.product.regularPrice != "")
                                ? Positioned(
                                    top: 10,
                                    right: 5,
                                    child: Shimmer.fromColors(
                                      baseColor: Colors.red,
                                      highlightColor: Colors.white,
                                      period: Duration(milliseconds: 500),
                                      child: Center(
                                        child: Text(
                                          "خصم $sale% ",
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 11.5,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ),
                                    //  Container(
                                    //   width: 50,
                                    //   height: 25,
                                    //   decoration: BoxDecoration(
                                    //     color: Colors.white,
                                    //     border: Border.all(color: Colors.black),
                                    //     borderRadius: BorderRadius.circular(5
                                    //         // Radius.circular(10),
                                    //         // bottomRight: Radius.circular(10),
                                    //         ),
                                    //   ),
                                    //   child:
                                    // ),
                                  )
                                : SizedBox()
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 5),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 0),
                child: Text(
                  widget.product.name,
                  // softWrap: true,
                  textAlign: TextAlign.start,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    // color: Colors.black.withOpacity(0.7),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 5),
                child: Row(
                  children: [
                    // Text(
                    //   // widget.product.type != 'grouped'
                    //   //     ?
                    //   Tools.getCurrencyFormatted(
                    //       product
                    //               .futcherProduct[
                    //                   index]
                    //               .price ??
                    //           "0.0",
                    //       currencyRate,
                    //       currency:
                    //           currency),
                    //   //     :
                    //   // Provider.of<ProductModel>(context).detailPriceRange,
                    //   style: Theme.of(
                    //           context)
                    //       .textTheme
                    //       .subtitle1
                    //       .copyWith(
                    //         fontSize:
                    //             13,
                    //         fontWeight:
                    //             FontWeight
                    //                 .w600,
                    //         color: Colors
                    //             .red,
                    //       ),
                    // ),
                    Text(
                      '${widget.product.price} ',
                      style: TextStyle(
                        fontSize: getProportionateScreenWidth(16),
                        fontWeight: FontWeight.w600,
                        color: Color(0xff2CB9B0),
                      ),
                    ),
                    Text(
                      "ج.م",
                      style: TextStyle(
                        fontSize: getProportionateScreenWidth(13),
                        fontWeight: FontWeight.w600,
                        color: Color(0xff2CB9B0),
                      ),
                    )

                    // (widget.product.salePrice != 0)
                    //     ? Text(
                    //         '\$${widget.product.salePrice}',
                    //         style: TextStyle(
                    //             fontSize: 14.5,
                    //             color: Colors.grey,
                    //             decoration: TextDecoration.lineThrough),
                    //       )
                    //
                  ],
                ),
              ),
              SizedBox(width: 3),
              (widget.product.regularPrice != "")
                  ? Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 5),
                      child: Text(
                        "${widget.product.regularPrice}\ج.م",
                        style: Theme.of(context).textTheme.subtitle1.copyWith(
                              fontSize: 11.5,
                              color: Theme.of(context)
                                  .accentColor
                                  .withOpacity(0.6),
                              fontWeight: FontWeight.w400,
                              decoration: TextDecoration.lineThrough,
                            ),
                      ),
                    )
                  : Container()
            ],
          ),
        ),
      ),
    );
  }
}

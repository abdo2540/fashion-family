import 'package:flutter/material.dart';
import 'package:fashion/models/entities/product.dart';
import 'package:path/path.dart' as path;
import 'package:fashion/services/index.dart';

class GetProduct extends ChangeNotifier {
  final Services _service = Services();
  List<List<Product>> products;
  String message;
var price ="0.0";
updatePrice({nPrice}){
  price=nPrice;
}
  /// current select product id/name
  String categoryId;
  String categoryName;
  int tagId;

//list products for products screen
  bool isFetching = false;
  bool loading = false;
  List<Product> futcherProduct;
  List<Product> futureProduct;

  String errMsg;
  bool isEnd;

  bool isProductVariationLoading = true;
// ProductVariation productVariation;
  List<Product> lstGroupedProduct;
  String cardPriceRange;
  String detailPriceRange = '';
  Future<void> getProductsList({
    categoryId,
    minPrice,
    maxPrice,
    orderBy,
    order,
    String tagId,
    lang,
    page,
    featured,
    onSale,
    attribute,
    attributeTerm,
  }) async {
    try {
      if (categoryId != null) {
        this.categoryId = categoryId;
      }
      if (tagId != null && tagId.isNotEmpty) {
        this.tagId = int.parse(tagId);
      }
      isFetching = true;
      isEnd = false;
      loading = true;
      // notifyListeners();

      final products = await _service.fetchProductsByCategory(
        categoryId: categoryId,
        tagId: tagId,
        minPrice: minPrice,
        maxPrice: maxPrice,
        orderBy: orderBy,
        order: order,
        lang: lang,
        page: page,
        featured: featured,
        onSale: onSale,
        attribute: attribute,
        attributeTerm: attributeTerm,
      );

      if (page == 0 || page == 1) {
        futcherProduct = products;
      } else {
        futcherProduct = [...futcherProduct, ...products];
      }
      loading = false;

      isFetching = false;
      errMsg = null;
      notifyListeners();
    } catch (err, _) {
      errMsg =
          "There is an issue with the app during request the data, please contact admin for fixing the issues " +
              err.toString();
      isFetching = false;
      notifyListeners();
    }
  }
}

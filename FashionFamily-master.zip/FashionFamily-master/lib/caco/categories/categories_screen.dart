import 'package:flutter/material.dart';
import 'package:fashion/caco/size_config.dart';

import 'components/body.dart';

class CategoriesScreen extends StatefulWidget {
  static String routeName = "/categories";

  @override
  _CategoriesScreenState createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      // resizeToAvoidBottomPadding: false,
      appBar: AppBar(
        title: const Text('Categories'),
        centerTitle: true,
        automaticallyImplyLeading: false,
      ),
      body: Body(),
    );
  }
}

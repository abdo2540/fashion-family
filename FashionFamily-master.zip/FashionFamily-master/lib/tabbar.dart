import 'dart:async';

import 'package:fashion/screens/settings/settings.dart';
import 'package:fashion/screens/users/user_update.dart';
import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:floating_bottom_navigation_bar/floating_bottom_navigation_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'common/config.dart';
import 'common/constants.dart';
import 'common/tools.dart';
import 'generated/l10n.dart';
import 'menu.dart';
import 'models/app_model.dart';
import 'models/cart/cart_model.dart';
import 'models/search_model.dart';
import 'route.dart';
import 'screens/base.dart';
import 'screens/index.dart'
    show
        CartScreen,
        PostScreen,
        CategoriesScreen,
        WishListScreen,
        HomeScreen,
        NotificationScreen,
        StaticSite,
        UserScreen,
        WebViewScreen;
import 'screens/pages/index.dart';
import 'services/index.dart';
import 'widgets/blog/slider_list.dart';
import 'widgets/common/auto_hide_keyboard.dart';
import 'widgets/icons/feather.dart';
import 'widgets/layout/adaptive.dart';
import 'widgets/layout/main_layout.dart';
import 'package:fashion/screens/cart/my_cart.dart';
import 'package:google_fonts/google_fonts.dart';

const int tabCount = 3;
const int turnsToRotateRight = 1;
const int turnsToRotateLeft = 3;

class MainTabControlDelegate {
  int index;
  Function(String nameTab) changeTab;
  Function(int index) tabAnimateTo;

  static MainTabControlDelegate _instance;

  static MainTabControlDelegate getInstance() {
    return _instance ??= MainTabControlDelegate._();
  }

  MainTabControlDelegate._();
}

class MainTabs extends StatefulWidget {

  List<Widget> Screens = [
    HomeScreen(),
    CategoriesScreen(),
    CartScreen(),
    WishListScreen(),
    UserScreen(),

  ];
  MainTabs({Key key}) : super(key: key);

  @override
  MainTabsState createState() => MainTabsState();
}

class MainTabsState extends BaseScreen<MainTabs>
    with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  final _auth = FirebaseAuth.instance;
  final GlobalKey<ScaffoldState> _scaffoldKey =
      GlobalKey(debugLabel: 'Dashboard');
  final List<Widget> _tabView = [];
  final navigators = Map<int, GlobalKey<NavigatorState>>();

  var tabData;

  Map saveIndexTab = Map();

  firebase_auth.User loggedInUser;

  TabController tabController;

  bool isAdmin = false;
  bool isFirstLoad = false;
  bool isShowCustomDrawer = false;

  StreamSubscription _subOpenNativeDrawer;
  StreamSubscription _subCloseNativeDrawer;
  StreamSubscription _subOpenCustomDrawer;
  StreamSubscription _subCloseCustomDrawer;

  bool get isDesktopDisplay => isDisplayDesktop(context);
  int index = 0;


  @override
  void afterFirstLayout(BuildContext context) {
    loadTabBar(context);
  }

  Widget tabView(Map<String, dynamic> data) {
    switch (data['layout']) {
      case 'search':
        return CategoriesScreen();
      // case 'search':
      //   {
      //     return AutoHideKeyboard(
      //       child: ChangeNotifierProvider<SearchModel>(
      //         create: (context) => SearchModel(),
      //         child: Services().widget.renderSearchScreen(
      //               context,
      //               showChat: data['showChat'],
      //             ),
      //       ),
      //     );
      //   }

      case 'cart':
        return MyCart();
      case 'profile':
        return UserScreen(
            settings: data['settings'],
            background: data['background'],
            showChat: data['showChat']);

      case 'wishlist':
        return WishListScreen(canPop: false, showChat: data['showChat']);

      default:
        return const HomeScreen();
    }
  }

  void changeTab(String nameTab) {
    if (saveIndexTab[nameTab] != null) {
      tabController?.animateTo(saveIndexTab[nameTab]);
    } else {
      Navigator.of(context, rootNavigator: true).pushNamed("/$nameTab");
    }
  }

  void loadTabBar(context) {
    tabData = List.from(
        Provider.of<AppModel>(context, listen: false).appConfig['TabBar']);

    for (var i = 0; i < tabData.length; i++) {
      Map<String, dynamic> _dataOfTab = Map.from(tabData[i]);
      saveIndexTab[_dataOfTab['layout']] = i;
      navigators[i] = GlobalKey<NavigatorState>();
      _tabView.add(Navigator(
        key: navigators[i],
        onGenerateRoute: (RouteSettings settings) {
          if (settings.name == Navigator.defaultRouteName) {
            return MaterialPageRoute(
              builder: (context) => tabView(_dataOfTab),
              fullscreenDialog: true,
              settings: settings,
            );
          }
          return Routes.getRouteGenerate(settings);
        },
      ));
    }

    setState(() {
      tabController = TabController(length: _tabView.length, vsync: this);
    });

    if (MainTabControlDelegate.getInstance().index != null) {
      tabController.animateTo(MainTabControlDelegate.getInstance().index);
    } else {
      MainTabControlDelegate.getInstance().index = 0;
    }

    // Load the Design from FluxBuilder
    tabController.addListener(() {
      eventBus.fire('tab_${tabController.index}');
      MainTabControlDelegate.getInstance().index = tabController.index;
    });
  }

  Future<void> getCurrentUser() async {
    try {
      //Provider.of<UserModel>(context).getUser();
      final user = await _auth.currentUser;
      if (user != null) {
        setState(() {
          loggedInUser = user;
        });
      }
    } catch (e) {
      printLog("[tabbar] getCurrentUser error ${e.toString()}");
    }
  }

  bool checkIsAdmin() {
    if (loggedInUser.email == adminEmail) {
      isAdmin = true;
    } else {
      isAdmin = false;
    }
    return isAdmin;
  }

  @override
  void initState() {
    printLog("[Dashboard] init");
    if (!kIsWeb) {
      getCurrentUser();
    }
    setupListenEvent();
    MainTabControlDelegate.getInstance().changeTab = changeTab;
    MainTabControlDelegate.getInstance().tabAnimateTo = (int index) {
      tabController?.animateTo(index);
    };
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeDependencies() {
    isShowCustomDrawer = isDesktopDisplay;
    super.didChangeDependencies();
  }

  @override
  void dispose() {
    tabController?.dispose();
    WidgetsBinding.instance.removeObserver(this);
    _subOpenNativeDrawer?.cancel();
    _subCloseNativeDrawer?.cancel();
    _subOpenCustomDrawer?.cancel();
    _subCloseCustomDrawer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      // went to Background
    }
    if (state == AppLifecycleState.resumed) {
      // came back to Foreground
      final appModel = Provider.of<AppModel>(context, listen: false);
      if (appModel.deeplink?.isNotEmpty ?? false) {
        if (appModel.deeplink['screen'] == 'NotificationScreen') {
          appModel.deeplink = null;
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => NotificationScreen()),
          );
        }
      }
    }

    super.didChangeAppLifecycleState(state);
  }

  void setupListenEvent() {
    _subOpenNativeDrawer = eventBus.on<EventOpenNativeDrawer>().listen((event) {
      if (!_scaffoldKey.currentState.isDrawerOpen) {
        _scaffoldKey.currentState.openDrawer();
      }
    });
    _subCloseNativeDrawer =
        eventBus.on<EventCloseNativeDrawer>().listen((event) {
      if (_scaffoldKey.currentState.isDrawerOpen) {
        _scaffoldKey.currentState.openEndDrawer();
      }
    });
    _subOpenCustomDrawer = eventBus.on<EventOpenCustomDrawer>().listen((event) {
      setState(() {
        isShowCustomDrawer = true;
      });
    });
    _subCloseCustomDrawer =
        eventBus.on<EventCloseCustomDrawer>().listen((event) {
      setState(() {
        isShowCustomDrawer = false;
      });
    });
  }

  Future<bool> handleWillPopScopeRoot() {
    // Check pop navigator current tab
    final currentNavigator = navigators[tabController.index];
    if (currentNavigator.currentState.canPop()) {
      currentNavigator.currentState.pop();
      return Future.value(false);
    }
    // Check pop root navigator
    if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
      return Future.value(false);
    }
    if (tabController.index != 0) {
      tabController.animateTo(0);
      return Future.value(false);
    } else {
      return showDialog(
            context: context,
            builder: (context) => AlertDialog(
              content: Text(
                S.of(context).areYouSure,
                style: TextStyle(fontSize: 13),
              ),
              title: Text(
                S.of(context).doYouWantToExitApp + "؟",
                style: TextStyle(fontSize: 13),
              ),
              actions: <Widget>[
                FlatButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: Text(
                    S.of(context).no,
                    style: TextStyle(
                        color: Theme.of(context).primaryColor, fontSize: 13),
                  ),
                ),
                FlatButton(
                  onPressed: () => Navigator.of(context).pop(true),
                  child: Text(
                    S.of(context).yes,
                    style: TextStyle(color: Colors.red, fontSize: 13),
                  ),
                ),
              ],
            ),
          ) ??
          false;
    }
  }

  @override
  Widget build(BuildContext context) {
    printLog(
        '[Resolution Screen]: ${MediaQuery.of(context).size.width} x ${MediaQuery.of(context).size.height}');
    Utils.setStatusBarWhiteForeground(false);

    if (_tabView.isEmpty) {
      return Container(
        color: Colors.white,
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 0),
      child: Container(height: 25, child: renderBody(context)),
    );
  }

  Widget renderBody(BuildContext context) {
    var totalCart = Provider.of<CartModel>(context).totalCartQuantity;
    final screenSize = MediaQuery.of(context).size;
    final appSetting = Provider.of<AppModel>(context).appConfig['Setting'];
    final colorTabbar = appSetting['ColorTabbar'] != null
        ? HexColor(appSetting['ColorTabbar'])
        : false;

    final tabBar = TabBar(
      controller: tabController,
      onTap: (index) {
        setState(() {});
      },
      tabs: [
        Container(
          height: 50,
          width: 50,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              ImageIcon(
                AssetImage("assets/fashion/icons8-coffee-beans-100.png"),
              ),
              Text(
                "الرئيسية",
                style: GoogleFonts.tajawal(fontSize: 10),
              )
            ],
          ),
        ),
        // Container(
        //   height: 50,
        //   child: ImageIcon(
        //     AssetImage("assets/fashion/Grid View.png"),
        //   ),
        // ),
        Container(
          height: 50,
          width: 50,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              ImageIcon(
                AssetImage("assets/fashion/icons8-search-120.png"),
                // color: Colors.black,
              ),
              Text(
                "بحث",
                style: GoogleFonts.tajawal(fontSize: 10),
              )
            ],
          ),
        ),
        Container(
          height: 50,
          width: 50,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Stack(
                children: <Widget>[
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: 30,
                        height: 25,
                        padding: const EdgeInsets.only(right: 0.0, top: 4),
                        child: Center(
                          child: ImageIcon(
                            AssetImage(
                                "assets/fashion/icons8-shopping-cart-256.png"),
                          ),
                        ),
                      ),
                      Text(
                        "السلة",
                        style: GoogleFonts.tajawal(fontSize: 10),
                      ),
                    ],
                  ),
                  if (totalCart > 0)
                    Positioned(
                      right: 0,
                      top: 0,
                      child: Container(
                        padding: const EdgeInsets.all(1),
                        decoration: BoxDecoration(
                          color: Color(0xff4f3933).withOpacity(.9),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 16,
                          minHeight: 16,
                        ),
                        child: Text(
                          totalCart.toString(),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                ],
              ),
            ],
          ),
        ),
        Container(
          height: 50,
          width: 50,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              ImageIcon(
                AssetImage("assets/fashion/icons8-settings-144 (1).png"),
              ),
              Text(
                "الاعدادات",
                style: GoogleFonts.tajawal(fontSize: 10),
              ),
            ],
          ),
        ),
      ],
      isScrollable: false,
      labelColor: colorTabbar == true ? Color(0xff4f3933) : Colors.white,
      indicatorWeight: .1,
      indicatorSize: TabBarIndicatorSize.label,
      indicator: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: colorTabbar == false ? Color(0xff4f3933) : Colors.white,
      ),
      indicatorPadding: const EdgeInsets.all(10.0),
      indicatorColor: colorTabbar == true ? Color(0xff4f3933) : Colors.white,
    );

    // TabBarView
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Theme.of(context).backgroundColor,
      // resizeToAvoidBottomPadding: false,
      body: widget.Screens[index],
      // drawer: isDesktopDisplay ? null : Drawer(child: MenuBar()),
      // bottomNavigationBar: Container(
      //   color: Colors.white,
      //   child: Container(
      //     decoration: BoxDecoration(
      //       color: colorTabbar == false
      //           ? Theme.of(context).backgroundColor
      //           : colorTabbar, // added
      //       // border: Border.all(color: Colors.grey, width: 5), // added
      //       borderRadius: BorderRadius.circular(25.0),
      //     ),
      //     child: SafeArea(
      //       top: false,
      //       child: AnimatedContainer(
      //           duration: const Duration(milliseconds: 600),
      //           curve: Curves.easeIn,
      //           height: isShowCustomDrawer ? 0 : null,
      //           constraints: const BoxConstraints(
      //             maxHeight: 80,
      //           ),
      //           decoration: BoxDecoration(
      //             color: Colors.white,
      //             // border: Border(
      //             //   top: BorderSide(color: Colors.red, width: 0.5),
      //             // ),
      //           ),
      //           width: screenSize.width,
      //           child: SizedBox(
      //             // height: 10,
      //             child: tabBar,
      //             width: MediaQuery.of(context).size.width,
      //           )),
      //     ),
      //   ),
      // ),
      extendBody: true,
      bottomNavigationBar: FloatingNavbar(
        selectedItemColor: Color(0xfff35819),
        borderRadius: 20,
        backgroundColor: Theme.of(context).primaryColor,
        fontSize: 10,
        onTap: (int val) => setState(() => index = val),
        currentIndex: index,
        items: [
          FloatingNavbarItem(icon: Icons.home_rounded, title: S.of(context).home),
          FloatingNavbarItem(icon: Icons.menu_rounded, title: S.of(context).categories),
          FloatingNavbarItem(icon: Icons.shopping_cart_rounded, title: S.of(context).cart),
          FloatingNavbarItem(icon: Icons.favorite_outline_rounded, title: S.of(context).myWishList),
          FloatingNavbarItem(icon: Icons.settings_outlined, title: S.of(context).settings),
        ],
      ),
    );
  }

  Widget _bottomNavigationBar(BuildContext context) {
    return BottomNavigationBar(
      // onTap: _selectPage,
      elevation: 0,
      iconSize: 25,
      backgroundColor: Colors.grey,
      // currentIndex: controller.index,
      showSelectedLabels: false,
      showUnselectedLabels: false,
      type: BottomNavigationBarType.fixed,
      items: [
        BottomNavigationBarItem(
          icon: ImageIcon(
            AssetImage("assets/icons/Shop.png"),
          ),
          activeIcon: ImageIcon(
            AssetImage("assets/icons/Shop.png"),
          ),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: ImageIcon(
            AssetImage("assets/icons/Grid View.png"),
          ),
          activeIcon: ImageIcon(
            AssetImage("assets/icons/Grid View.png"),
          ),
          label: 'Categories',
        ),
        BottomNavigationBarItem(
          icon: ImageIcon(
            AssetImage("assets/icons/Search.png"),
          ),
          activeIcon: ImageIcon(
            AssetImage("assets/icons/Search.png"),
          ),
          label: 'Search',
        ),
        BottomNavigationBarItem(
          icon: ImageIcon(
            AssetImage("assets/icons/Love.png"),
          ),
          activeIcon: ImageIcon(
            AssetImage("assets/icons/Love.png"),
          ),
          label: 'WishList',
        ),
        BottomNavigationBarItem(
          icon: ImageIcon(
            AssetImage("assets/icons/User.png"),
          ),
          activeIcon: ImageIcon(
            AssetImage("assets/icons/User.png"),
          ),
          label: 'Profile',
        ),
      ],
    );
  }

  List<Widget> renderTabbar() {
    final isTablet = Tools.isTablet(MediaQuery.of(context));
    var totalCart = Provider.of<CartModel>(context).totalCartQuantity;
    final tabData = Provider.of<AppModel>(context, listen: false)
        .appConfig['TabBar'] as List;

    final appSetting = Provider.of<AppModel>(context).appConfig['Setting'];
    final colorIcon = appSetting['TabBarIconColor'] != null
        ? HexColor(appSetting['TabBarIconColor'])
        : Theme.of(context).accentColor;

    final activeColorIcon = appSetting['ActiveTabBarIconColor'] != null
        ? HexColor(appSetting['ActiveTabBarIconColor'])
        : Theme.of(context).primaryColor;

    List<Widget> list = [];

    int index = 0;

    tabData.forEach((item) {
      final isActive = tabController.index == index;
      var icon = !item["icon"].contains('/')
          ? Icon(
              featherIcons[item["icon"]],
              color: isActive ? activeColorIcon : colorIcon,
              size: 22,
            )
          : (item["icon"].contains('http')
              ? Image.network(
                  item["icon"],
                  color: isActive ? activeColorIcon : colorIcon,
                  width: 24,
                )
              : Image.asset(
                  item["icon"],
                  color: isActive ? activeColorIcon : colorIcon,
                  width: 24,
                ));

      if (item["layout"] == "cart") {
        icon = Stack(
          children: <Widget>[
            Container(
              width: 30,
              height: 25,
              padding: const EdgeInsets.only(right: 6.0, top: 4),
              child: icon,
            ),
            if (totalCart > 0)
              Positioned(
                right: 0,
                top: 0,
                child: Container(
                  padding: const EdgeInsets.all(1),
                  decoration: BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  constraints: const BoxConstraints(
                    minWidth: 16,
                    minHeight: 16,
                  ),
                  child: Text(
                    totalCart.toString(),
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: isTablet ? 14 : 12,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              )
          ],
        );
      }

      if (item["label"] != null) {
        list.add(Tab(
          icon: icon,
          iconMargin: EdgeInsets.zero,
          text: item["label"],
        ));
      } else {
        list.add(Tab(icon: icon));
      }
      index++;
    });

    return list;
  }
}

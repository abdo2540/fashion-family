import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../common/constants/general.dart';
import '../../../models/blog_model.dart';
import '../../../screens/blogs/blogs.dart';
import '../../../widgets/blog/blog_view.dart';
import '../../../widgets/home/header/header_view.dart';

class BlogListItems extends StatefulWidget {
  final config;

  BlogListItems({this.config, Key key}) : super(key: key);

  @override
  _BlogListItemsState createState() => _BlogListItemsState();
}

class _BlogListItemsState extends State<BlogListItems> {
  Widget _buildHeader(context, blogs) {
    if (widget.config.containsKey("name")) {
      var showSeeAllLink = widget.config['layout'] != "instagram";
      return HeaderView(
        headerText: widget.config["name"] ?? '',
        showSeeAll: showSeeAllLink,
        callback: () => {
          Navigator.push(
            context,
            MaterialPageRoute(
              fullscreenDialog: kIsWeb,
              builder: (context) => BlogScreen(),
            ),
          )
        },
      );
    }
    return Container();
  }

  @override
  Widget build(BuildContext context) {
    var emptyPosts = [Blog.empty(1), Blog.empty(2), Blog.empty(3)];
    var blogs = Provider.of<BlogModel>(context).blogs;

    return LayoutBuilder(
      builder: (context, constraints) {
        if (blogs.isEmpty) {
          return Column(
            children: <Widget>[
              _buildHeader(context, null),
              BlogItemView(posts: emptyPosts, index: 0),
              BlogItemView(posts: emptyPosts, index: 1),
              BlogItemView(posts: emptyPosts, index: 2),
            ],
          );
        }
        return Column(
          children: <Widget>[
            _buildHeader(context, blogs),
            Container(
              constraints: const BoxConstraints(
                maxHeight: 300,
              ),
              width: constraints.maxWidth,
              height: constraints.maxWidth * (kIsWeb ? 0.4 : 0.6),
              color: Theme.of(context).cardColor,
              padding: const EdgeInsets.only(top: 8.0),
              child: PageView(
                children: [
                  for (var i = 0; i < blogs.length; i = i + 3)
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        blogs[i] != null
                            ? BlogItemView(posts: blogs, index: i)
                            : Container(),
                        i + 1 < blogs.length
                            ? BlogItemView(posts: blogs, index: i + 1)
                            : Container(),
                        i + 2 < blogs.length
                            ? BlogItemView(posts: blogs, index: i + 2)
                            : Container(),
                      ],
                    )
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}

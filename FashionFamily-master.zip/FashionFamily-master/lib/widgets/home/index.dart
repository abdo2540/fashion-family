import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../common/constants/route_list.dart';
import '../../common/tools.dart';
import 'dynamic_layout.dart';
import '../../models/index.dart' show AppModel, BlogModel, Category, CategoryModel;

import 'package:provider/provider.dart';
import '../../common/constants.dart';
class HomeLayout extends StatefulWidget {
  final configs;
  final bool isPinAppBar;
  final bool isShowAppbar;

  HomeLayout({
    this.configs,
    this.isPinAppBar = false,
    this.isShowAppbar = true,
    Key key,
  }) : super(key: key);

  @override
  _HomeLayoutState createState() => _HomeLayoutState();
}

class _HomeLayoutState extends State<HomeLayout> {
  List widgetData;

  @override
  void initState() {
    Provider.of<BlogModel>(context, listen: false).blogs;
    /// init config data
    widgetData =
        List<Map<String, dynamic>>.from(widget.configs["HorizonLayout"]) ?? [];
    if (widgetData.isNotEmpty && widget.isShowAppbar) {
      widgetData.removeAt(0);
    }

    /// init single vertical layout
    if (widget.configs["VerticalLayout"] != null) {
      Map verticalData =
          Map<String, dynamic>.from(widget.configs["VerticalLayout"]);
      verticalData['type'] = 'vertical';
      widgetData.add(verticalData);
    }

    /// init multi vertical layout
    if (widget.configs["VerticalLayouts"] != null) {
      List verticalLayouts = widget.configs["VerticalLayouts"];
      for (int i = 0; i < verticalLayouts.length; i++) {
        Map verticalData = verticalLayouts[i];
        verticalData['type'] = 'vertical';
        widgetData.add(verticalData);
      }
      ;
    }

    super.initState();
  }

  @override
  void didUpdateWidget(HomeLayout oldWidget) {
    if (oldWidget.configs != widget.configs) {
      /// init config data
      List data =
          List<Map<String, dynamic>>.from(widget.configs["HorizonLayout"]);
      if (data.isNotEmpty && widget.isShowAppbar) {
        data.removeAt(0);
      }

      /// init vertical layout
      if (widget.configs["VerticalLayout"] != null) {
        Map verticalData =
            Map<String, dynamic>.from(widget.configs["VerticalLayout"]);
        verticalData['type'] = 'vertical';
        data.add(verticalData);
      }
      setState(() {
        widgetData = data;
      });
    }
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {

    final category = Provider.of<CategoryModel>(context);



    List<dynamic> horizonLayout = widget.configs["HorizonLayout"] ?? [];

    Map config = horizonLayout
        .firstWhere((element) => element['layout'] == 'logo', orElse: () => {});

    return Scaffold(
      body: CustomScrollView(
        cacheExtent: 20000.0,
        slivers: [
            buildSliverAppBar(context),
          Container(
            height: 100,
            width: double.infinity,

            child: ListenableProvider.value(
              value: category,
              child: Consumer<CategoryModel>(
                builder: (context, value, child) {
                  if (value.isLoading) {
                    return kLoadingWidget(context);
                  }

                  if (value.categories == null) {
                    return Container(
                      width: double.infinity,
                      height: double.infinity,
                      alignment: Alignment.center,
                      child: Text("S.of(context).dataEmpty"),
                    );
                  }

                  List<Category> categories = value.categories;

                  return ListView.builder(
                      itemCount: categories.length,
                      itemBuilder: (context, index){
                        return Row(children: [Text("${categories[index].name}"


                        )],);
                      }


                  );
                },
              ),
            ),
          ),



          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                var config = widgetData[index];



                return DynamicLayout(config, widget.configs['Setting']);
                  // VerticalLayout(config: config);
                  //
              },
              childCount: widgetData.length,
            ),
          ),
        ],
      ),
    );
  }

  SliverAppBar buildSliverAppBar(BuildContext context) {
    return SliverAppBar(
            pinned: widget.isPinAppBar,
            snap: true,
            floating: true,
            titleSpacing: 0,
            backgroundColor: Colors.white,
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [

              IconButton(
                icon: Icon(
                  Icons.drag_handle,
                  color:  Theme.of(context)
                      .accentColor
                      .withOpacity(0.9),
                  size: 22,
                ),
                onPressed: () {
                  eventBus
                      .fire(const EventOpenNativeDrawer());

                  },
              ),
              Image.asset("name"),
              IconButton(
                icon: Icon(
                  Icons.search,
                  color:  Theme.of(context)
                      .accentColor
                      .withOpacity(0.6),
                  size: 22,
                ),
                onPressed: () {
                  Navigator.of(context)
                      .pushNamed(RouteList.homeSearch);
                },
              ),

            ],)
          );
  }
}

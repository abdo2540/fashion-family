import 'package:flutter/material.dart';

import '../../common/constants/general.dart';
import '../../common/packages.dart' show StoryWidget;
import '../../common/tools.dart';
import '../../services/index.dart';
import 'banner/banner_animate_items.dart';
import 'banner/banner_group_items.dart';
import 'banner/banner_slider_items.dart';
import 'category/category_icon_items.dart';
import 'category/category_image_items.dart';
import 'header/header_search.dart';
import 'header/header_text.dart';
import 'horizontal/blog_list_items.dart';
import 'horizontal/horizontal_list_items.dart';
import 'horizontal/instagram_items.dart';
import 'horizontal/simple_list.dart';
import 'horizontal/video/index.dart';
import 'logo.dart';
import 'product_list_layout.dart';

class DynamicLayout extends StatelessWidget {
  final config;
  final setting;

  DynamicLayout(this.config, this.setting);

  @override
  Widget build(BuildContext context) {
    switch (config["layout"]) {




      // case "category":
      //   return (config['type'] == 'image')
      //       ? CategoryImages(
      //           config: config,
      //           key: config['key'] != null ? Key(config['key']) : null,
      //         )
      //       : CategoryIcons(
      //           config: config,
      //           key: config['key'] != null ? Key(config['key']) : null,
      //         );



      case "bannerImage":
        if (config['isSlider'] == true) {
          return BannerSliderItems(
              config: config,
              key: config['key'] != null ? Key(config['key']) : null);
        }
        return BannerGroupItems(
          config: config,
          key: config['key'] != null ? Key(config['key']) : null,
        );

      case "largeCardHorizontalListItems":
        return LargeCardHorizontalListItems(
          config: config,
          key: config['key'] != null ? Key(config['key']) : null,
        );

      case "simpleVerticalListItems":
        return SimpleVerticalProductList(
          config: config,
          key: config['key'] != null ? Key(config['key']) : null,
        );



      case "blog":
        return BlogListItems(
          config: config,
          key: config['key'] != null ? Key(config['key']) : null,
        );



      case "story":
        return StoryWidget(
          config: config,
          onTapStoryText: (cfg) {
            Utils.onTapNavigateOptions(context: context, config: cfg);
          },
        );
      case "fourColumn":
      case "threeColumn":
      case "twoColumn":
      case "staggered":
      case "recentView":
      case "saleOff":
        return ProductListLayout(
          config: config,
          key: config['key'] != null ? Key(config['key']) : null,
        );

      default:
        return const SizedBox();
    }
  }
}

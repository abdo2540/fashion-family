class BackdropConstants {
  static const double drawerWidth = 150;
}

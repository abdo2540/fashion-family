import 'package:flutter/material.dart';

import 'package:provider/src/provider.dart';
import '../../screens/base.dart';
import 'package:fashion/models/index.dart'
    show
        AppModel,
        BlogModel,
        CartModel,
        CategoryModel,
        FilterAttributeModel,
        FilterTagModel,
        TagModel,
        UserModel;

class StaticSplashScreen extends StatefulWidget {
  final String imagePath;
  final Function onNextScreen;
  final int duration;
  final Key key;

  StaticSplashScreen({
    this.imagePath,
    this.key,
    this.onNextScreen,
    this.duration = 1500,
  });

  @override
  _StaticSplashScreenState createState() => _StaticSplashScreenState();
}

class _StaticSplashScreenState extends BaseScreen<StaticSplashScreen> {
  @override
  void afterFirstLayout(BuildContext context) {
    Future.delayed(Duration(milliseconds: widget.duration), () {
      widget.onNextScreen();
      // final lang = Provider.of<AppModel>(context, listen: false).langCode;
      // Provider.of<CategoryModel>(context, listen: false).getCategories(
      //   lang: lang,
      //   sortingList: Provider.of<AppModel>(context, listen: false).categories,
      // );

//      Navigator.of(context).pushReplacement(
//          MaterialPageRoute(builder: (context) => widget.onNextScreen));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).backgroundColor,
      body: Container(
        height: double.infinity,
        width: double.infinity,
        child: Center(
          child: Image.asset("assets/fashion/logo.png",
              gaplessPlayback: true, fit: BoxFit.fitWidth),
        ),
      ),
    );
  }
}

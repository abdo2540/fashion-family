import 'package:fashion/screens/detail/index.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_slidable/src/widgets/slidable.dart';
import '../../common/config/products.dart';
import '../../common/constants.dart';
import '../../common/tools.dart';
import '../../models/index.dart' show AppModel, Product, ProductVariation;
import '../../services/index.dart';
import 'product_variant.dart';

import '../../generated/l10n.dart';
import 'package:intl/intl.dart';
import 'package:fashion/caco/size_config.dart';
import 'package:flutter_slidable/src/widgets/slidable_action_pane.dart';
import 'package:flutter_slidable/src/widgets/slide_action.dart';
import 'package:fashion/models/product_addons.dart';
class ShoppingCartRow extends StatelessWidget {
  ShoppingCartRow({
    @required this.product,
    @required this.quantity,
    this.onRemove,
    this.onChangeQuantity,
    this.variation,
    this.options,
    this.addonsOptions,
  });

  final Product product;
  final List<AddonsOption> addonsOptions;
  final ProductVariation variation;
  final Map<String, dynamic> options;
  final int quantity;
  final Function onChangeQuantity;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    var currency = Provider.of<AppModel>(context).currency;
    final currencyRate = Provider.of<AppModel>(context).currencyRate;

    final price = Services().widget.getPriceItemInCart(
        product, variation, currencyRate, currency,
        selectedOptions: addonsOptions);

    final imageFeature = variation != null && variation.imageFeature != null
        ? variation.imageFeature
        : product.imageFeature;
    var maxQuantity = kCartDetail['maxAllowQuantity'] ?? 100;
    var totalQuantity = variation != null
        ? (variation.stockQuantity ?? maxQuantity)
        : (product.stockQuantity ?? maxQuantity);
    var limitQuantity =
    totalQuantity > maxQuantity ? maxQuantity : totalQuantity;

    ThemeData theme = Theme.of(context);

    return LayoutBuilder(
      builder: (context, constraints) {
        return InkWell(
          onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=> ProductDetailScreen(product: product,)));
          },
          child: Container(
            height: MediaQuery.of(context).size.height*.18,
            child: Column(
              children: [
                Container(
                  margin:   const EdgeInsets.symmetric(vertical:5),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      // boxShadow: [
                      //   BoxShadow(
                      //     color: Colors.grey.withOpacity(0.1),
                      //     spreadRadius: 5,
                      //     blurRadius: 7,
                      //     offset: Offset(0, 3), // changes position of shadow
                      //   ),
                      // ],
                      borderRadius:
                      BorderRadius
                          .circular(10)),
                  child: Center(
                    child: Row(
                      key: ValueKey(product.name+price),
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Container(
                            margin:
                                EdgeInsets.symmetric(horizontal: 8, vertical: 0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Container(
                                    width: constraints.maxWidth * 0.3,
                                    height: constraints.maxWidth * 0.35,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.all(
                                        // topLeft:
                                        Radius.circular(10),
                                        // bottomLeft: Radius.circular(20),
                                      ),
                                    ),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(10.0),
                                      child: Tools.image(url: product.imageFeature,fit: BoxFit.cover),
                                    )),

                                const SizedBox(width: 6.0),
                                Expanded(
                                  child: Container(
                                    width: constraints.maxWidth * 0.40,
                                    height: constraints.maxWidth * 0.32,
                                    alignment: Alignment.center,
                                    child: Padding(
                                      padding:
                                          const EdgeInsets.symmetric(vertical: 0),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          SingleChildScrollView(
                                            scrollDirection: Axis.horizontal,
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              children: [
                                                Text(
                                                  product.name,
                                                  style: TextStyle(
                                                      // color: theme.primaryColor,
                                                      fontSize: 16.5,
                                                      fontWeight: FontWeight.bold),
                                                  maxLines: 1,
                                                  overflow: TextOverflow.ellipsis,
                                                ),

                                              ],
                                            ),
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.end,
                                            children: [
                                              Text(
                                                '${product.price} ' + ' ' + S.of(context).currency,
                                                style: TextStyle(
                                                    color: Colors.black,
                                                    fontSize: 15,
                                                    fontWeight: FontWeight.w500),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),

                                            ],
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              // product.categories[0].name==null?Text(""):
                                              // Text(
                                              //   '${product.categories[0].name} ',
                                              //   style: TextStyle(
                                              //       color: Colors.black,
                                              //       fontSize: 15,
                                              //       fontWeight: FontWeight.w500),
                                              //   maxLines: 1,
                                              //   overflow: TextOverflow.ellipsis,
                                              // ),
                                              Container(
                                                width: constraints.maxWidth * 0.2,
                                                height: constraints.maxWidth * 0.1,
                                                child: Padding(
                                                  padding: const EdgeInsets.symmetric(
                                                      vertical: 0),
                                                  child: QuantitySelection(
                                                    enabled: onChangeQuantity != null,
                                                    width: 80,
                                                    height: 100,
                                                    color: Theme.of(context).primaryColor,
                                                    limitSelectQuantity: limitQuantity,
                                                    value: quantity,
                                                    onChanged:onChangeQuantity,
                                                    useNewDesign: true,
                                                  ),
                                                ),
                                              )

                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Services()
                                                  .widget
                                                  .renderVariantCartItem(variation, options),
                                              if (addonsOptions?.isNotEmpty ?? false)
                                                Services().widget.renderAddonsOptionsCartItem(
                                                    context, addonsOptions),
                                              InkWell(
                                                onTap: onRemove,
                                                child: Icon(Icons.delete, color: Colors.red,
                                                ),
                                              ),


                                              // Text(
                                              //
                                              //   '${product.selectedOptions} ',
                                              //   style: TextStyle(
                                              //       color: Colors.black,
                                              //       fontSize: 15,
                                              //       fontWeight: FontWeight.w500),
                                              //   maxLines: 1,
                                              //   overflow: TextOverflow.ellipsis,
                                              // ),
                                              // if (variation != null || options != null)
                                              //   Services()
                                              //       .widget
                                              //       .renderVariantCartItem(variation, options),
                                              // if (addonsOptions?.isNotEmpty ?? false)
                                              //   Services().widget.renderAddonsOptionsCartItem(
                                              //       context, addonsOptions),




                                              // const SizedBox(height: 7),
                                              // Text(
                                              //   " جنية مصري",
                                              //   style: TextStyle(
                                              //       color: Colors.black,
                                              //       fontSize: 11.5,
                                              //       fontWeight: FontWeight.w500),
                                              //   maxLines: 1,
                                              //   overflow: TextOverflow.ellipsis,
                                              // ),
                                              // InkWell(
                                              //   onTap: onRemove,
                                              //   child: Container(
                                              //     decoration: BoxDecoration(
                                              //
                                              //       borderRadius:
                                              //           BorderRadius.circular(10.0),
                                              //     ),
                                              //     width: 50,
                                              //     height: 35,
                                              //     child: Center(
                                              //       child: Icon(
                                              //         Icons.delete,
                                              //         color: Color(0xff4f3933),
                                              //       ),
                                              //     ),
                                              //   ),
                                              // ),

                                            ],
                                          ),






                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                // SizedBox(height: 20,),

                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                // const SizedBox(height: 10.0),
                // const Divider(color: Color(0xFFffd900), height: 1),
                // const SizedBox(height: 10.0),
              ],
            ),
          ),
        );
      },
    );
  }

  Padding buildPaddingCartRow() {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4, horizontal: 15),
      child: Container(
        width: double.infinity,
        child: Card(
          elevation: 5,
          shadowColor: Colors.black.withOpacity(0.6),
          margin: EdgeInsets.all(0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 0, vertical: 0),
            child: Row(
              children: [
                Container(
                  width: 90,
                  height: 95,
                  clipBehavior: Clip.antiAliasWithSaveLayer,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20),
                      bottomLeft: Radius.circular(20),
                    ),
                  ),
                  child: Image.asset(
                    " products.image",
                    fit: BoxFit.cover,
                    width: double.infinity,
                    height: double.infinity,
                  ),
                ),
                SizedBox(width: SizeConfig.screenWidth * 0.04),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "products.name",
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 16),
                      ),
                      SizedBox(height: SizeConfig.screenHeight * 0.005),
                      Row(
                        children: [
                          Text(
                            "   products.discountPrice != 0.0",
                            // ? '\$${products.discountPrice}'
                            // : '\$${products.price}'",
                            style: TextStyle(
                              fontSize: 15,
                              color: Colors.red,
                            ),
                          ),
                          // products.discountPrice != 0.0
                          //     ? SizedBox(width: SizeConfig.screenWidth * 0.02)
                          //     : Container(),
                          // products.discountPrice != 0.0
                          //     ? Text(
                          //   '\$${products.price}',
                          //   style: TextStyle(
                          //     fontSize: 15,
                          //     color: Colors.grey,
                          //     decoration: TextDecoration.lineThrough,
                          //   ),
                          // )
                          //     : Container(),
                        ],
                      ),
                      SizedBox(height: SizeConfig.screenHeight * 0.005),
//                    QuantityPicker(),
                    ],
                  ),
                ),
                SizedBox(width: SizeConfig.screenWidth * 0.01),
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        icon: Icon(
                          Icons.add,
                          size: 20,
                        ),
                        constraints: BoxConstraints(maxWidth: 20),
                        onPressed: () => null,
                        padding: EdgeInsets.all(0),
                        splashRadius: 15,
//                        backgroundColor: Colors.white,
//                        foregroundColor: Colors.black54,
//                        radius: 13,
                      ),
                      SizedBox(height: SizeConfig.screenHeight * 0.002),
                      Text('1', style: TextStyle(fontSize: 16)),
                      SizedBox(height: SizeConfig.screenHeight * 0.002),
                      IconButton(
                        icon: Icon(
                          Icons.remove,
                          size: 20,
                          color: Colors.black45,
                        ),
                        constraints: BoxConstraints(maxWidth: 20),
                        onPressed: () => null,
                        padding: EdgeInsets.all(0),
                        splashRadius: 15,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import '../../common/config/products.dart';
import '../../common/constants.dart';
import '../../common/tools.dart';
import '../../generated/l10n.dart';
import 'package:fashion/caco/size_config.dart';
import '../../widgets/common/tooltip.dart' as tool_tip;

enum VariantLayout { inline, dropdown }

class BasicSelection extends StatefulWidget {
  final Map<String, String> imageUrls;
  final List<String> options;
  final String value;
  final String title;
  final String type;
  final Function onChanged;
  final VariantLayout layout;

  BasicSelection(
      {@required this.options,
      @required this.title,
      @required this.value,
      this.type,
      this.layout,
      this.onChanged,
      this.imageUrls});

  @override
  _BasicSelectionState createState() => _BasicSelectionState();
}

class _BasicSelectionState extends State<BasicSelection> {
  @override
  Widget build(BuildContext context) {
    Color primaryColor = Color(0xff4F3933);

    if (widget.type == "option") {
      return OptionSelection(
        options: widget.options,
        value: widget.value,
        title: widget.title,
        onChanged: widget.onChanged,
      );
    }

    if (widget.type == "image") {
      return ImageSelection(
        imageUrls: widget.imageUrls,
        options: widget.options,
        value: widget.value,
        title: widget.title,
        onChanged: widget.onChanged,
      );
    }

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        // spacing: 0.0,
        // runSpacing: 5.0,
        crossAxisAlignment: CrossAxisAlignment.start,

        // mainAxisAlignment: MainAxisAlignment.s,
        children: <Widget>[
          // Text(
          //   "${widget.title[0].toUpperCase()}${widget.title.substring(1)} :   ",
          //   style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
          // ),
          for (var item in widget.options)
            tool_tip.Tooltip(
              message: item.toString(),
              child: Container(
                //height: type == "color" ? 26 : 30,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.ease,
                  margin: const EdgeInsets.symmetric(horizontal: 1),
                  decoration: widget.type == "color"
                      ? BoxDecoration(
                    color:
                    item.toUpperCase() == widget.value.toUpperCase()
                        ? HexColor(kNameToHex[item
                        .toString()
                        .replaceAll(' ', "_")
                        .toLowerCase()] ??
                        "#ffffff")
                        : HexColor(kNameToHex[item
                        .toString()
                        .replaceAll(' ', "_")
                        .toLowerCase()] ??
                        "#ffffff")
                        .withOpacity(0.6),
                    // borderRadius: BorderRadius.circular(),
                    shape: BoxShape.circle,
                  )
                      : BoxDecoration(
                    // color: item.toUpperCase() == value.toUpperCase()
                    //     ? Colors.white
                    //     : Colors.transparent,
                    // shape: BoxShape.rectangle,
                    // border: Border.all(
                    //     color: item.toUpperCase() ==
                    //             value.toUpperCase()
                    //         ? Colors.black
                    //         : Colors.transparent),
                  ),
                  child: InkWell(
                    // splashColor: Colors.transparent,
                    // highlightColor: Colors.transparent,
                    onTap: () {
                      widget.onChanged(item);
                    },
                    child: widget.type == "color"
                        ? Container(
                      margin: EdgeInsets.only(right: 2),
                      width: 50,
                      height: 50,
                      decoration: new BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                            width: 1,
                            color:
                            Colors.black.withOpacity(1)),
                      ),
                      child: item == widget.value
                          ? const Icon(
                        Icons.check,
                        color: Colors.black,
                        size: 20,
                      )
                          : Container(
                        decoration: new BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                              width: .0001,
                              color: Colors.grey),
                        ),
                      ),
                    )
                        : Container(
                      width: 50,
                      height: 50,
                      margin: EdgeInsets.only(right: 2),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: item.toUpperCase() ==
                            widget.value.toUpperCase()
                            ? Theme.of(context).primaryColor
                            : Colors.transparent,
                        border: Border.all(
                            width: 1.3,
                            color: item.toUpperCase() ==
                                widget.value.toUpperCase()
                                ? Theme.of(context).primaryColor
                                : Colors.grey),
                      ),
                      padding: const EdgeInsets.all(
                        5,
                      ),
                      child: Padding(
                        child: Center(
                          child: FittedBox(
                            child: Text(
                              item,
                              style: TextStyle(
                                color: item == widget.value
                                    ? Colors.white
                                    : Colors.black,
                                fontSize: 15,
                              ),
                            ),
                          ),
                        ),
                        padding: const EdgeInsets.only(
                            top: 2, bottom: 2),
                      ),
                    ),
                  ),
                ),
              ),
            )
        ],
      ),
    );
  }
}

class OptionSelection extends StatelessWidget {
  final List<String> options;
  final String value;
  final String title;
  final Function onChanged;
  final VariantLayout layout;

  OptionSelection({
    @required this.options,
    @required this.value,
    this.title,
    this.layout,
    this.onChanged,
  });

  showOptions(context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              for (final option in options)
                ListTile(
                    onTap: () {
                      onChanged(option);
                      Navigator.pop(context);
                    },
                    title: Text(option, textAlign: TextAlign.center)),
              Container(
                height: 1,
                decoration: const BoxDecoration(color: kGrey200),
              ),
              ListTile(
                title: Text(
                  S.of(context).selectTheSize,
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => showOptions(context),
      child: Container(
        height: 42,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 2.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Expanded(
                child: Text("${title[0].toUpperCase()}${title.substring(1)}",
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 18)),
              ),
              Text(
                value,
                style: TextStyle(
                  color: Theme.of(context).accentColor,
                  fontSize: 13,
                ),
              ),
              const SizedBox(width: 5),
              const Icon(Icons.keyboard_arrow_down, size: 16, color: kGrey600)
            ],
          ),
        ),
      ),
    );
  }
}

class ColorSelection extends StatelessWidget {
  final List<String> options;
  final String value;
  final Function onChanged;
  final VariantLayout layout;

  ColorSelection(
      {@required this.options,
      @required this.value,
      this.layout,
      this.onChanged});

  @override
  Widget build(BuildContext context) {
    if (layout == VariantLayout.dropdown) {
      return GestureDetector(
        onTap: () => showOptions(context),
        child: Container(
          decoration:
              BoxDecoration(border: Border.all(width: 1.0, color: kGrey200)),
          height: 42,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Expanded(
                  child: Text(S.of(context).color,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 14)),
                ),
                Container(
                    height: 20,
                    width: 20,
                    decoration: BoxDecoration(
                        color: kNameToHex[value.toLowerCase()] != null
                            ? HexColor(kNameToHex[value.toLowerCase()])
                            : Colors.transparent)),
                const SizedBox(width: 5),
                const Icon(Icons.keyboard_arrow_down, size: 16, color: kGrey600)
              ],
            ),
          ),
        ),
      );
    }

    return Container(
      height: 25,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: <Widget>[
            Center(
              child: Text(
                S.of(context).color,
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
            ),
            const SizedBox(width: 15.0),
            for (var item in options)
              AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                curve: Curves.easeIn,
                margin: const EdgeInsets.only(right: 20.0),
                decoration: BoxDecoration(
                  color: item == value
                      ? HexColor(kNameToHex[item.toLowerCase()])
                      : HexColor(kNameToHex[item.toLowerCase()])
                          .withOpacity(0.6),
                  borderRadius: BorderRadius.circular(20.0),
                  border: Border.all(
                      width: 1.0,
                      color: Theme.of(context).accentColor.withOpacity(0.5)),
                ),
                child: InkWell(
                  splashColor: Colors.transparent,
                  highlightColor: Colors.transparent,
                  onTap: () {
                    onChanged(item);
                  },
                  child: SizedBox(
                    height: 25,
                    width: 25,
                    child: item == value
                        ? const Icon(
                            Icons.check,
                            color: Colors.white,
                            size: 16,
                          )
                        : Container(),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  void showOptions(context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              for (final option in options)
                ListTile(
                  onTap: () {
                    onChanged(option);
                    Navigator.pop(context);
                  },
                  title: Center(
                    child: Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(3.0),
                        border: Border.all(
                            width: 1.0, color: Theme.of(context).accentColor),
                        color: HexColor(kNameToHex[option.toLowerCase()]),
                      ),
                    ),
                  ),
                ),
              Container(
                height: 1,
                decoration: const BoxDecoration(color: kGrey200),
              ),
              ListTile(
                title: Text(
                  S.of(context).selectTheColor,
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class QuantitySelection extends StatefulWidget {
  final int limitSelectQuantity;
  final int value;
  final double width;
  final double height;
  final Function onChanged;
  final Color color;
  final bool useNewDesign;
  final bool enabled;
  final bool expanded;

  QuantitySelection({
    @required this.value,
    this.width = 40.0,
    this.height = 42.0,
    this.limitSelectQuantity = 100,
    @required this.color,
    this.onChanged,
    this.useNewDesign = true,
    this.enabled = true,
    this.expanded = false,
  });

  @override
  _QuantitySelectionState createState() => _QuantitySelectionState();
}

class _QuantitySelectionState extends State<QuantitySelection> {
  final TextEditingController _textController = TextEditingController();
  Timer _debounce;

  Timer _changeQuantityTimer;

  @override
  void initState() {
    super.initState();
    _textController.text = "${widget.value}";
    _textController.addListener(_onQuantityChanged);
  }

  @override
  void dispose() {
    _textController?.removeListener(_onQuantityChanged);
    _changeQuantityTimer?.cancel();
    _debounce?.cancel();
    _textController?.dispose();
    super.dispose();
  }

  int get currentQuantity => int.tryParse(_textController.text) ?? -1;

  bool _validateQuantity([int value]) {
    if ((value ?? currentQuantity) <= 0) {
      _textController.text = "1";
      return false;
    }

    if ((value ?? currentQuantity) > widget.limitSelectQuantity) {
      _textController.text = "${widget.limitSelectQuantity}";
      return false;
    }
    return true;
  }

  void changeQuantity(int value, {bool forceUpdate = false}) {
    if (!_validateQuantity(value)) {
      return;
    }

    if (value != currentQuantity || forceUpdate == true) {
      _textController.text = "$value";
    }
  }

  void _onQuantityChanged() {
    if (!_validateQuantity()) {
      return;
    }

    if (_debounce?.isActive ?? false) {
      _debounce.cancel();
    }
    _debounce = Timer(
      const Duration(milliseconds: 300),
      () {
        if (widget.onChanged != null) {
          widget.onChanged(currentQuantity);
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widget.useNewDesign == true) {
      final _iconPadding = EdgeInsets.all(
        max(
          ((widget.height ?? 32.0) - 24.0 - 8) * 0.5,
          0.0,
        ),
      );
      final _textField = Container(
        margin: const EdgeInsets.symmetric(horizontal: 4.0),
        height: widget.height,
        width: widget.expanded == true ? null : widget.width,
        decoration: BoxDecoration(
          border: Border.all(width: 1.0, color: kGrey200),
          borderRadius: BorderRadius.circular(3),
        ),
        alignment: Alignment.center,
        child: TextField(
          readOnly: widget.enabled == false,
          enabled: widget.enabled == true,
          controller: _textController,
          maxLines: 1,
          maxLength: "${widget.limitSelectQuantity ?? 100}".length,
          onEditingComplete: _validateQuantity,
          onSubmitted: (_) => _validateQuantity(),
          decoration: const InputDecoration(
            border: InputBorder.none,
            counterText: "",
          ),
          keyboardType: const TextInputType.numberWithOptions(
            signed: false,
            decimal: false,
          ),
          textAlign: TextAlign.center,
        ),
      );
      return Container(
        height: 200,
        decoration: BoxDecoration(
            // color: Colors.amber,
            // boxShadow: [
            //   BoxShadow(
            //     color: Colors.grey.withOpacity(0.1),
            //     spreadRadius: 5,
            //     blurRadius: 7,
            //     offset: Offset(0, 3), // changes position of shadow
            //   ),
            // ],
            borderRadius:
            BorderRadius
                .circular(10)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment:CrossAxisAlignment.center ,
          children: [
            InkWell(
                onTap:() => changeQuantity(currentQuantity - 1),
                child: Center(
                  child: Icon(
                    Icons.indeterminate_check_box_outlined,
                    size: 20,
                    color:Theme.of(context).primaryColor,
                  ),
                )),
            Text(
              '$currentQuantity',
              style: TextStyle(
                fontSize: 18,
              ),
            ),
            InkWell(
              onTap: () => changeQuantity(currentQuantity + 1),

              child: Center(
                child:  Icon(
                  Icons.add_box_outlined,
                  color:Theme.of(context).primaryColor,
                  size: 20,
                ),
              ),
            ),
          ],
        ),
      );
    }
    return GestureDetector(
      onTap: () {
        // if (widget.onChanged != null) {
        //   showOptions(context);
        // }
      },
      child:Container(
        height: 30,
        width: 100,
        decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3), // changes position of shadow
              ),
            ],
            borderRadius:
            BorderRadius
                .circular(10)),
        child: Padding(
          padding: const EdgeInsets.symmetric(  vertical: 5),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment:CrossAxisAlignment.center ,
            children: [
              InkWell(
                onTap: () => changeQuantity(currentQuantity + 1),

                child: Center(
                  child: const Icon(
                    Icons.add_circle_outline_sharp,
                    color: Color(0xff4f3933),
                    size: 20,
                  ),
                ),
              ),
              // SizedBox(height: 7),
              Text(
                '$currentQuantity',
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
              // SizedBox(height: 7),
              InkWell(
                  onTap:() {

                    changeQuantity(currentQuantity - 1);

                  },
                  child: Center(
                    child: Icon(
                      Icons.remove_circle_outline,
                      size: 20,
                      color:Color(0xff4f3933),
                    ),
                  )),

            ],
          ),
        ),
      )
      // Column(
      //   mainAxisAlignment: MainAxisAlignment.spaceAround,
      //   crossAxisAlignment: CrossAxisAlignment.center,
      //   children: [
      //     SizedBox(height: 15),
      //     CircleAvatar(
      //       backgroundColor: Color(0xff4f3933),
      //       radius: 12,
      //       child: Center(
      //         child: IconButton(
      //           // padding: _iconPadding,
      //           onPressed: () => changeQuantity(currentQuantity + 1),
      //           icon: const Icon(
      //             Icons.add,
      //             size: 9,
      //             color: Colors.white,
      //           ),
      //         ),
      //       ),
      //     ),
      //
      //     // Expanded(
      //     //   child: _textField,
      //     // ),
      //     SizedBox(height: 9),
      //     Text(
      //       '$currentQuantity',
      //       style: TextStyle(fontSize: 15),
      //     ),
      //     SizedBox(height: 5),
      //     CircleAvatar(
      //       backgroundColor: Color(0xff4f3933),
      //       radius: 12,
      //       child: IconButton(
      //         // padding: _iconPadding,
      //         onPressed: () => changeQuantity(currentQuantity - 1),
      //         icon: const Center(
      //             child: Icon(
      //           Icons.remove,
      //           color: Colors.white,
      //           size: 9,
      //         )),
      //       ),
      //     ),
      //   ],
      // ),
    );
  }

  void showOptions(context) {
    showModalBottomSheet(
        context: context,
        useRootNavigator: true,
        builder: (BuildContext context) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      for (int option = 1;
                          option <= widget.limitSelectQuantity;
                          option++)
                        ListTile(
                            onTap: () {
                              widget.onChanged(option);
                              Navigator.pop(context);
                            },
                            title: Text(
                              option.toString(),
                              textAlign: TextAlign.center,
                            )),
                    ],
                  ),
                ),
              ),
              Container(
                height: 1,
                decoration: const BoxDecoration(color: kGrey200),
              ),
              ListTile(
                title: Text(
                  S.of(context).selectTheQuantity,
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          );
        });
  }
}

class ImageSelection extends StatelessWidget {
  final Map<String, String> imageUrls;
  final List<String> options;
  final String value;
  final String title;
  final Function onChanged;
  final VariantLayout layout;

  ImageSelection({
    @required this.options,
    @required this.value,
    this.title,
    this.layout,
    this.onChanged,
    this.imageUrls,
  });

  @override
  Widget build(BuildContext context) {
    final double size = kProductDetail["attributeImagesSize"] ?? 50.0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Padding(
                child: Text(
                  "${title[0].toUpperCase()}${title.substring(1)}",
                  style: Theme.of(context).textTheme.headline6,
                ),
                padding: const EdgeInsets.only(bottom: 10),
              ),
            ),
          ],
        ),
        Wrap(
          spacing: 0.0,
          runSpacing: 12.0,
          children: <Widget>[
            for (var item in options)
              tool_tip.Tooltip(
                message: item.toString(),
                child: Container(
                  height: size + 2,
                  width: size + 2,
                  margin: const EdgeInsets.only(right: 15.0),
                  child: Container(
                    padding: const EdgeInsets.all(2.0),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5.0),
                      border: Border.all(
                        width: 1.0,
                        color: Theme.of(context).accentColor.withOpacity(
                            item.toUpperCase() == value.toUpperCase()
                                ? 0.6
                                : 0.3),
                      ),
                    ),
                    child: InkWell(
                      splashColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () {
                        onChanged(item);
                      },
                      child: Stack(
                        children: [
                          Positioned.fill(
                            child: Tools.image(
                              url: imageUrls[item],
                              height: size,
                              width: size,
                            ),
                          ),
                          if (item.toUpperCase() == value.toUpperCase())
                            Positioned.fill(
                              child: Container(
                                color: Theme.of(context)
                                    .backgroundColor
                                    .withOpacity(0.6),
                                child: const Icon(
                                  Icons.check_circle_rounded,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              )
          ],
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'package:fashion/caco/constants.dart';
import 'package:flutter_styled_toast/flutter_styled_toast.dart';
import 'package:fashion/generated/l10n.dart';
// import 'custom_toast_content_widget.dart';
import '../../models/index.dart' show Product, WishListModel;

class HeartButton extends StatefulWidget {
  final Product product;
  final double size;
  final Color color;

  HeartButton({this.product, this.size, this.color});

  @override
  _HeartButtonState createState() => _HeartButtonState();
}

class _HeartButtonState extends State<HeartButton> {
  @override
  Widget build(BuildContext context) {
    List<Product> wishlist = Provider.of<WishListModel>(context).getWishList();
    final isExist = wishlist.firstWhere((item) => item.id == widget.product.id,
        orElse: () => null);

    if (isExist == null) {
      return InkWell(
        onTap: () {
          Provider.of<WishListModel>(context, listen: false)
              .addToWishlist(widget.product);
          setState(() {});
          showToast(S.of(context).addedToWishlist,
              context: context,
              animation: StyledToastAnimation.slideFromLeftFade,
              reverseAnimation: StyledToastAnimation.fadeScale,
              position:
                  StyledToastPosition(align: Alignment.topCenter, offset: 0.0),
              startOffset: Offset(0.0, -3.0),
              reverseEndOffset: Offset(0.0, -3.0),
              duration: Duration(seconds: 2),
              //Animation duration   animDuration * 2 <= duration
              animDuration: Duration(milliseconds: 700),
              backgroundColor: Theme.of(context).primaryColor,
              curve: Curves.fastLinearToSlowEaseIn,
              reverseCurve: Curves.fastOutSlowIn);
        },
        child: Container(
          height: 30,
          width: 30,
          decoration: new BoxDecoration(
            // color: Colors.white,
            shape: BoxShape.circle,
            // border: Border.all(width: 1.0, color: Colors.red),
          ),
          child: Center(
              child: Icon(Icons.favorite_border, color: Color(0xfff35819), size: 20)),
        ),
      );
    }

    // !isFavorite
    //    ? Icon(
    //        Icons.favorite_border,
    //        color: kPrimaryColor,
    //      )
    //    : Icon(
    //        Icons.favorite,
    //        color: kPrimaryColor,
    //      ),

    return InkWell(
      onTap: () {
        Provider.of<WishListModel>(context, listen: false)
            .removeToWishlist(widget.product);
        setState(() {});
        showToast(S.of(context).removedFromWishlist,
            context: context,
            animation: StyledToastAnimation.slideFromLeftFade,
            reverseAnimation: StyledToastAnimation.fadeScale,
            position:
                StyledToastPosition(align: Alignment.topCenter, offset: 0.0),
            startOffset: Offset(0.0, -3.0),
            reverseEndOffset: Offset(0.0, -3.0),
            duration: Duration(seconds: 2),
            //Animation duration   animDuration * 2 <= duration
            animDuration: Duration(milliseconds: 700),
            backgroundColor: Colors.red,
            curve: Curves.fastLinearToSlowEaseIn,
            reverseCurve: Curves.fastOutSlowIn);
      },
      child: Container(
        height: 30,
        width: 30,
        decoration: new BoxDecoration(
          // color: Colors.white,
          shape: BoxShape.circle,
          // border: Border.all(width: 1.0, color: Colors.red),
        ),
        child: Center(child: Icon(Icons.favorite, color: Color(0xfff35819), size: 20)),
      ),
    );

    // IconButton(
    //     onPressed: () {
    //       Provider.of<WishListModel>(context, listen: false)
    //           .removeToWishlist(widget.product);
    //       setState(() {});
    //     },
    //     icon: Icon(
    //       Icons.favorite,
    //       color: Colors.red,
    //       size: 25,
    //     )

    //     //  CircleAvatar(
    //     //   backgroundColor: Colors.pink.withOpacity(0.1),
    //     //   child: Icon(FontAwesomeIcons.solidHeart,
    //     //       color: Colors.pink, size: widget.size ?? 16.0),
    //     // ),
    //     );
  }
}

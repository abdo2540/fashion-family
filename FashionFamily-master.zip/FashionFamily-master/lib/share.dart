import 'package:url_launcher/url_launcher.dart';

class ShareFunction {
  launchCaller() async {
    const url = 'tel://+201094575555';
    await launch(url);
  }
  launchInstagram() async {
    const url = 'https://www.instagram.com/fashionfamilyeg/';
    await launch(url);
  }

  launchMessanger() async {
    const url = 'https://m.me/fashionfamilyeg/';
    await launch(url);
  }

  launchWhatApp() async {
    const url = 'https://wa.me/+201094575555/';
    await launch(url);
  }

  launchTiktok() async {
    const url = 'https://www.tiktok.com/@fashionfamilyeg';
    await launch(url);
  }
  launchFacebook() async {
    const url = 'https://www.facebook.com/FashionFamilyEG';
    await launch(url);
  }
}

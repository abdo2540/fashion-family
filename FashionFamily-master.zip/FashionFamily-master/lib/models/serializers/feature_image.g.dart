// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feature_image.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeatureImage _$FeatureImageFromJson(Map<String, dynamic> json) {
  return FeatureImage(
    url: json['url'] as String,
  );
}

Map<String, dynamic> _$FeatureImageToJson(FeatureImage instance) =>
    <String, dynamic>{
      'url': instance.url,
    };

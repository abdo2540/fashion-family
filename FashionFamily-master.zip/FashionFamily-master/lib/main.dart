import 'dart:io' show HttpClient;
import 'package:app_tracking_transparency/app_tracking_transparency.dart';
import 'package:appsflyer_sdk/appsflyer_sdk.dart';
import 'package:device_preview/device_preview.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'common/constants.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final status = await AppTrackingTransparency.requestTrackingAuthorization();

  GestureBinding.instance.resamplingEnabled = true;
  Map appsFlyerOptions = {
    "afDevKey": "ZZparsHDZ68cKuxsNbvpUJ",
    "afAppId": "1614618732",
    "isDebug": true
  };

  AppsflyerSdk appsflyerSdk = await AppsflyerSdk(appsFlyerOptions);

  appsflyerSdk.onInstallConversionData((res) {
    print("res:  ssssssssssssssssssssssssssssssssssssssssssssssss" +
        res.toString());
  });
  appsflyerSdk.onAppOpenAttribution((res) {
    print("res: " + res.toString());
  });
  appsflyerSdk.setCurrencyCode("EGP");
  appsflyerSdk.onDeepLinking((res) {
    print("res: " + res.toString());
  });
  // appsflyerSdk.
  appsflyerSdk.initSdk(
      registerConversionDataCallback: true,
      registerOnAppOpenAttributionCallback: true,
      registerOnDeepLinkingCallback: true);
  Provider.debugCheckInvalidValueType = null;
  printLog('[main] ============== main.dart START ==============');

  if (!kIsWeb) {
    /// enable network traffic logging
    HttpClient.enableTimelineLogging = true;

    // await SystemChrome.setPreferredOrientations(
    //     [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);

    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle.dark.copyWith(statusBarColor: Colors.transparent),
    );
  }

  //Initialize Firebase due to version 0.5.0+ requires to
  if (!isWindow) await Firebase.initializeApp();
  printLog('[main] Initialize Firebase successfully');
  // runApp(
  //   DevicePreview(
  //     // enabled: !kReleaseMode,
  //     builder: (context) => App(), // Wrap your app
  //   ),
  // );
  runApp(App());
}

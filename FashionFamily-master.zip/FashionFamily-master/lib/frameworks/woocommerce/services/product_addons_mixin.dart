import 'dart:convert';

import 'package:fashion/common/index.dart';
import 'package:fashion/generated/i18n.dart';
import 'package:fashion/models/app_model.dart';
import 'package:fashion/models/entities/product.dart';
import 'package:fashion/models/product_addons.dart';
import 'package:fashion/services/index.dart';
import 'package:flutter/material.dart';
import 'package:fashion/widgets/product/product_variant.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:path/path.dart' as path;
import 'package:provider/provider.dart';

// import '../../models/index.dart'
//     show AddonsOption, AppModel, Product, ProductAddons, UserModel;

mixin ProductAddonsMixin {
  bool get mediaTypeAllowed => (true) || (true);

  bool isUploading = false;

  bool get customTypeAllowed => (false);

  // FileType get allowedCustomFileType {
  //   final allowedTypes = kProductAddons['allowedCustomType'];
  //   if ((kProductAddons['allowCustomType'] ?? false) &&
  //       (allowedTypes is List && allowedTypes.isNotEmpty)) {
  //     return FileType.custom;
  //   }
  //   if ((kProductAddons['allowCustomType'] ?? false) &&
  //       (allowedTypes == null ||
  //           (allowedTypes is List && allowedTypes.isEmpty))) {
  //     return FileType.any;
  //   }
  //   throw Exception('No file type is supported!');
  // }
  //
  // FileType get allowedMediaFileType {
  //   if ((kProductAddons['allowImageType'] ?? true) &&
  //       (kProductAddons['allowVideoType'] ?? true)) {
  //     return FileType.media;
  //   }
  //   if ((kProductAddons['allowImageType'] ?? true) &&
  //       !(kProductAddons['allowVideoType'] ?? true)) {
  //     return FileType.image;
  //   }
  //   if (!(kProductAddons['allowImageType'] ?? true) &&
  //       (kProductAddons['allowVideoType'] ?? true)) {
  //     return FileType.video;
  //   }
  //   throw Exception('No file type is supported!');

  Future<void> getProductAddons({
    BuildContext context,
    Product product,
    Function(
            {Product productInfo,
            Map<String, Map<String, AddonsOption>> selectedOptions})
        onLoad,
    Map<String, Map<String, AddonsOption>> selectedOptions,
  }) async {
    final lang = Provider.of<AppModel>(context, listen: false).langCode;
    await Services().getProduct(product.id, lang: lang).then((onValue) async {
      if (onValue?.addOns?.isNotEmpty ?? false) {
        /// Select default options.
        selectedOptions.addAll(onValue.defaultAddonsOptions);

        onLoad(productInfo: onValue, selectedOptions: selectedOptions);
      }
    });
    return null;
  }

  int currentQuantity = 0;
  List<Widget> getProductAddonsWidget({
    BuildContext context,
    String lang,
    Product product,
    Map<String, Map<String, AddonsOption>> selectedOptions,
    Function onSelectProductAddons,
  }) {
    final rates = Provider.of<AppModel>(context).currencyRate;
    final listWidget = <Widget>[];
    if (product.addOns?.isNotEmpty ?? false) {
      listWidget.add(
        Container(
          padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10),
          margin: const EdgeInsets.only(bottom: 4),
          decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  spreadRadius: 5,
                  blurRadius: 7,
                  offset: Offset(0, 3), // changes position of shadow
                ),
              ],
              borderRadius: BorderRadius.circular(10)),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  'الاجمالي',
                  style: Theme.of(context)
                      .textTheme
                      .subtitle2
                      .copyWith(fontWeight: FontWeight.w600),
                ),
              ),
              const SizedBox(width: 4),
              Text(
                Tools.getCurrencyFormatted(product.productOptionsPrice, rates),
                style:Theme.of(context)
                    .textTheme
                    .subtitle2
                    .copyWith(fontWeight: FontWeight.w600),
              ),
              const SizedBox(width: 4),
            ],
          ),
        ),
      );
      listWidget.add(Column(
        children: product.addOns.map<Widget>((ProductAddons item) {
          final selected = (selectedOptions[item.name] ?? {});
          if (item.isHeadingType) {
            return Container(
              padding:
                  const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10),
              margin: const EdgeInsets.only(bottom: 4),
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColorLight.withOpacity(0.7),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      item.name,
                      style: Theme.of(context)
                          .textTheme
                          .subtitle2
                          .copyWith(fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            );
          }

          return ExpansionTile(
            tilePadding: const EdgeInsets.only(right: 8.0),
            title: ListTile(
              visualDensity: VisualDensity.adaptivePlatformDensity,
              title: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const SizedBox(width: 15),
                  Expanded(
                    child: Text(
                      item.name,
                    ),
                  ),
                  (item.isRadioButtonType && item.required)
                      ? Text(
                          'يجب الأختيار ',
                          style: TextStyle(
                            fontSize: 10,
                            color: Theme.of(context).accentColor,
                          ),
                        )
                      : const Text('')
                ],
              ),
              subtitle: selected.isNotEmpty
                  ? Padding(
                      padding: const EdgeInsets.only(right: 20, top: 5),
                      child: Text(
                        item.description
                            ,
                        style: Theme.of(context).textTheme.caption.copyWith(
                              color: Theme.of(context).primaryColor,
                              fontWeight: FontWeight.w600,
                            ),
                      ),
                    )
                  : Container(),
              contentPadding: EdgeInsets.zero,
            ),
            children: [
              Wrap(
                children: List.generate(item.options.length, (index) {
                  final option = item.options[index];
                  final isSelected = selected[option.label] != null;
                  final onTap = () {
                    if (item.isRadioButtonType) {
                      selected.clear();
                      selected[option.label] = option;
                      onSelectProductAddons(selectedOptions: selectedOptions);
                      return;
                    }
                    if (item.isCheckboxType) {
                      if (isSelected) {
                        selected.remove(option.label);
                      } else {
                        selected[option.label] = option;
                      }
                      onSelectProductAddons(selectedOptions: selectedOptions);
                      return;
                    }
                  };
                  return Container(
                    constraints: BoxConstraints(
                      minWidth: MediaQuery.of(context).size.width * 0.45,
                    ),
                    child: item.isFileUploadType
                        ? Padding(
                            padding: const EdgeInsets.only(
                              left: 8.0,
                              right: 8.0,
                              bottom: 8.0,
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: StatefulBuilder(
                                      builder: (context, StateSetter setState) {
                                    return TextButton.icon(
                                      onPressed: (isUploading ?? false)
                                          ? null
                                          : () => _showOption(context,
                                                  onFileUploadStart: () {
                                                isUploading = true;
                                                setState(() {});
                                              }, onFileUploadFailed: () {
                                                isUploading = false;
                                                setState(() {});
                                              }, onFileUploaded:
                                                      (List<String> fileUrls) {
                                                isUploading = false;
                                                setState(() {});
                                                for (var url in fileUrls) {
                                                  /// Overwrite previous file if not multiple files not allowed.
                                                  var key = (true ?? false)
                                                      ? url.split('/').last
                                                      : item.name;
                                                  selected[key] = AddonsOption(
                                                    parent: item.name,
                                                    label: '$url',
                                                  );
                                                  onSelectProductAddons(
                                                      selectedOptions:
                                                          selectedOptions);
                                                }
                                              }),
                                      icon: (isUploading ?? false)
                                          ? SizedBox(
                                              height: 20,
                                              width: 20,
                                              child: CircularProgressIndicator(
                                                strokeWidth: 2.0,
                                                valueColor:
                                                    AlwaysStoppedAnimation<
                                                            Color>(
                                                        Theme.of(context)
                                                            .primaryColor),
                                              ),
                                            )
                                          : const Icon(
                                              FontAwesomeIcons.fileUpload,
                                            ),
                                      label: Text(
                                        '${(isUploading ?? false)}'
                                            .toUpperCase(),
                                      ),
                                    );
                                  }),
                                ),
                              ],
                            ),
                          )
                        : InkWell(
                            onTap: onTap,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (item.isRadioButtonType)
                                  Radio(
                                    visualDensity: VisualDensity.compact,
                                    groupValue: selected.keys.isNotEmpty
                                        ? selected.keys.first
                                        : '',
                                    value: option.label,
                                    onChanged: (_) => onTap(),
                                    activeColor: Theme.of(context).primaryColor,
                                  ),
                                if (item.isCheckboxType)
                                  Checkbox(
                                    visualDensity: VisualDensity.compact,
                                    onChanged: (_) => onTap(),
                                    activeColor: Theme.of(context).primaryColor,
                                    checkColor: Colors.white,
                                    value: isSelected,
                                  ),
                                if (item.isTextType)
                                  Expanded(
                                    child: Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 8.0),
                                      child: TextField(
                                        onChanged: (text) {
                                          if (text.isEmpty) {
                                            selected.remove(item.name);
                                            onSelectProductAddons(
                                                selectedOptions:
                                                    selectedOptions);
                                            return;
                                          }

                                          if (selected[item.name] != null) {
                                            selected[item.name].label = text;
                                          } else {
                                            selected[item.name] = AddonsOption(
                                              parent: item.name,
                                              label: text + item.price,
                                              price: item.price,
                                            );
                                          }
                                          onSelectProductAddons(
                                              selectedOptions: selectedOptions);
                                        },
                                        decoration: InputDecoration(
                                          contentPadding:
                                              const EdgeInsets.all(8),
                                          border: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Theme.of(context)
                                                    .accentColor),
                                            borderRadius:
                                                BorderRadius.circular(5),
                                          ),
                                          labelText: option.label,
                                        ),
                                        minLines: 1,
                                        maxLines: item.isShortTextType ? 1 : 4,
                                      ),
                                    ),
                                  ),
                                if (!item.isTextType)
                                  Text(
                                    option.label,
                                    style: TextStyle(
                                      fontWeight:
                                          isSelected ? FontWeight.bold : null,
                                      fontSize: 14,
                                    ),
                                  ),
                                if (item.isInputMultiplier)
                                  QuantaiItem(
                                    item: item,
                                    onSelectProductAddons:
                                        onSelectProductAddons,
                                    selected: selected,
                                    selectedOptions: selectedOptions,
                                  ),
                                // if (item.isInputMultiplier &&
                                //     !item.isHeadingType)
                                //   Padding(
                                //     padding: const EdgeInsets.symmetric(
                                //         horizontal: 4.0),
                                //     child: Text(
                                //       '(${Tools.getCurrencyFormatted(option.price, rates)})',
                                //       style: TextStyle(
                                //         fontWeight:
                                //             isSelected ? FontWeight.bold : null,
                                //         fontSize: 13,
                                //       ),
                                //     ),
                              ],
                            ),
                          ),
                  );
                }),
              )
            ],
          );
        }).toList(),
      ));
    }
    return listWidget;
  }

  void _showOption(BuildContext context,
      {VoidCallback onFileUploadStart,
      Function(List<String> fileUrl) onFileUploaded,
      VoidCallback onFileUploadFailed}) {
    showModalBottomSheet(
      context: context,
      builder: (_context) {
        return Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            mainAxisSize: MainAxisSize.min,
            children: [
              Wrap(
                alignment: WrapAlignment.spaceEvenly,
                children: <Widget>[
                  if (true)
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(_context);
                        // selectFile(
                        //   context,
                        //   true,
                        //   onFileSelected: onFileUploaded,
                        //   onFileUploadStart: onFileUploadStart,
                        //   onFileUploadFailed: onFileUploadFailed,
                        // );
                      },
                      child: _UploadTypeIcon(
                        icon: FontAwesomeIcons.image,
                        text: "الاستوديو",
                      ),
                    ),
                  const SizedBox(width: 20),
                  if (true)
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(_context);
                        // selectFile(
                        //   context,
                        //   true,
                        //   onFileSelected: onFileUploaded,
                        //   onFileUploadStart: onFileUploadStart,
                        //   onFileUploadFailed: onFileUploadFailed,
                        // );
                      },
                      child: _UploadTypeIcon(
                        icon: FontAwesomeIcons.file,
                        text: "ملف",
                      ),
                    ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(top: 16.0),
                child: Text(
                  "الحد لاقصي 5",
                  style: Theme.of(context).textTheme.caption,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

//   Future<void> selectFile(BuildContext context, FileType fileType,
//       {VoidCallback onFileUploadStart,
//       Function(List<String> fileUrls) onFileSelected,
//       VoidCallback onFileUploadFailed}) async {
//     final userModel = Provider.of<UserModel>(context, listen: false);
//
//     if (userModel?.user?.cookie == null) {
//       await showDialog(
//           context: context,
//           builder: (BuildContext context) {
//             return AlertDialog(
//               content: Text(S.of(context).pleaseSignInBeforeUploading),
//               actions: [
//                 TextButton(
//                   onPressed: () {
//                     Navigator.of(context).pop();
//                   },
//                   child: Text(S.of(context).cancel),
//                 ),
//                 ElevatedButton(
//                   onPressed: () {
//                     Navigator.of(context).pop();
//                     Navigator.of(
//                       App.fluxStoreNavigatorKey.currentContext,
//                     ).pushNamed(RouteList.login);
//                   },
//                   child: Text(
//                     S.of(context).signIn,
//                     style: const TextStyle(
//                       color: Colors.white,
//                     ),
//                   ),
//                 ),
//               ],
//             );
//           });
//       return;
//     }
//
//     final result = await FilePicker.platform.pickFiles(
//       withData: true,
//       allowMultiple: (kProductAddons['allowMultiple'] ?? false),
//       type: fileType,
//       allowedExtensions: fileType == FileType.custom
//           ? kProductAddons['allowedCustomType']
//           : null,
//     );
//     if (result?.files?.isEmpty ?? true) {
//       /// Cancel select file.
//       Tools.showSnackBar(
//         Scaffold.of(context),
//         S.of(context).selectFileCancelled,
//       );
//       return;
//     }
//
//     /// Check file size limit.
//     final double fileSizeLimit = kProductAddons['fileUploadSizeLimit'] is double
//         ? kProductAddons['fileUploadSizeLimit']
//         : double.tryParse('${kProductAddons['fileUploadSizeLimit']}');
//     if (fileSizeLimit != null && fileSizeLimit > 0.0) {
//       for (var file in result.files) {
//         if (file.size > (fileSizeLimit * 1000000)) {
//           Tools.showSnackBar(
//             Scaffold.of(context),
//             S.of(context).fileIsTooBig,
//           );
//           return;
//         }
//       }
//     }
//
//     onFileUploadStart();
//
//     try {
//       final urls = <String>[];
//       for (var file in result.files) {
//         await Services().api.uploadImage({
//           'title': {'rendered': path.basename(file.path)},
//           'media_attachment': base64.encode(file.bytes)
//         }, userModel.user != null ? userModel.user.cookie : null).then((photo) {
//           urls.add(photo['guid']['rendered']);
//         });
//       }
//       onFileSelected(urls);
//     } catch (err) {
//       printLog(err);
//       onFileUploadFailed();
//
//       try {
//         Tools.showSnackBar(
//           Scaffold.of(context),
//           S.of(context).fileUploadFailed,
//         );
//       } catch (_) {}
//     }
//   }
// }
class QuantaiItem extends StatefulWidget {
  Map<String, AddonsOption> selected;
  Map<String, Map<String, AddonsOption>> selectedOptions;
  Function onSelectProductAddons;
  ProductAddons item;
  QuantaiItem(
      {this.selected,
      this.onSelectProductAddons,
      this.item,
      this.selectedOptions});
  @override
  _QuantaiItemState createState() => new _QuantaiItemState();
}

class _QuantaiItemState extends State<QuantaiItem> {
  int _itemCount = 0;
  final TextEditingController _textController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width - 100,
      height: 80,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          InkWell(
              onTap: () {
                if (_itemCount > 0) {
                  setState(() {
                    _itemCount--;
                  });

                  widget.selected[widget.item.name] = AddonsOption(
                    parent: widget.item.name,
                    label: '${widget.item.name + " " + _itemCount.toString()}',
                    price: (double.parse(widget.item.price) * _itemCount)
                        .toString(),
                  );
                  widget.onSelectProductAddons(
                      selectedOptions: widget.selectedOptions);
                }
              },
              child: const Center(
                child: Icon(
                  Icons.remove_circle_outline,
                  size: 25,
                  color: Color(0xff4f3933),
                ),
              )),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 4.0),
            height: 80,
            width: 150,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(3),
            ),
            alignment: Alignment.center,
            child: TextField(
              keyboardType: TextInputType.number,
              onChanged: (text) {
                setState(() {
                  _itemCount = int.parse(text);
                });

                {
                  setState(() {
                    widget.selected[widget.item.name] = AddonsOption(
                      parent: widget.item.name,
                      label:
                          '${widget.item.name + " " + _itemCount.toString() + ' ' + widget.item.description}',
                      price: (double.parse(widget.item.price) * _itemCount)
                          .toString(),
                    );
                  });
                }
                setState(() {
                  widget.onSelectProductAddons(
                      selectedOptions: widget.selectedOptions);
                });
              },
              textAlign: TextAlign.center,
              decoration: InputDecoration(
                hintText: "$_itemCount",

                contentPadding: const EdgeInsets.all(8),
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: Theme.of(context).primaryColor),
                  borderRadius: BorderRadius.circular(5),
                ),
                // labelText: widget.option.label,
              ),
              minLines: 1,
            ),
          ),
          // Text(
          //   '${_itemCount}',
          //   style: const TextStyle(
          //     fontSize: 18,
          //   ),
          // ),
          InkWell(
            onTap: () {
              _itemCount++;
              widget.selected[widget.item.name] = AddonsOption(
                parent: widget.item.name,
                label: '${widget.item.name + " " + _itemCount.toString()}',
                price:
                    (double.parse(widget.item.price) * _itemCount).toString(),
              );
              widget.onSelectProductAddons(
                  selectedOptions: widget.selectedOptions);
            },
            child: const Center(
              child: Icon(
                Icons.add_circle_outline_sharp,
                color: Color(0xff4f3933),
                size: 25,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _UploadTypeIcon extends StatelessWidget {
  final IconData icon;
  final String text;

  const _UploadTypeIcon({Key key, this.icon, this.text}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        if (icon != null)
          Icon(
            icon,
            size: 50,
            color: Theme.of(context).primaryColor,
          ),
        Padding(
          padding: const EdgeInsets.only(top: 8.0),
          child: Text(
            text ?? '',
            style: Theme.of(context).textTheme.subtitle2.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).accentColor,
                ),
          ),
        ),
      ],
    );
  }
}

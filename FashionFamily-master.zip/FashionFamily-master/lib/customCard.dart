import 'package:flutter/material.dart';
import 'package:fashion/caco/constants.dart';
import 'package:fashion/caco/size_config.dart';
import 'package:fashion/models/entities/product.dart';
import 'package:fashion/common/tools.dart';
import 'package:fashion/common/constants/route_list.dart';
import 'package:fashion/common/constants/general.dart';
import 'package:fashion/generated/l10n.dart';
import 'package:fashion/models/index.dart'
    show AppModel, CartModel, Product, ProductModel, RecentModel;
import 'package:provider/provider.dart';
import 'package:fashion/widgets/product/heart_button.dart';

class custoCard extends StatefulWidget {
  final Product product;

  const custoCard({
    Key key,
    this.product,
  }) : super(key: key);

  @override
  _custoCardState createState() => _custoCardState();
}

class _custoCardState extends State<custoCard> {
  bool isFavorite = false;

  @override
  Widget build(BuildContext context) {
    // print(widget.product.regularPrice);
    final String currency = Provider.of<AppModel>(context).currency;
    final Map<String, dynamic> currencyRate =
        Provider.of<AppModel>(context).currencyRate;
    return AspectRatio(
      aspectRatio: 1.5 / 2,

      child: Container(
        width: 180,
        // height: 100,
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: 10),
          child: InkWell(
            onTap: () {
              Navigator.of(
                context,
                // rootNavigator: !isBigScreen(context), // Push in tab for tablet (IPad)
              ).pushNamed(
                RouteList.productDetail,
                arguments: widget.product,
              );
            },
            child: SizedBox(
              width: getProportionateScreenWidth(150),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.max,
                children: [
                  AspectRatio(
                    aspectRatio: 1 / 1.2,
                    child: Card(
                      clipBehavior: Clip.antiAliasWithSaveLayer,
                      margin: EdgeInsets.symmetric(horizontal: 0, vertical: 10),
                      elevation: 0,
                      shadowColor: kCardBackgroundColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: GestureDetector(
                        onTap: () {
                          if (widget.product.imageFeature == '') return;
                          Provider.of<RecentModel>(context, listen: false)
                              .addRecentProduct(widget.product);
                          //Load update product detail screen for FluxBuilder
                          eventBus.fire('detail');
                          Navigator.of(
                            context,
                            // rootNavigator: !isBigScreen(context), // Push in tab for tablet (IPad)
                          ).pushNamed(
                            RouteList.productDetail,
                            arguments: widget.product,
                          );
                        },
                        child: Image.network(
                          widget.product.imageFeature,
                          fit: BoxFit.cover,
                          width: double.infinity,
                          height: double.infinity,
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Row(
                      crossAxisAlignment:
                      CrossAxisAlignment
                          .center,
                      mainAxisAlignment:
                      MainAxisAlignment
                          .start,
                      children: [
                        Expanded(
                          child: Text(
                            widget.product.name,
                            softWrap: true,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 15.5,
                              color: Colors.black,
                            ),
                          ),
                        ),
                        Row(
                          crossAxisAlignment:
                          CrossAxisAlignment
                              .center,
                          mainAxisAlignment:
                          MainAxisAlignment
                              .end,
                          children: [
                            HeartButton(
                              product: widget.product,
                              size:
                              18.0,
                            ),
                          ],
                        ),

                      ],
                    ),
                  ),
                  Row(
                    mainAxisAlignment:
                    MainAxisAlignment
                        .spaceBetween,
                    crossAxisAlignment:
                    CrossAxisAlignment
                        .center,
                    children: [
                      Row(
                        mainAxisAlignment:
                        MainAxisAlignment
                            .end,
                        crossAxisAlignment:
                        CrossAxisAlignment
                            .center,
                        children: [
                          Text(
                            '${widget.product.price}' + ' ' + S.of(context).currency ?? "0.0",
                            maxLines:
                            2,
                            overflow:
                            TextOverflow
                                .ellipsis,
                            textAlign:
                            TextAlign
                                .end,
                            style:
                            const TextStyle(
                              color: Colors
                                  .black,
                              fontWeight:
                              FontWeight.w600,
                              fontSize:
                              15,
                            ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisAlignment:
                        MainAxisAlignment
                            .end,
                        crossAxisAlignment:
                        CrossAxisAlignment
                            .center,
                        children: [
                          Padding(
                            padding: const EdgeInsets
                                .only(
                                top:
                                5),
                            child:
                            Text(
                              widget.product.averageRating.toString(),
                              maxLines:
                              2,
                              overflow:
                              TextOverflow.ellipsis,
                              textAlign:
                              TextAlign.end,
                              style:
                              const TextStyle(
                                color:
                                Colors.amber,
                                // fontWeight:
                                // FontWeight.w600,
                                fontSize:
                                13,
                              ),
                            ),
                          ),
                          Icon(
                            Icons
                                .star,
                            color: Colors
                                .amber,
                            size: 18,
                          ),
                        ],
                      ),
                    ],
                  ),

                  // Padding(
                  //   padding: const EdgeInsets.symmetric(horizontal: 5),
                  //   child: Row(
                  //     children: [
                  //       Text(
                  //         // widget.product.type != 'grouped'
                  //         //     ?
                  //         '${widget.product.price}' + 'ج.م.'?? "0.0",
                  //
                  //         //     :
                  //         // Provider.of<ProductModel>(context).detailPriceRange,
                  //         style: Theme.of(context).textTheme.subtitle1.copyWith(
                  //               fontSize: 15,
                  //               fontWeight: FontWeight.w600,
                  //               color: Theme.of(context).primaryColor,
                  //             ),
                  //       ),
                  //       // Text(
                  //       //   '\ج.م ${widget.product.regularPrice}',
                  //       //   style: TextStyle(
                  //       //     fontSize: getProportionateScreenWidth(16),
                  //       //     fontWeight: FontWeight.w600,
                  //       //     color: Colors.red,
                  //       //   ),
                  //       // ),
                  //       //
                  //
                  //       // (widget.product.salePrice != 0)
                  //       //     ? Text(
                  //       //         '\$${widget.product.salePrice}',
                  //       //         style: TextStyle(
                  //       //             fontSize: 14.5,
                  //       //             color: Colors.grey,
                  //       //             decoration: TextDecoration.lineThrough),
                  //       //       )
                  //       //
                  //     ],
                  //   ),
                  // ),
                  // SizedBox(width: 3),
                  // (widget.product.regularPrice != "")
                  //     ? Padding(
                  //         padding: const EdgeInsets.symmetric(horizontal: 5),
                  //         child: Text(
                  //           Tools.getCurrencyFormatted(
                  //             widget.product.regularPrice,
                  //             currencyRate,
                  //             currency: currency,
                  //           ),
                  //           style: Theme.of(context).textTheme.subtitle1.copyWith(
                  //                 fontSize: 12,
                  //                 color: Theme.of(context)
                  //                     .accentColor
                  //                     .withOpacity(0.6),
                  //                 fontWeight: FontWeight.w400,
                  //                 decoration: TextDecoration.lineThrough,
                  //               ),
                  //         ),
                  //       )
                  //     : Container()
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:fashion/caco/home/components/home_featured_list_item.dart';
import 'package:fashion/caco/home/components/home_special_list_item.dart';
import 'package:fashion/caco/serv/get_product.dart';
import 'package:fashion/caco/serv/getjustArivved.dart';
import 'package:fashion/caco/shimmer_product_list_item.dart';
import 'package:fashion/caco/size_config.dart';
import 'package:fashion/generated/l10n.dart';
import 'package:fashion/screens/categories/card.dart';
import 'package:fashion/screens/detail/product_description.dart';
import 'package:fashion/screens/detail/product_title.dart';
import 'package:fashion/screens/detail/product_variant.dart';
import 'package:fashion/screens/detail/review.dart';
import 'package:fashion/screens/index.dart';
import 'package:fashion/share.dart';
import 'package:fashion/tabbar.dart';
import 'package:fashion/text_field.dart';
import 'package:fashion/widgets/common/tree_view.dart';
import 'package:fashion/widgets/product/heart_button.dart';
import 'package:carousel_slider/carousel_controller.dart';
import 'package:carousel_slider/carousel_options.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_widget_from_html/src/html_widget.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:quiver/strings.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';
import 'package:showcaseview/showcaseview.dart';
import 'package:sizer/sizer.dart';
import 'package:uni_links/uni_links.dart';
import 'package:universal_platform/universal_platform.dart';
import 'package:url_launcher/url_launcher.dart';

import "../../common/config.dart";
import '../../common/constants.dart';
import '../../models/app_model.dart';
import '../../models/index.dart'
    show
        Blog,
        BlogModel,
        BlogNewsModel,
        CartModel,
        Category,
        CategoryModel,
        FilterAttributeModel,
        FilterTagModel,
        Product,
        ProductModel,
        RecentModel,
        TagModel;
import '../../models/point_model.dart';
import '../../models/user_model.dart';
import '../../screens/base.dart';
import '../../services/index.dart';
import 'deeplink_item.dart';

const SCALE_FRACTION = 0.9;
const FULL_SCALE = 1.0;
final PAGER_HEIGHT = SizeConfig.screenHeight * 0.32;
const PAGER_WIDTH = double.infinity;

class HomeScreen extends StatefulWidget {
  const HomeScreen();

  @override
  State<StatefulWidget> createState() {
    return HomeScreenState();
  }
}

class HomeScreenState extends BaseScreen<HomeScreen>
    with AutomaticKeepAliveClientMixin<HomeScreen> {
  @override
  bool get wantKeepAlive => true;

  Uri _latestUri;
  StreamSubscription _sub;
  int itemId;
  bool loading = false;
  List<Blog> blogs = [];
  List<Category> categories = [];
  List<Category> showCategories = [];
  double viewPortFraction = 0.9;
  int currentPage = 0;
  CarouselController buttonCarouselController = CarouselController();
  bool initial = true;
  double height;
  bool load = false;
  PageController pageController;
  @override
  void dispose() {
    printLog("[Home] dispose");
    _sub?.cancel();
    super.dispose();
  }

  GlobalKey _one = GlobalKey();
  var isFirstSeen;
  BuildContext myContext;
  @override
  void initState() {
    getBlogs();
    printLog("[Home] initState");
    isFirstSeen = checkFirstSeen();
    pageController = PageController(
        initialPage: currentPage, viewportFraction: viewPortFraction);

    initPlatformState();

    super.initState();
  }

  List<Category> list = [];

  Future<void> initPlatformState() async {
    if (UniversalPlatform.isAndroid || UniversalPlatform.isIOS) {
      await initPlatformStateForStringUniLinks();
    }
  }

  Future<void> initPlatformStateForStringUniLinks() async {
    // Attach a listener to the links stream
    _sub = getLinksStream().listen((String link) {
      if (!mounted) return;
      setState(() {
        _latestUri = null;
        try {
          if (link != null) _latestUri = Uri.parse(link);
          setState(() {
            itemId = int.parse(_latestUri.path.split('/')[1]);
          });

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ItemDeepLink(
                itemId: itemId,
              ),
            ),
          );
        } on FormatException {
          printLog('[initPlatformStateForStringUniLinks] error');
        }
      });
    }, onError: (err) {
      if (!mounted) return;
      setState(() {
        _latestUri = null;
      });
    });

    getLinksStream().listen((String link) {
      printLog('got link: $link');
    }, onError: (err) {
      printLog('got err: $err');
    });
  }

  @override
  void afterFirstLayout(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    printLog("[Home] afterFirstLayout");
    checkFirstSeen();
    final userModel = Provider.of<UserModel>(context, listen: false);

    if (userModel.user != null &&
        userModel.user.cookie != null &&
        kAdvanceConfig["EnableSyncCartFromWebsite"]) {
      Services().widget.syncCartFromWebsite(userModel.user.cookie, context);
    }

    if (userModel.user != null && userModel.user.cookie != null) {
      Provider.of<PointModel>(context, listen: false).getMyPoint(
          Provider.of<UserModel>(context, listen: false).user.cookie);
    }

    DynamicLinkService();
  }

  final List<String> imgList = [
    // 'https://image.freepik.com/free-vector/coffee-beans-banner-template_23-2148903660.jpg',
    // 'https://image.freepik.com/free-vector/grand-opening-coffee-banner_23-2148903661.jpg',
    // 'https://image.freepik.com/free-psd/coffee-concept-landing-page-template_23-2148615855.jpg',
  ];

  Future<List<Blog>> getBlogs({page}) async {
    try {
      var _jsons =
          await Blog.getBlogs(url: Config().blog ?? Config().url, page: 1);
      for (var item in _jsons) {
        blogs.add(Blog.fromJson(item));
      }

      if (imgList.isEmpty) {
        for (var x in blogs) imgList.add(x.imageFeature);
      }
      setState(() {
        load = true;
      });
      return blogs;
    } catch (e) {
      return [];
    }
  }

  Future<bool> checkFirstSeen() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    bool _seen = prefs.getBool('seenTips') ?? false;
    // if (_seen == false) {
    //   WidgetsBinding.instance.addPostFrameCallback(
    //       (_) => ShowCaseWidget.of(myContext).startShowCase([_one]));
    // }
    print(_seen);

    return _seen;
  }

  void _showSheet(context, product) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(30), topRight: Radius.circular(30)),
      ),
      builder: (context) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: .7,
          maxChildSize: .9,
          builder: (context, controller) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    width: 90,
                    height: 10,
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [],
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Expanded(
                  child: Center(
                    child: ListView(
                      controller: controller,
                      physics: BouncingScrollPhysics(),
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: ProductTitle(product),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 20),
                              child: ProductDescription(product),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 15, vertical: 20),
                              child: ProductVariant(product),
                            ),
                            Reviews(product.id),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  String newCategoryId;
  int _page = 1;
  bool onSale;
  String newTagId;
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);

    final String currency = Provider.of<AppModel>(context).currency;
    final Map<String, dynamic> currencyRate =
        Provider.of<AppModel>(context).currencyRate;
    super.build(context);
    var Categories = Provider.of<CategoryModel>(context);

    if (loading == true) {
      kLoadingWidget(context);
    }
    List<Category> getSubCategories(id) {
      return categories.where((o) => o.parent == id).toList();
    }

    Widget getChildCategoryList(category) {
      return ChildList(
        children: [
          for (var category in getSubCategories(category.id))
            Parent(
              parent: SubItem(category),
              childList: ChildList(
                children: [
                  for (var cate in getSubCategories(category.id))
                    Parent(
                      parent: SubItem(cate, level: 1),
                      childList: ChildList(
                        children: [
                          for (var _cate in getSubCategories(cate.id))
                            Parent(
                              parent: SubItem(_cate, level: 2),
                              childList: ChildList(children: []),
                            ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          SubItem(
            category,
            seeAll: S.of(context).seeAll,
          ),
          const Padding(
            padding: EdgeInsets.only(bottom: 0.0),
            child: Divider(
              color: Colors.red,
              endIndent: 150,
              thickness: 1,
              indent: 150,
            ),
          )
        ],
      );
    };
    return Consumer<AppModel>(
      builder: (context, value, child) {
        if (value.appConfig == null) {
          return kLoadingWidget(context);
        }
        final screenSize = MediaQuery.of(context).size;
        final product = Provider.of<GetProduct>(context, listen: false);
        final productFetured =
            Provider.of<GetProductJust>(context, listen: false);
        return Scaffold(
            backgroundColor: Colors.grey.shade200,
            body: Column(
              children: [
                SizedBox(
                  height: screenSize.height*0.03,
                ),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        elevation: 5,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => SearchScreen()));
                          },
                          child: Container(
                              height: 50,
                              width: 50,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  // border: Border.all(
                                  //     color: Theme.of(context).primaryColor,
                                  //     width: 1)
                              ),
                              child: Center(
                                  child: SvgPicture.asset(
                                'assets/fashion/search2.svg',
                                color: Color(0xfff35819),
                                fit: BoxFit.scaleDown,
                                height: 30,
                                width: 30,
                              ))),
                        ),
                      ),
                      Image.asset(
                        "assets/fashion/fashion logo app.png",
                        height: 14.0.w,
                        width: 25.0.w,
                      ),
                      Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        elevation: 5,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => CategoriesScreen()));
                          },
                          child: Container(
                            height: 50,
                            width: 50,
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                                // border: Border.all(
                                //     color: Theme.of(context).primaryColor,
                                //     width: 1)
                            ),
                            child: Center(
                              child: Text(
                                '...',
                                style: TextStyle(
                                    color: Color(0xfff35819),
                                    fontSize: 25,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Row(
                  children: [
                    buildContainerCategory(Categories),
                  ],
                ),
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        color: Colors.white),
                    child: ListView(
                      physics: const BouncingScrollPhysics(),
                      children: [
                        // const SizedBox(
                        //   height: 10,
                        // ),
                        buildBanner(),
                        // Padding(
                        //   padding: const EdgeInsets.only(
                        //     top: 20,
                        //     bottom: 10,
                        //   ),
                        //   child: Row(
                        //     mainAxisAlignment: MainAxisAlignment.start,
                        //     children: [
                        //       const Padding(
                        //         padding: EdgeInsets.symmetric(horizontal: 20),
                        //         child: Text(
                        //           'تسوق الفئات',
                        //           style: TextStyle(
                        //               fontSize: 18,
                        //               fontWeight: FontWeight.bold),
                        //         ),
                        //       ),
                        //       Expanded(
                        //           child: Divider(
                        //         indent: .5,
                        //         height: .4,
                        //         endIndent: .9,
                        //         thickness: .5,
                        //         color: Color(0xff4f3933).withOpacity(.9),
                        //       ))
                        //     ],
                        //   ),
                        // ),
                        // buildContainerCategory(Categories),
                        // const SizedBox(
                        //   height: 10,
                        // ),
                        // const SizedBox(
                        //   height: 15,
                        // ),
                        // ShowCaseWidget(
                        //     onFinish: () async {
                        //       var prefs =
                        //           await SharedPreferences.getInstance();
                        //       await prefs.setBool('seenTips', true);
                        //     },
                        //     autoPlayDelay: const Duration(milliseconds: 2000),
                        //     autoPlayLockEnable: true,
                        //     builder: Builder(builder: (c) {
                        //       myContext = c;
                        //       print(isFirstSeen);
                        //
                        //       return Showcase(
                        //         key: _one,
                        //         title: 'جديد',
                        //
                        //         disableAnimation: false,
                        //         // shapeBorder:
                        //         //     CircleBorder(side: ),
                        //         showArrow: true,
                        //         overlayColor: Colors.black,
                        //         description: 'اعمل توليفتك الخاصة من البن ',
                        //         child: Row(
                        //           mainAxisAlignment: MainAxisAlignment.start,
                        //           children: [
                        //             const Padding(
                        //               padding: EdgeInsets.symmetric(
                        //                   horizontal: 20),
                        //               child: Text(
                        //                 ' اصنع توليفتك بنفسك',
                        //                 style: TextStyle(
                        //                     fontSize: 18,
                        //                     fontWeight: FontWeight.bold),
                        //               ),
                        //             ),
                        //             Expanded(
                        //                 child: Divider(
                        //               indent: .5,
                        //               height: .4,
                        //               endIndent: .9,
                        //               thickness: .5,
                        //               color:
                        //                   Color(0xff4f3933).withOpacity(.9),
                        //             ))
                        //           ],
                        //         ),
                        //       );
                        //     })),
                        // const SizedBox(
                        //   height: 3,
                        // ),
                        // ListenableProvider.value(
                        //     value: product,
                        //     child: Consumer<GetProduct>(
                        //         builder: (context, value, child) {
                        //       if (value.isFetching == false) {
                        //         return ListView.builder(
                        //             primary: false,
                        //             padding: const EdgeInsets.symmetric(
                        //                 vertical: 5, horizontal: 0),
                        //             physics:
                        //                 const NeverScrollableScrollPhysics(),
                        //             shrinkWrap: true,
                        //             scrollDirection: Axis.vertical,
                        //             itemCount: 1,
                        //             itemBuilder: (context, index) {
                        //               return InkWell(
                        //                   onTap: () {
                        //                     Navigator.of(
                        //                       context,
                        //                       rootNavigator: true,
                        //                       // rootNavigator: !isBigScreen(context),
                        //                       // Push in tab for tablet (IPad)
                        //                     ).pushNamed(
                        //                       RouteList.productDetail,
                        //                       arguments:
                        //                           value.futcherProduct[index],
                        //                     );
                        //                     // _showSheet(
                        //                     //     context,
                        //                     //     value.futcherProduct[
                        //                     //         index]);
                        //                   },
                        //                   child: Container(
                        //                     margin:
                        //                         const EdgeInsets.symmetric(
                        //                             horizontal: 10,
                        //                             vertical: 5),
                        //                     decoration: BoxDecoration(
                        //                         color: Colors.white,
                        //                         boxShadow: [
                        //                           BoxShadow(
                        //                             color: Colors.grey
                        //                                 .withOpacity(0.1),
                        //                             spreadRadius: 5,
                        //                             blurRadius: 7,
                        //                             offset: const Offset(0,
                        //                                 3), // changes position of shadow
                        //                           ),
                        //                         ],
                        //                         borderRadius:
                        //                             BorderRadius.circular(
                        //                                 10)),
                        //                     child: Row(
                        //                       crossAxisAlignment:
                        //                           CrossAxisAlignment.center,
                        //                       mainAxisAlignment:
                        //                           MainAxisAlignment.start,
                        //                       children: [
                        //                         Container(
                        //                           height: 150,
                        //                           width: 100,
                        //                           margin: const EdgeInsets
                        //                                   .symmetric(
                        //                               horizontal: 5,
                        //                               vertical: 5),
                        //                           child: Padding(
                        //                             padding:
                        //                                 const EdgeInsets.all(
                        //                                     2.0),
                        //                             child: ClipRRect(
                        //                                 borderRadius:
                        //                                     BorderRadius
                        //                                         .circular(10),
                        //                                 child: Image.network(
                        //                                   value
                        //                                       .futcherProduct[
                        //                                           index]
                        //                                       .imageFeature,
                        //                                   fit: BoxFit.cover,
                        //                                   width:
                        //                                       double.infinity,
                        //                                   height:
                        //                                       double.infinity,
                        //                                 )),
                        //                           ),
                        //                         ),
                        //                         Expanded(
                        //                           child: Padding(
                        //                             padding: const EdgeInsets
                        //                                     .symmetric(
                        //                                 vertical: 10,
                        //                                 horizontal: 5),
                        //                             child: Column(
                        //                               crossAxisAlignment:
                        //                                   CrossAxisAlignment
                        //                                       .start,
                        //                               mainAxisAlignment:
                        //                                   MainAxisAlignment
                        //                                       .spaceBetween,
                        //                               children: [
                        //                                 Row(
                        //                                   crossAxisAlignment:
                        //                                       CrossAxisAlignment
                        //                                           .center,
                        //                                   mainAxisAlignment:
                        //                                       MainAxisAlignment
                        //                                           .start,
                        //                                   children: [
                        //                                     Expanded(
                        //                                       flex: 5,
                        //                                       child: Row(
                        //                                         crossAxisAlignment:
                        //                                             CrossAxisAlignment
                        //                                                 .start,
                        //                                         mainAxisAlignment:
                        //                                             MainAxisAlignment
                        //                                                 .start,
                        //                                         children: [
                        //                                           Expanded(
                        //                                             child:
                        //                                                 Text(
                        //                                               value
                        //                                                   .futcherProduct[index]
                        //                                                   .name,
                        //                                               maxLines:
                        //                                                   1,
                        //                                               overflow:
                        //                                                   TextOverflow.ellipsis,
                        //                                               textAlign:
                        //                                                   TextAlign.start,
                        //                                               style:
                        //                                                   const TextStyle(
                        //                                                 color:
                        //                                                     Colors.black,
                        //                                                 fontWeight:
                        //                                                     FontWeight.bold,
                        //                                                 fontSize:
                        //                                                     15,
                        //                                               ),
                        //                                             ),
                        //                                           ),
                        //                                         ],
                        //                                       ),
                        //                                     ),
                        //                                     Expanded(
                        //                                       flex: 2,
                        //                                       child: Row(
                        //                                         crossAxisAlignment:
                        //                                             CrossAxisAlignment
                        //                                                 .center,
                        //                                         mainAxisAlignment:
                        //                                             MainAxisAlignment
                        //                                                 .end,
                        //                                         children: [
                        //                                           HeartButton(
                        //                                             product: value
                        //                                                     .futcherProduct[
                        //                                                 index],
                        //                                             size:
                        //                                                 18.0,
                        //                                           ),
                        //                                         ],
                        //                                       ),
                        //                                     ),
                        //                                   ],
                        //                                 ),
                        //                                 HtmlWidget(
                        //                                   value
                        //                                       .futcherProduct[
                        //                                           index]
                        //                                       .description
                        //                                       .replaceAll(
                        //                                           'src="//',
                        //                                           'src="https://'),
                        //                                   webView: false,
                        //                                   textStyle:
                        //                                       TextStyle(
                        //                                     fontSize: 13,
                        //                                   ),
                        //                                 ),
                        //                                 const SizedBox(
                        //                                   height: 5,
                        //                                 ),
                        //                                 Row(
                        //                                   mainAxisAlignment:
                        //                                       MainAxisAlignment
                        //                                           .spaceBetween,
                        //                                   crossAxisAlignment:
                        //                                       CrossAxisAlignment
                        //                                           .center,
                        //                                   children: [
                        //                                     Row(
                        //                                       mainAxisAlignment:
                        //                                           MainAxisAlignment
                        //                                               .end,
                        //                                       crossAxisAlignment:
                        //                                           CrossAxisAlignment
                        //                                               .center,
                        //                                       children: [
                        //                                         value
                        //                                                 .futcherProduct[
                        //                                                     index]
                        //                                                 .name
                        //                                                 .contains(
                        //                                                     "اصنع توليفتك")
                        //                                             ? SizedBox()
                        //                                             : Text(
                        //                                                 value.futcherProduct[index].price +
                        //                                                     " جنية",
                        //                                                 maxLines:
                        //                                                     2,
                        //                                                 overflow:
                        //                                                     TextOverflow.ellipsis,
                        //                                                 textAlign:
                        //                                                     TextAlign.end,
                        //                                                 style:
                        //                                                     const TextStyle(
                        //                                                   color:
                        //                                                       Colors.black,
                        //                                                   // fontWeight:
                        //                                                   // FontWeight.w600,
                        //                                                   fontSize:
                        //                                                       13,
                        //                                                 ),
                        //                                               ),
                        //                                       ],
                        //                                     ),
                        //                                     Row(
                        //                                       mainAxisAlignment:
                        //                                           MainAxisAlignment
                        //                                               .end,
                        //                                       crossAxisAlignment:
                        //                                           CrossAxisAlignment
                        //                                               .center,
                        //                                       children: [
                        //                                         Padding(
                        //                                           padding: const EdgeInsets
                        //                                                   .only(
                        //                                               top: 5),
                        //                                           child: Text(
                        //                                             value
                        //                                                 .futcherProduct[
                        //                                                     index]
                        //                                                 .averageRating
                        //                                                 .toString(),
                        //                                             maxLines:
                        //                                                 2,
                        //                                             overflow:
                        //                                                 TextOverflow
                        //                                                     .ellipsis,
                        //                                             textAlign:
                        //                                                 TextAlign
                        //                                                     .end,
                        //                                             style:
                        //                                                 const TextStyle(
                        //                                               color: Colors
                        //                                                   .amber,
                        //                                               // fontWeight:
                        //                                               // FontWeight.w600,
                        //                                               fontSize:
                        //                                                   13,
                        //                                             ),
                        //                                           ),
                        //                                         ),
                        //                                         Icon(
                        //                                           Icons.star,
                        //                                           color: Colors
                        //                                               .amber,
                        //                                           size: 18,
                        //                                         ),
                        //                                       ],
                        //                                     ),
                        //                                   ],
                        //                                 ),
                        //                               ],
                        //                             ),
                        //                           ),
                        //                         ),
                        //                       ],
                        //                     ),
                        //                   ));
                        //             });
                        //       } else if (value.isFetching == true) {
                        //         return ListView.separated(
                        //           itemCount: 1,
                        //           physics: NeverScrollableScrollPhysics(),
                        //           padding: const EdgeInsets.all(0),
                        //           shrinkWrap: true,
                        //           itemBuilder: (context, index) {
                        //             return Shimmer.fromColors(
                        //               period: Duration(milliseconds: 300),
                        //               baseColor: Color(0xff4f3933),
                        //               highlightColor: Colors.white,
                        //               child: Container(
                        //                 height: 120.0,
                        //                 width: screenSize.width,
                        //                 padding: const EdgeInsets.all(8.0),
                        //                 margin: const EdgeInsets.symmetric(
                        //                   horizontal: 16.0,
                        //                 ),
                        //                 decoration: BoxDecoration(
                        //                   color:
                        //                       Colors.black.withOpacity(0.1),
                        //                   borderRadius:
                        //                       BorderRadius.circular(15.0),
                        //                 ),
                        //                 child: Column(
                        //                   children: <Widget>[
                        //                     Expanded(
                        //                       child: Row(
                        //                         children: <Widget>[
                        //                           Container(
                        //                             width: 104.0,
                        //                             decoration: BoxDecoration(
                        //                               color: Colors.blue
                        //                                   .withOpacity(0.1),
                        //                               borderRadius:
                        //                                   BorderRadius
                        //                                       .circular(11.0),
                        //                             ),
                        //                           ),
                        //                           SizedBox(
                        //                             width: 12.0,
                        //                           ),
                        //                           Expanded(
                        //                             flex: 2,
                        //                             child: Column(
                        //                               crossAxisAlignment:
                        //                                   CrossAxisAlignment
                        //                                       .start,
                        //                               mainAxisAlignment:
                        //                                   MainAxisAlignment
                        //                                       .spaceEvenly,
                        //                               mainAxisSize:
                        //                                   MainAxisSize.max,
                        //                               children: <Widget>[
                        //                                 Row(
                        //                                   children: <Widget>[
                        //                                     Expanded(
                        //                                       child:
                        //                                           Container(
                        //                                         height: 25.0,
                        //                                         decoration:
                        //                                             BoxDecoration(
                        //                                           color: Colors
                        //                                               .white
                        //                                               .withOpacity(
                        //                                                   0.3),
                        //                                           borderRadius:
                        //                                               BorderRadius.circular(
                        //                                                   8.0),
                        //                                         ),
                        //                                       ),
                        //                                     ),
                        //                                     SizedBox(
                        //                                       width: 20.0,
                        //                                     ),
                        //                                     // Container(
                        //                                     //   height: 25.0,
                        //                                     //   width: 28.0,
                        //                                     //   decoration: BoxDecoration(
                        //                                     //     color: Colors.black.withOpacity(0.3),
                        //                                     //     borderRadius: BorderRadius.circular(8.0),
                        //                                     //   ),
                        //                                     // ),
                        //                                   ],
                        //                                 ),
                        //                                 SizedBox(
                        //                                   height: 8.0,
                        //                                 ),
                        //                                 Container(
                        //                                   height: 23.0,
                        //                                   width: screenSize
                        //                                           .width *
                        //                                       0.2,
                        //                                   decoration:
                        //                                       BoxDecoration(
                        //                                     color: Colors
                        //                                         .white
                        //                                         .withOpacity(
                        //                                             0.3),
                        //                                     borderRadius:
                        //                                         BorderRadius
                        //                                             .circular(
                        //                                                 8.0),
                        //                                   ),
                        //                                 ),
                        //                                 Expanded(
                        //                                     child:
                        //                                         SizedBox()),
                        //                                 Padding(
                        //                                   padding:
                        //                                       const EdgeInsets
                        //                                               .only(
                        //                                           bottom: 3.0,
                        //                                           right: 3.0),
                        //                                   child: Row(
                        //                                     mainAxisAlignment:
                        //                                         MainAxisAlignment
                        //                                             .spaceBetween,
                        //                                     mainAxisSize:
                        //                                         MainAxisSize
                        //                                             .max,
                        //                                     crossAxisAlignment:
                        //                                         CrossAxisAlignment
                        //                                             .end,
                        //                                     children: <
                        //                                         Widget>[
                        //                                       Container(
                        //                                         height: 26.0,
                        //                                         width: 50.0,
                        //                                         decoration:
                        //                                             BoxDecoration(
                        //                                           color: Colors
                        //                                               .white
                        //                                               .withOpacity(
                        //                                                   0.3),
                        //                                           borderRadius:
                        //                                               BorderRadius.circular(
                        //                                                   8.0),
                        //                                         ),
                        //                                       ),
                        //                                       Row(
                        //                                         children: <
                        //                                             Widget>[
                        //                                           Container(
                        //                                             height:
                        //                                                 26.0,
                        //                                             width:
                        //                                                 100.0,
                        //                                             decoration:
                        //                                                 BoxDecoration(
                        //                                               color: Colors
                        //                                                   .white
                        //                                                   .withOpacity(0.3),
                        //                                               borderRadius:
                        //                                                   BorderRadius.circular(8.0),
                        //                                             ),
                        //                                           ),
                        //                                         ],
                        //                                       ),
                        //                                     ],
                        //                                   ),
                        //                                 ),
                        //                               ],
                        //                             ),
                        //                           ),
                        //                         ],
                        //                       ),
                        //                     ),
                        //                   ],
                        //                 ),
                        //               ),
                        //             );
                        //           },
                        //           separatorBuilder: (context, index) {
                        //             return SizedBox(height: 20.0);
                        //           },
                        //         );
                        //       } else {
                        //         return Container(
                        //           child: const Center(
                        //             child: Text("فشل التحميل"),
                        //           ),
                        //         );
                        //       }
                        //     })),
                        // const SizedBox(
                        //   height: 3,
                        // ),
                        const SizedBox(
                          height: 15,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 50,
                                    height: 50,
                                    decoration: BoxDecoration(
                                      color: Theme.of(context).primaryColor.withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(10),

                                    ),
                                    child: SvgPicture.asset('assets/fashion/fire2.svg',fit: BoxFit.scaleDown,color: Color(0xfff35819))
                                  ),
                                  SizedBox(width: 10,),
                                  Text(
                                    S.of(context).latestDeals,
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                              InkWell(
                                onTap: () {
                                  // Navigator.push(context, MaterialPageRoute(builder: (context)=> CategoriesScreen(
                                  //
                                  // ) ));
                                  ProductModel.showList(
                                    context: context,
                                    cateId: 115.toString(),
                                    cateName: "أحدث العروض",
                                  );
                                },
                                child: Text(
                                  S.of(context).seeMore,
                                  style: TextStyle(
                                    color: Theme.of(context).primaryColor,
                                    fontSize: 15
                                  ),
                                ),
                              ),
                              // Expanded(
                              //     child: Divider(
                              //   indent: .5,
                              //   height: .4,
                              //   endIndent: .9,
                              //   thickness: .5,
                              //   color: Color(0xff4f3933).withOpacity(.9),
                              // ))
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 3,
                        ),
                        ListenableProvider.value(
                            value: productFetured,
                            child: Consumer<GetProductJust>(
                                builder: (context, value, child) {
                              if (value.isFetching == false) {
                                var productF = value.futcherProduct;
                                return GridView.builder(
                                    gridDelegate:
                                      SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 2,
                                      crossAxisSpacing: 1,
                                      mainAxisSpacing: 1,
                                      childAspectRatio: 1.5 / 2,
                                    ),
                                    primary: false,
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 0),
                                    physics:
                                        const NeverScrollableScrollPhysics(),
                                    shrinkWrap: true,
                                    scrollDirection: Axis.vertical,
                                    itemCount: 6,
                                    itemBuilder: (context, index) {
                                      return InkWell(
                                          onTap: () {
                                            // Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=>ProductsPage(
                                            //   categoryId: value.categoryId,
                                            // )));
                                            Navigator.of(
                                              context,
                                              rootNavigator: true,
                                              // rootNavigator: !isBigScreen(context),
                                              // Push in tab for tablet (IPad)
                                            ).pushNamed(
                                              RouteList.productDetail,
                                              arguments: productF[index],
                                            );

                                            // _showSheet(
                                            //     context,
                                            //     value.futcherProduct[
                                            //     index]);
                                          },
                                          child: Container(
                                            margin:
                                                const EdgeInsets.only(left: 5,right: 5,top: 10),
                                            decoration: BoxDecoration(
                                                color: Colors.white,
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Colors.grey
                                                        .withOpacity(0.1),
                                                    spreadRadius: 5,
                                                    blurRadius: 7,
                                                    offset: const Offset(0,
                                                        3), // changes position of shadow
                                                  ),
                                                ],
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        10)),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Expanded(
                                                  child: Container(
                                                    height: 150,
                                                    width: 200,
                                                    margin: const EdgeInsets
                                                            .symmetric(
                                                        horizontal: 5,
                                                        ),
                                                    child: Padding(
                                                      padding: const EdgeInsets.only(top: 5),
                                                      child: ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      10),
                                                          child:
                                                              Image.network(
                                                            productF[index]
                                                                .imageFeature,
                                                            fit: BoxFit.cover,
                                                            width: double
                                                                .infinity,
                                                            height: double
                                                                .infinity,
                                                          )),
                                                    ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding: const EdgeInsets.symmetric(horizontal: 5),
                                                  child: Row(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      Flexible(
                                                        child: Text(
                                                            productF[index]
                                                          .name,
                                                            maxLines:
                                                          1,
                                                            overflow:
                                                          TextOverflow.ellipsis,
                                                            textAlign:
                                                          TextAlign.start,
                                                            style:
                                                          const TextStyle(
                                                        color:
                                                            Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize:
                                                            15,
                                                            ),
                                                          ),
                                                      ),
                                                      HeartButton(
                                                        product:
                                                        productF[index],
                                                        size:
                                                        18.0,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                // HtmlWidget(
                                                //   productF[index]
                                                //       .description
                                                //       .replaceAll(
                                                //           'src="//',
                                                //           'src="https://'),
                                                //   webView: false,
                                                //   textStyle:
                                                //       TextStyle(
                                                //     fontSize: 13,
                                                //   ),
                                                // ),
                                                const SizedBox(
                                                  height: 5,
                                                ),
                                                Padding(
                                                  padding: const EdgeInsets.only(left: 5,right: 5,bottom: 5),
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    children: [
                                                      Text(
                                                        productF[index]
                                                                .price +
                                                            "  " + S.of(context).currency,
                                                        maxLines:
                                                            2,
                                                        overflow:
                                                            TextOverflow
                                                                .ellipsis,
                                                        textAlign:
                                                            TextAlign
                                                                .end,
                                                        style:
                                                            const TextStyle(
                                                          color: Colors
                                                              .black,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontSize:
                                                              15,
                                                        ),
                                                      ),
                                                      Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Text(
                                                              productF[index]
                                                            .averageRating
                                                            .toString(),
                                                              maxLines:
                                                            1,
                                                              overflow:
                                                            TextOverflow.ellipsis,
                                                              textAlign:
                                                            TextAlign.end,
                                                              style:
                                                            const TextStyle(
                                                          color:
                                                              Colors.amber,
                                                          // fontWeight:
                                                          // FontWeight.w600,
                                                          fontSize:
                                                              13,
                                                              ),
                                                            ),
                                                          Icon(
                                                            Icons
                                                                .star,
                                                            color: Colors
                                                                .amber,
                                                            size: 18,
                                                          ),

                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ));
                                    });
                              } else if (value.isFetching == true) {
                                return GridView.builder(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 6, horizontal: 6),
                                    physics: const BouncingScrollPhysics(),
                                    shrinkWrap: true,
                                    itemCount: 6,
                                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 2,
                                      crossAxisSpacing: 1,
                                      mainAxisSpacing: 1,
                                      childAspectRatio: 1.5 / 2,
                                    ),
                                    itemBuilder: (context, index) {
                                      return Container(
                                        height: 150,
                                        child: Shimmer.fromColors(
                                          period: Duration(milliseconds: 300),
                                          baseColor: Colors.black,
                                          highlightColor: Colors.white,
                                          child: Container(
                                            width: 150.0,
                                            height: 120,
                                            child: ShimmerProductListItem(),
                                          ),
                                        ),
                                      );
                                    });
                              } else
                                return null;
                            })),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Container(
                                      width: 50,
                                      height: 50,
                                      decoration: BoxDecoration(
                                        color: Theme.of(context).primaryColor.withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(10),

                                      ),
                                      child: SvgPicture.asset('assets/fashion/star2.svg',fit: BoxFit.scaleDown,color: Color(0xfff35819))
                                  ),
                                  SizedBox(width: 10,),
                                  Text(
                                    S.of(context).topSelling,
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                              InkWell(
                                onTap: () {
                                  // Navigator.push(context, MaterialPageRoute(builder: (context)=> CategoriesScreen(
                                  //
                                  // ) ));
                                  ProductModel.showList(
                                    context: context,
                                    cateId: 116.toString(),
                                    cateName: "الاكثر مبيعاً",
                                  );
                                },
                                child: Text(
                                  S.of(context).seeMore,
                                  style: TextStyle(
                                      color: Theme.of(context).primaryColor,
                                      fontSize: 15
                                  ),
                                ),
                              ),
                              // Expanded(
                              //     child: Divider(
                              //   indent: .5,
                              //   height: .4,
                              //   endIndent: .9,
                              //   thickness: .5,
                              //   color: Color(0xff4f3933).withOpacity(.9),
                              // ))
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 3,
                        ),
                        ListenableProvider.value(
                            value: product,
                            child: Consumer<GetProduct>(
                                builder: (context, value, child) {
                                  if (value.isFetching == false) {
                                    var fetPro = value.futcherProduct;
                                    return GridView.builder(
                                        gridDelegate:
                                        SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 2,
                                          crossAxisSpacing: 1,
                                          mainAxisSpacing: 1,
                                          childAspectRatio: 1.5 / 2.1,
                                        ),
                                        primary: false,
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 5, horizontal: 0),
                                        physics:
                                        const NeverScrollableScrollPhysics(),
                                        shrinkWrap: true,
                                        scrollDirection: Axis.vertical,
                                        itemCount: 6,
                                        itemBuilder: (context, index) {
                                          return InkWell(
                                              onTap: () {
                                                // Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=>ProductsPage(
                                                //   categoryId: value.categoryId,
                                                // )));
                                                Navigator.of(
                                                  context,
                                                  rootNavigator: true,
                                                  // rootNavigator: !isBigScreen(context),
                                                  // Push in tab for tablet (IPad)
                                                ).pushNamed(
                                                  RouteList.productDetail,
                                                  arguments: fetPro[index],
                                                );

                                                // _showSheet(
                                                //     context,
                                                //     value.futcherProduct[
                                                //     index]);
                                              },
                                              child: Container(
                                                margin:
                                                const EdgeInsets.only(left: 5,right: 5,top: 10),
                                                decoration: BoxDecoration(
                                                    color: Colors.white,
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: Colors.grey
                                                            .withOpacity(0.1),
                                                        spreadRadius: 5,
                                                        blurRadius: 7,
                                                        offset: const Offset(0,
                                                            3), // changes position of shadow
                                                      ),
                                                    ],
                                                    borderRadius:
                                                    BorderRadius.circular(
                                                        10)),
                                                child: Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                                  children: [
                                                    Expanded(
                                                      child: Container(
                                                        height: 150,
                                                        width: 200,
                                                        margin: const EdgeInsets
                                                            .symmetric(
                                                          horizontal: 5,
                                                        ),
                                                        child: Padding(
                                                          padding: const EdgeInsets.only(top: 5),
                                                          child: ClipRRect(
                                                              borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                  10),
                                                              child:
                                                              Image.network(
                                                                fetPro[index]
                                                                    .imageFeature,
                                                                fit: BoxFit.cover,
                                                                width: double
                                                                    .infinity,
                                                                height: double
                                                                    .infinity,
                                                              )),
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: const EdgeInsets.symmetric(horizontal: 5),
                                                      child: Row(
                                                        crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                        mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                        children: [
                                                          Flexible(
                                                            child: Text(
                                                              fetPro[index]
                                                                  .name,
                                                              maxLines:
                                                              1,
                                                              overflow:
                                                              TextOverflow.ellipsis,
                                                              textAlign:
                                                              TextAlign.start,
                                                              style:
                                                              const TextStyle(
                                                                color:
                                                                Colors.black,
                                                                fontWeight:
                                                                FontWeight.bold,
                                                                fontSize:
                                                                15,
                                                              ),
                                                            ),
                                                          ),
                                                          HeartButton(
                                                            product:
                                                            fetPro[index],
                                                            size:
                                                            18.0,
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    // HtmlWidget(
                                                    //   productF[index]
                                                    //       .description
                                                    //       .replaceAll(
                                                    //           'src="//',
                                                    //           'src="https://'),
                                                    //   webView: false,
                                                    //   textStyle:
                                                    //       TextStyle(
                                                    //     fontSize: 13,
                                                    //   ),
                                                    // ),
                                                    const SizedBox(
                                                      height: 5,
                                                    ),
                                                    Padding(
                                                      padding: const EdgeInsets.only(left: 5,right: 5,bottom: 5),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                        crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                        children: [
                                                          Text(
                                                            fetPro[index]
                                                                .price +
                                                                "  " + S.of(context).currency,
                                                            maxLines:
                                                            2,
                                                            overflow:
                                                            TextOverflow
                                                                .ellipsis,
                                                            textAlign:
                                                            TextAlign
                                                                .end,
                                                            style:
                                                            const TextStyle(
                                                              color: Colors
                                                                  .black,
                                                              fontWeight:
                                                              FontWeight.w600,
                                                              fontSize:
                                                              15,
                                                            ),
                                                          ),
                                                          Row(
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              Text(
                                                                fetPro[index]
                                                                    .averageRating
                                                                    .toString(),
                                                                maxLines:
                                                                1,
                                                                overflow:
                                                                TextOverflow.ellipsis,
                                                                textAlign:
                                                                TextAlign.end,
                                                                style:
                                                                const TextStyle(
                                                                  color:
                                                                  Colors.amber,
                                                                  // fontWeight:
                                                                  // FontWeight.w600,
                                                                  fontSize:
                                                                  13,
                                                                ),
                                                              ),
                                                              Icon(
                                                                Icons
                                                                    .star,
                                                                color: Colors
                                                                    .amber,
                                                                size: 18,
                                                              ),

                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ));
                                        });
                                  } else if (value.isFetching == true) {
                                    return GridView.builder(
                                      padding: const EdgeInsets.all(0),
                                      physics:
                                      const NeverScrollableScrollPhysics(),
                                      gridDelegate:
                                      const SliverGridDelegateWithFixedCrossAxisCount(
                                        crossAxisCount: 3,
                                        childAspectRatio: 1 / 1.25,
                                        mainAxisSpacing: 16.0,
                                        crossAxisSpacing: 16.0,
                                      ),
                                      itemCount: 6,
                                      itemBuilder: (context, index) {
                                        return Container(
                                          width: double.infinity - 100,
                                          height: 500,
                                          child: Shimmer.fromColors(
                                              period: const Duration(
                                                  milliseconds: 300),
                                              baseColor: Colors.black,
                                              highlightColor: Colors.white,
                                              child: ShimmerProductListItem()),
                                        );
                                      },
                                    );
                                  } else
                                    return null;
                                })),
                      ],
                    ),
                  ),
                ),

              ],
            ),
          floatingActionButton: Padding(
            padding: Platform.isIOS ?  EdgeInsets.only(bottom:90) : EdgeInsets.only(bottom:60),
            child: SpeedDial(
              foregroundColor: Theme.of(context).primaryColor,
              backgroundColor: Colors.white,
              icon: Icons.phone_rounded,
              activeIcon: Icons.dangerous,
              children: [
                SpeedDialChild(
                    backgroundColor: Colors.transparent,
                    child: SvgPicture.asset('assets/icons/phonee.svg'),
                    label: 'اتصل بنا',
                    onTap: (){ShareFunction().launchCaller();}),
                SpeedDialChild(
                    backgroundColor: Colors.transparent,

                    child: SvgPicture.asset('assets/icons/whatsapp.svg'),
                    label: 'واتساب',
                    onTap: (){ShareFunction().launchWhatApp();}),
                SpeedDialChild(
                    backgroundColor: Colors.transparent,

                    child: SvgPicture.asset('assets/icons/messenger.svg'),
                    label: 'ماسنجر',
                    onTap: (){ShareFunction().launchMessanger();}),
                SpeedDialChild(
                    backgroundColor: Colors.transparent,

                    child: SvgPicture.asset('assets/icons/ig.svg'),
                    label: 'انستجرام',
                    onTap: () {
                      ShareFunction().launchInstagram();
                    }
                ),
                SpeedDialChild(
                    backgroundColor: Colors.transparent,

                    child: SvgPicture.asset('assets/icons/tiktok.svg'),
                    label: 'تيك توك',
                    onTap: () {
                      ShareFunction().launchTiktok();
                    }
                ),
                SpeedDialChild(
                    backgroundColor: Colors.transparent,

                    child: SvgPicture.asset('assets/icons/facebook.svg'),
                    label: 'صفحة الفيس بوك',
                    onTap: () {
                      ShareFunction().launchFacebook();
                    }
                ),

              ],
            ),
          ),
        );
      },
    );
  }


  Container buildContainerCategory(CategoryModel Categories) {
    return Container(
      height: 18.0.w,
      width: 100.0.w,
      child: Padding(
        padding: const EdgeInsets.only(top: 10, bottom: 10),
        child: ListenableProvider.value(
            value: Categories,
            child: Consumer<CategoryModel>(builder: (context, value, child) {
              if (value.isLoading == true) {
                return Center(
                  child: ListView.builder(
                    padding: const EdgeInsets.all(0),
                    physics: const NeverScrollableScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    itemCount: 4,
                    itemBuilder: (context, index) {
                      return Container(
                        height: 15.0.w,
                        width: 30.0.w,
                        child: Shimmer.fromColors(
                            period: const Duration(milliseconds: 300),
                            highlightColor: Colors.white,
                            baseColor: Theme.of(context).primaryColor,
                            // child: ShimmerProductListItem()
                        ),
                      );
                    },
                  ),
                );
              } else if (value.isLoading == false) {
                // categories = value.categories;
                categories = value.categories
                    .where((item) => item.id != "115" && item.id != "116").toList();
                var data=[
                  86,
                  112,
                  117,
                  118,
                  114,

                ];
                var dataName=[
                  "رجالي",
                  "حريمي",
                  "أطفال",
                  "أحذية",
                  "إكسسوارات",

                ];
                return ListView.builder(
                  padding: const EdgeInsets.only(right: 5),
                  scrollDirection: Axis.horizontal,
                  itemCount: data.length,
                  itemBuilder: (context, index) {
                     return InkWell(
                      onTap: () {
                          ProductModel.showList(
                          context: context,
                          cateId: data[index].toString(),
                          cateName: dataName[index],
                          );
                      },
                      child: Container(
                        height: 15.0.w,
                        width: 30.0.w,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(color: Theme.of(context).primaryColor, width: 1),
                          borderRadius: BorderRadius.all(
                            Radius.circular(10),
                          ),
                        ),
                        margin: EdgeInsets.symmetric(horizontal: 5),
                        child: Align(
                          alignment: Alignment.center,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10.0),
                            child: Container(
                              // color: Colors.black.withOpacity(.1),
                              alignment: Alignment.center,
                              child: Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(0.0),
                                  child: Text(
                                    dataName[index],
                                    style:  TextStyle(
                                        color: Theme.of(context).primaryColor,
                                        fontSize: 13,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                );
              } else {
                return Container(
                  child: const Center(
                    child: Text("فشل التحميل"),
                  ),
                );
              }
            })),
      ),
    );
  }

  Widget buildBanner() {
    return (load == true)
        ? Container(
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.all(
                Radius.circular(30),
              ),
            ),
            width: double.infinity,
            height: 30.0.h,
            child: CarouselSlider(
              options: CarouselOptions(
                  viewportFraction: 0.9,
                  autoPlay: true,
                  aspectRatio: 1.5,
                  enlargeCenterPage: true,
                  autoPlayCurve: Curves.easeInOutSine),
              items: imgList
                  .map((item) => Container(
                        child: Container(
                            margin: const EdgeInsets.all(5.0),
                            child: ClipRRect(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(15.0)),
                                child: Image.network(item,
                                    fit: BoxFit.cover, width: 1000))),
                      ))
                  .toList(),
            ),
          )
        : Shimmer.fromColors(
            period: Duration(milliseconds: 300),
            baseColor: Colors.black,
            highlightColor: Colors.black.withOpacity(0.5),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 10),
              height: 30.0.h,
              width: double.infinity,
              child: AspectRatio(
                aspectRatio: 1 / 1,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(15.0),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: Container(
                          height: 250.0,
                          decoration: BoxDecoration(
                            color: Theme.of(context).primaryColor.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
  }

  Widget _renderItemCategory(
      {String categoryId, String categoryName, String categoryPhoto}) {
    print("${categoryId}============>");
    return GestureDetector(
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.symmetric(horizontal: 3, vertical: 7),
        decoration: BoxDecoration(
          // color: newCategoryId == categoryId ? Color(0xff4f3933) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Container(
          width: 30,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            // mainAxisAlignment: Mai,
            children: [
              Row(
                children: [
                  RotatedBox(
                    quarterTurns: -1,
                    child: Container(
                      height: 10,
                      width: 10,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: newCategoryId == categoryId
                            ? Colors.black
                            : Colors.transparent,
                      ),
                    ),
                  ),
                  RotatedBox(
                    quarterTurns: -1,
                    child: FittedBox(
                        child: Text(
                      "${categoryName}",
                      style: TextStyle(
                        fontWeight: newCategoryId == categoryId
                            ? FontWeight.bold
                            : FontWeight.normal,
                        color: newCategoryId == categoryId
                            ? Colors.black
                            : Colors.black,
                      ),
                    )),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      onTap: () {
        ProductModel.showList(
          context: context,
          cateId: categoryId,
          cateName: categoryName,
        );
        setState(() {
          newCategoryId = categoryId;
        });
      },
    );
  }

  Future<List<Category>> getProducts() async {
    try {
      var url =
          "https://dokkan.store/cacao/wp-json/wc/v2/products/categories?exclude=311&per_page=100&page=1&hide_empty=true&lang=ar&consumer_key=ck_48c3b5cb9baf2ba92bf90734c5a887f609ff6f7e&consumer_secret=cs_34d8a855d2ca3a34be4882fa5f7c028e9c80a539";
      final c = await http.get(url);
      print(c.body);
      var response = json.decode(c.body);
      print(c.body);
      // var response = await wcApi.getAsync("products");

      if (response is Map && isNotBlank(response["message"])) {
        throw Exception(response["message"]);
      } else {
        for (var item in response) {
          list.add(Category.fromJson(item));
        }

        return list;
      }
    } catch (e) {
      print(e);
      //This error exception is about your Rest API is not config correctly so that not return the correct JSON format, please double check the document from this link https://docs.inspireui.com/fluxstore/woocommerce-setup/
      rethrow;
    }
  }

  // Padding buildPaddingBnnar() {
  //   return Padding(
  //     padding: EdgeInsets.symmetric(
  //       horizontal: getProportionateScreenWidth(15),
  //     ),
  //     child: Container(
  //         decoration: BoxDecoration(
  //           borderRadius: BorderRadius.all(
  //             Radius.circular(30),
  //           ),
  //         ),
  //         width: double.infinity,
  //         height: getProportionateScreenHeight(138),
  //         child: Carousel(
  //           dotBgColor: Colors.transparent,
  //           dotIncreasedColor: Color(0XFFffd900),
  //
  //           images: panner,
  //           boxFit: BoxFit.cover,
  //           radius: Radius.circular(30),
  //           // dotBgColor: ,
  //           dotSize: 4.0,
  //           noRadiusForIndicator: true,
  //           // radius:Radius.circular(30) ,
  //
  //           dotSpacing: 15.0,
  //           animationCurve: Curves.ease,
  //           dotColor: Theme.of(context).primaryColor,
  //           indicatorBgPadding: 5.0,
  //           borderRadius: true,
  //         )),
  //   );
  // }

  Widget CreditCardTile(String image, double scale) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(
          height: PAGER_HEIGHT * scale,
          width: PAGER_WIDTH * scale,
          child: Card(
            elevation: 5,
            shadowColor: Colors.amber,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0)),
            clipBehavior: Clip.antiAlias,
            child: Image.asset(
              image,
              fit: BoxFit.cover,
            ),
          )),
    );
  }

  Widget itemBuilder(index, List<Product> futcherProduct) {
    height = MediaQuery.of(context).size.height;
    return AnimatedBuilder(
      animation: pageController,
      child: Container(
        width: 100,
        decoration: BoxDecoration(
            color: Colors.grey, borderRadius: BorderRadius.circular(10)),
        child: LayoutBuilder(
          builder: (ctx, cons) => InkWell(
            onTap: () {
              Navigator.of(
                context,
                rootNavigator: true,
              ).pushNamed(
                RouteList.productDetail,
                arguments: futcherProduct[index],
              );
            },
            child: Container(
              width: 300,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(30),
                      child: Image.network(
                        futcherProduct[index].images[0],
                        fit: BoxFit.fitHeight,
                        height: MediaQuery.of(context).size.height * .20,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: cons.maxHeight * 0.04,
                  ),
                  Container(
                    child: Text(
                      futcherProduct[index].name,
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.w600),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        futcherProduct[index].price,
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.w600),
                      ),
                      const Text(
                        "ج.م",
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                  (futcherProduct[index].regularPrice != "")
                      ? Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 5),
                          child: Text(
                            "${futcherProduct[index].regularPrice}\ج.م",
                            style:
                                Theme.of(context).textTheme.subtitle1.copyWith(
                                      fontSize: 15.5,
                                      color: Colors.red,
                                      fontWeight: FontWeight.w400,
                                      decoration: TextDecoration.lineThrough,
                                    ),
                          ),
                        )
                      : Container(),
                ],
              ),
            ),
          ),
        ),
      ),
      builder: (ctx, child) {
        double value = 1;
        double opacityValue = 1;
        if (pageController.position.haveDimensions) {
          value = pageController.page - index;
          value = (1 - value.abs() * 0.2).clamp(.9, 2.0);
          return Transform.scale(
            alignment: Alignment.bottomCenter,
            scale: value,
            child: child,
          );
        } else {
          return Transform.scale(
            alignment: Alignment.bottomCenter,
            scale: value,
            child: child,
          );
        }
      },
    );
  }

  buildPaddingAppBAr() {
    var totalCart = Provider.of<CartModel>(context).totalCartQuantity;
    final screenSize = MediaQuery.of(context).size;
    return Column(
      children: [
        // SizedBox(
        //   height: 20,
        // ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: [
            const Text(
              "fashion",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Row(
              children: [
                SizedBox(width: getProportionateScreenWidth(10)),
                Stack(
                  children: [
                    InkWell(
                      onTap: () {
                        MainTabControlDelegate.getInstance().tabAnimateTo(3);
                        // CartScreen();
                      },
                      child: Card(
                        elevation: 5,
                        shadowColor: Colors.black,
                        color: Colors.black,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(7),
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Image.asset(
                            'assets/icons/Shopping Cart Home.png',
                            color: Color(0XFFffd900),
                            width: 25,
                          ),
                        ),
                      ),
                    ),
                    Positioned.fill(
                      child: Align(
                        alignment: Alignment.topRight,
                        child: CircleAvatar(
                          backgroundColor: Colors.red,
                          child: FittedBox(
                            child: Padding(
                              padding: const EdgeInsets.all(1.0),
                              child: Text(
                                '${totalCart}',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ),
                          radius: 9,
                        ),
                      ),
                    )
                  ],
                ),
              ],
            )

            // SizedBox(width: getProportionateScreenWidth(10)),
          ],
        ),
        SizedBox(
          height: 20,
        ),
        EntryField(
          readOnly: true,
          onTap: () {
            MainTabControlDelegate.getInstance().tabAnimateTo(2);
          },
          textAlign: TextAlign.start,
          prefixIcon: Icons.search,
          // label:S.of(context).search ,
          hint: "ابحث هنا ..",
        ),
        SizedBox(
          height: 20,
        ),
      ],
    );
  }

  List<Category> getSubCategories(id) {
    return categories.where((o) => o.parent == id).toList();
  }

  Widget getChildCategoryList(category) {
    print(category.id);
    return ChildList(
      children: [
        SubItem(
          category,
          seeAll: S.of(context).seeAll,
        ),
        for (var category in getSubCategories(category.id))
          Parent(
            parent: SubItem(category),
            childList: ChildList(
              children: [
                for (var cate in getSubCategories(category.id))
                  Parent(
                    parent: SubItem(cate, level: 1),
                    childList: ChildList(
                      children: [
                        for (var _cate in getSubCategories(cate.id))
                          Parent(
                            parent: SubItem(_cate, level: 2),
                            childList: ChildList(children: []),
                          ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
      ],
    );
  }

  bool hasChildren(id) {
    return categories.where((o) => o.parent == id).toList().isNotEmpty;
  }

  Container categoriRow(CategoryModel category) {
    return Container(
      height: getProportionateScreenHeight(120),
      width: double.infinity,
      child: ListenableProvider.value(
        value: category,
        child: Consumer<CategoryModel>(
          builder: (context, value, child) {
            if (value.isLoading) {
              return Container(
                height: getProportionateScreenHeight(120),
                child: Shimmer.fromColors(
                  period: Duration(milliseconds: 500),
                  baseColor: Colors.amber.withOpacity(0.5),
                  highlightColor: Colors.black.withOpacity(0.5),
                  child: Container(
                    width: 150.0,
                    height: getProportionateScreenHeight(120),
                    child: ShimmerProductListItem(),
                  ),
                ),
              );
            }
            if (value.categories == null) {
              return Container(
                width: double.infinity,
                height: double.infinity,
                alignment: Alignment.center,
                child: Text(S.of(context).dataEmpty),
              );
            }
            //  if (value.categories[index].parent == '0')
            categories = value.categories;
            // if (showCategories.isEmpty) {
            //   // for (int i = 0; i < categories.length; i++) {
            //   //   if (hasChildren(categories[i].id) == true) {
            //   //     showCategories.add(categories[i]);
            //   //   }
            //   // }
            // }

            return Padding(
              padding: EdgeInsets.only(
                left: getProportionateScreenWidth(5),
              ),
              child: Container(
                height: getProportionateScreenHeight(120),
                child: ListView.builder(
                    physics: BouncingScrollPhysics(),
                    shrinkWrap: true,
                    itemCount: categories.length,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (context, index) {
                      // showCategories = value.categories[index].parent;
                      if (value.categories[index].parent != '0') {
                        return InkWell(
                          onTap: () {
                            // var data =
                            //     Provider.of<ProductModel>(context, listen: false)
                            //         .productsList[0]
                            //         .name;

                            // print("$data");
                            ProductModel.showList(
                              context: context,
                              cateId: categories[index].id,
                              cateName: categories[index].name,
                            );
                          },
                          child: HomeSpecialListItem(
                            category: categories[index],
                          ),
                        );
                      }
                    }),
              ),
            );

            // ListView.builder(
            //     itemCount: categories.length,
            //     itemBuilder: (context, index) {
            //       return InkWell(
            //         onTap: () {
            // ProductModel.showList(
            //       context: context,
            //       cateId: categories[index].id,
            //       cateName: categories[index].name,
            //     );

            //         },
            //         child: Container(
            //           margin:
            //               EdgeInsets.symmetric(vertical: 20, horizontal: 20),
            //           child: Row(
            //             children: [Text("${categories[index].name}")],
            //           ),
            //         ),
            //       );
            //     });
          },
        ),
      ),
    );
  }

  Container TrendingRow(CategoryModel category) {
    return Container(
      height: getProportionateScreenHeight(120),
      width: double.infinity,
      child: ListenableProvider.value(
        value: category,
        child: Consumer<CategoryModel>(
          builder: (context, value, child) {
            if (value.isLoading) {
              return Container(
                height: getProportionateScreenHeight(120),
                child: Shimmer.fromColors(
                  period: Duration(milliseconds: 500),
                  baseColor: Colors.amber.withOpacity(0.5),
                  highlightColor: Colors.black.withOpacity(0.5),
                  child: Container(
                    width: 150.0,
                    height: getProportionateScreenHeight(120),
                    child: ShimmerProductListItem(),
                  ),
                ),
              );
            }
            if (value.categories == null) {
              return Container(
                width: double.infinity,
                height: double.infinity,
                alignment: Alignment.center,
                child: Text(S.of(context).dataEmpty),
              );
            }
            categories = value.categories;

            return Padding(
              padding: EdgeInsets.only(
                left: getProportionateScreenWidth(5),
              ),
              child: Container(
                height: getProportionateScreenHeight(120),
                child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: categories.length,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (context, index) {
                      return InkWell(
                        onTap: () {
                          // var data =
                          //     Provider.of<ProductModel>(context, listen: false)
                          //         .productsList[0]
                          //         .name;

                          // print("$data");
                          ProductModel.showList(
                            context: context,
                            cateId: categories[index].id,
                            cateName: categories[index].name,
                          );
                        },
                        child: HomeSpecialListItem(
                          category: categories[index],
                        ),
                      );
                    }),
              ),
            );

            // ListView.builder(
            //     itemCount: categories.length,
            //     itemBuilder: (context, index) {
            //       return InkWell(
            //         onTap: () {
            // ProductModel.showList(
            //       context: context,
            //       cateId: categories[index].id,
            //       cateName: categories[index].name,
            //     );

            //         },
            //         child: Container(
            //           margin:
            //               EdgeInsets.symmetric(vertical: 20, horizontal: 20),
            //           child: Row(
            //             children: [Text("${categories[index].name}")],
            //           ),
            //         ),
            //       );
            //     });
          },
        ),
      ),
    );
  }

  buildAppBar(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        IconButton(
          icon: Icon(
            Icons.drag_handle,
            color: Theme.of(context).accentColor.withOpacity(0.9),
            size: 22,
          ),
          onPressed: () {
            eventBus.fire(const EventOpenNativeDrawer());
          },
        ),
        // Image.asset("name"),
        IconButton(
          icon: Icon(
            Icons.search,
            color: Theme.of(context).accentColor.withOpacity(0.6),
            size: 22,
          ),
          onPressed: () {
            Navigator.of(context).pushNamed(RouteList.homeSearch);
          },
        ),
      ],
    );
  }
}

// Expanded(
//   child: Container(
//     decoration: BoxDecoration(
//       borderRadius: BorderRadius.only(
//           topRight: Radius.circular(30),
//           topLeft: Radius.circular(30)),
//     ),
//     child: Padding(
//       padding: const EdgeInsets.only(top: 15.0),
//       child: SingleChildScrollView(
//         physics: BouncingScrollPhysics(),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           mainAxisSize: MainAxisSize.max,
//           children: <Widget>[
//             SizedBox(
//                 height: getProportionateScreenHeight(17)),
//             ListTitleRow(
//                 title: S.of(context).Special_for_you,
//                 suffix: '${S.of(context).seeAll}'),
//             SizedBox(
//                 height: getProportionateScreenHeight(7)),
//             categoriRow(Categories),
//             SizedBox(
//                 height: getProportionateScreenHeight(10)),
//             ListTitleRow(
//                 title: S.of(context).Featured_Product,
//                 suffix: '${S.of(context).seeAll}'),
//             ListenableProvider.value(
//               value: product,
//               child: Consumer<GetProduct>(
//                   builder: (context, value, child) {
//                 if (value.isFetching == false) {
//                   return Container(
//                     height: 210,
//                     child: ListView.builder(
//                         physics: BouncingScrollPhysics(),
//                         shrinkWrap: true,
//                         itemCount:
//                             product.futcherProduct.length,
//                         scrollDirection: Axis.horizontal,
//                         itemBuilder: (context, index) {
//                           return Container(
//                             width: 150,
//                             child: Container(
//                               margin: EdgeInsets.symmetric(
//                                   horizontal: 10),
//                               child: InkWell(
//                                 onTap: () {
//                                   Navigator.of(
//                                     context,
//                                     rootNavigator: true,
//                                   ).pushNamed(
//                                     RouteList.productDetail,
//                                     arguments: product
//                                             .futcherProduct[
//                                         index],
//                                   );
//                                 },
//                                 child: SizedBox(
//                                   width:
//                                       getProportionateScreenWidth(
//                                           110),
//                                   child: Column(
//                                     crossAxisAlignment:
//                                         CrossAxisAlignment
//                                             .start,
//                                     mainAxisAlignment:
//                                         MainAxisAlignment
//                                             .start,
//                                     mainAxisSize:
//                                         MainAxisSize.max,
//                                     children: [
//                                       AspectRatio(
//                                         aspectRatio:
//                                             1 / 1.1,
//                                         child: Card(
//                                           clipBehavior: Clip
//                                               .antiAliasWithSaveLayer,
//                                           margin: EdgeInsets
//                                               .symmetric(
//                                                   horizontal:
//                                                       0,
//                                                   vertical:
//                                                       10),
//                                           elevation: 0,
//                                           shadowColor:
//                                               kCardBackgroundColor,
//                                           shape:
//                                               RoundedRectangleBorder(
//                                             borderRadius:
//                                                 BorderRadius
//                                                     .circular(
//                                                         15),
//                                           ),
//                                           child: Stack(
//                                             children: [
//                                               GestureDetector(
//                                                 onTap: () {
//                                                   if (product
//                                                           .futcherProduct[
//                                                               index]
//                                                           .imageFeature ==
//                                                       '')
//                                                     return;
//                                                   Provider.of<RecentModel>(
//                                                           context,
//                                                           listen:
//                                                               false)
//                                                       .addRecentProduct(
//                                                           product.futcherProduct[index]);
//                                                   //Load update product detail screen for FluxBuilder
//                                                   eventBus.fire(
//                                                       'detail');
//                                                   Navigator
//                                                       .of(
//                                                     context,
//                                                     rootNavigator:
//                                                         true, // Push in tab for tablet (IPad)
//                                                   ).pushNamed(
//                                                     RouteList
//                                                         .productDetail,
//                                                     arguments:
//                                                         product.futcherProduct[index],
//                                                   );
//                                                 },
//                                                 child: Image
//                                                     .network(
//                                                   product
//                                                       .futcherProduct[
//                                                           index]
//                                                       .imageFeature,
//                                                   fit: BoxFit
//                                                       .cover,
//                                                   width: double
//                                                       .infinity,
//                                                   height: double
//                                                       .infinity,
//                                                 ),
//                                               ),
//                                             ],
//                                           ),
//                                         ),
//                                       ),
//                                       const SizedBox(
//                                           height: 5),
//                                       Padding(
//                                         padding:
//                                             const EdgeInsets
//                                                     .symmetric(
//                                                 horizontal:
//                                                     0),
//                                         child: Text(
//                                           product
//                                               .futcherProduct[
//                                                   index]
//                                               .name,
//                                           // softWrap: true,
//                                           textAlign:
//                                               TextAlign
//                                                   .start,
//                                           maxLines: 1,
//                                           overflow:
//                                               TextOverflow
//                                                   .ellipsis,
//                                           style: TextStyle(
//                                             fontWeight:
//                                                 FontWeight
//                                                     .bold,
//                                             fontSize: 14,
//                                             // color: Colors.black.withOpacity(0.7),
//                                           ),
//                                         ),
//                                       ),
//                                       Padding(
//                                         padding:
//                                             const EdgeInsets
//                                                     .symmetric(
//                                                 horizontal:
//                                                     5),
//                                         child: Row(
//                                           children: [
//                                             Text(
//                                               '${product.futcherProduct[index].price} ',
//                                               style:
//                                                   TextStyle(
//                                                 fontSize:
//                                                     getProportionateScreenWidth(
//                                                         16),
//                                                 fontWeight:
//                                                     FontWeight
//                                                         .w600,
//                                                 color: Colors
//                                                     .amber,
//                                               ),
//                                             ),
//                                             Text(
//                                               "ج.م",
//                                               style:
//                                                   TextStyle(
//                                                 fontSize:
//                                                     getProportionateScreenWidth(
//                                                         13),
//                                                 fontWeight:
//                                                     FontWeight
//                                                         .w600,
//                                                 color: Colors
//                                                     .amber,
//                                               ),
//                                             )

//                                             //
//                                           ],
//                                         ),
//                                       ),
//                                       SizedBox(width: 3),
//                                       (product
//                                                   .futcherProduct[
//                                                       index]
//                                                   .regularPrice !=
//                                               "")
//                                           ? Padding(
//                                               padding: const EdgeInsets
//                                                       .symmetric(
//                                                   horizontal:
//                                                       5),
//                                               child: Text(
//                                                 "${product.futcherProduct[index].regularPrice}\ج.م",
//                                                 style: Theme.of(
//                                                         context)
//                                                     .textTheme
//                                                     .subtitle1
//                                                     .copyWith(
//                                                       fontSize:
//                                                           11.5,
//                                                       color: Theme.of(context)
//                                                           .accentColor
//                                                           .withOpacity(0.6),
//                                                       fontWeight:
//                                                           FontWeight.w400,
//                                                       decoration:
//                                                           TextDecoration.lineThrough,
//                                                     ),
//                                               ),
//                                             )
//                                           : Container()
//                                     ],
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           );
//                         }),
//                   );
//                 } else if (value.isFetching == true) {
//                   return Container(
//                     width: double.infinity,
//                     height:
//                         getProportionateScreenHeight(200),
//                     child: ListView.separated(
//                       padding: const EdgeInsets.symmetric(
//                           horizontal: 16.0),
//                       shrinkWrap: true,
//                       scrollDirection: Axis.horizontal,
//                       itemCount: 5,
//                       itemBuilder: (context, index) {
//                         return Shimmer.fromColors(
//                           period:
//                               Duration(milliseconds: 500),
//                           baseColor:
//                               Colors.amber.withOpacity(0.5),
//                           highlightColor:
//                               Colors.black.withOpacity(0.5),
//                           child: Container(
//                             width: 150.0,
//                             child: ShimmerProductListItem(),
//                           ),
//                         );
//                       },
//                       separatorBuilder: (context, index) {
//                         return SizedBox(
//                           width: 10.0,
//                         );
//                       },
//                     ),
//                   );
//                 } else
//                   return null;
//               }),
//             ),
//             SizedBox(
//                 height: getProportionateScreenHeight(10)),
//           ],
//         ),
//       ),
//     ),
//   ),
// ),

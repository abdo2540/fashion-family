import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:quiver/strings.dart';
import 'package:fashion/screens/checkout/payment.dart';
import '../../common/constants.dart';
import '../../common/tools.dart';
import '../../generated/l10n.dart';
import '../../models/cart/cart_model.dart';
import '../../models/shipping_method_model.dart';
import '../../services/index.dart';
import 'package:shimmer/shimmer.dart';
import 'package:fashion/screens/checkout/review_screen.dart';
import 'package:flutter_svg/svg.dart';

class ShippingMethods extends StatefulWidget {
  final Function onBack;
  final Function onNext;

  ShippingMethods({this.onBack, this.onNext});

  @override
  _ShippingMethodsState createState() => _ShippingMethodsState();
}

class _ShippingMethodsState extends State<ShippingMethods> {
  int selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    Future.delayed(
      Duration.zero,
      () async {
        final shippingMethod =
            Provider.of<CartModel>(context, listen: false).shippingMethod;
        final shippingMethods =
            Provider.of<ShippingMethodModel>(context, listen: false)
                .shippingMethods;
        if (shippingMethods != null &&
            shippingMethods.isNotEmpty &&
            shippingMethod != null) {
          final index = shippingMethods
              .indexWhere((element) => element.id == shippingMethod.id);
          if (index > -1) {
            setState(() {
              selectedIndex = index;
            });
          }
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final shippingMethodModel = Provider.of<ShippingMethodModel>(context);
    final currency = Provider.of<CartModel>(context).currency;
    final currencyRates = Provider.of<CartModel>(context).currencyRates;
    final screenSize = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      // appBar: AppBar(
      //   backgroundColor: const Color(0xff4f3933),
      //   leading: IconButton(
      //       icon: const Icon(
      //         Icons.arrow_back_ios,
      //         size: 20,
      //         color: Colors.white,
      //       ),
      //       onPressed: () {
      //         Navigator.of(context).pop();
      //       }),
      //   centerTitle: true,
      //   title: Text(
      //     S.of(context).shippingMethod,
      //     style: TextStyle(
      //         fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
      //   ),
      // ),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    elevation: 5,
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          // border: Border.all(
                          //     color: Theme.of(context).primaryColor, width: 1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                            child: Icon(
                              Icons.arrow_back_ios,
                              color: Theme.of(context).primaryColor,
                              size: 20,
                            )),
                      ),
                    ),
                  ),
                  Text(S.of(context).shippingMethod,
                      style: GoogleFonts.tajawal(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.black)
                  ),
                  Card(
                    color: Colors.transparent,
                    elevation: 0.0,
                    child: Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 30,
                  width: 30,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Theme.of(context).primaryColor,
                  ),
                  child: Icon(Icons.check, color: Colors.white,),
                ),
                Container(
                  height: 5,
                  width: 100,
                  color: Theme.of(context).primaryColor,
                ),
                Container(
                  height: 30,
                  width: 30,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Theme.of(context).primaryColor,
                  ),
                ),
                Container(
                  height: 5,
                  width: 100,
                  color: Colors.grey,
                ),
                Container(
                  height: 30,
                  width: 30,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    S.of(context).shippingAddress,
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 12
                    ),
                  ),
                  Text(
                    S.of(context).shippingMethod,
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 12
                    ),
                  ),
                  Text(
                    S.of(context).payment,
                    style: TextStyle(
                        color: Colors.grey,
                        fontSize: 12
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 10),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(30), topRight: Radius.circular(30)),
                  color: Colors.white,
                ),
                child: ListenableProvider.value(
                  value: shippingMethodModel,
                  child: Consumer<ShippingMethodModel>(
                    builder: (context, model, child) {
                      if (model.isLoading) {
                        return Column(
                          children: [
                            SizedBox(
                              height: 20,
                            ),
                            Container(
                                height: 100,
                                child: Shimmer.fromColors(
                                  period: Duration(milliseconds: 300),
                                  baseColor: Theme.of(context).primaryColor,
                                  highlightColor: Colors.white,
                                  child: Container(
                                    width: double.infinity,
                                    child: Container(
                                      margin: const EdgeInsets.all(8.0),
                                      height: 50.0,
                                      decoration: BoxDecoration(
                                        color: Colors.black.withOpacity(0.2),
                                        borderRadius:
                                            BorderRadius.circular(12.0),
                                      ),
                                    ),
                                  ),
                                )),
                            Container(
                              height: 50,
                              child: Shimmer.fromColors(
                                period: Duration(milliseconds: 300),
                                baseColor: Color(0xff4f3933),
                                highlightColor: Colors.white,
                                child: Container(
                                  margin: const EdgeInsets.all(8.0),
                                  height: 50.0,
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(12.0),
                                  ),
                                ),
                              ),
                            )
                          ],
                        );
                      }

                      if (model.message != null) {
                        return Container(
                          height: 100,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 20),
                          child: Center(
                              child: Text(model.message,
                                  style: const TextStyle(color: kErrorRed))),
                        );
                      }

                      return Column(
                        children: <Widget>[
                          SizedBox(
                            height: 20,
                          ),
                          // SizedBox(
                          //   height: 10,
                          // ),
                          for (int i = 0;
                              i < model.shippingMethods.length;
                              i++)
                            Column(
                              children: <Widget>[
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(10),
                                        // bottomRight: Radius.circular(30),
                                      ),
                                      border: Border.all(
                                        color: Theme.of(context).primaryColor,
                                      ),
                                      color: i == selectedIndex
                                          ? Colors.white
                                          : Colors.transparent,
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 15, horizontal: 10),
                                      child: Row(
                                        children: <Widget>[
                                          Radio(
                                            activeColor: Theme.of(context).primaryColor,
                                            value: i,
                                            groupValue: selectedIndex,
                                            onChanged: (i) {
                                              setState(() {
                                                selectedIndex = i;
                                              });
                                            },
                                          ),
                                          const SizedBox(width: 10),
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: <Widget>[
                                                Services()
                                                    .widget
                                                    .renderShippingPaymentTitle(
                                                        context,
                                                        model
                                                            .shippingMethods[
                                                                i]
                                                            .title),
                                                const SizedBox(height: 5),
                                                if (model.shippingMethods[i]
                                                            .cost >
                                                        0.0 ||
                                                    !isNotBlank(model
                                                        .shippingMethods[i]
                                                        .classCost))
                                                  Text(
                                                    "${model.shippingMethods[i].cost}" + ' ' + S.of(context).currency,
                                                    style: const TextStyle(
                                                        fontSize: 14,
                                                        color: kGrey400),
                                                  ),
                                                if (model.shippingMethods[i]
                                                            .cost ==
                                                        0.0 &&
                                                    isNotBlank(model
                                                        .shippingMethods[i]
                                                        .classCost))
                                                  Text(
                                                    model.shippingMethods[i]
                                                        .classCost,
                                                    style: const TextStyle(
                                                        fontSize: 14,
                                                        color: kGrey400),
                                                  )
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                i < model.shippingMethods.length - 1
                                    ? const Divider(height: 1)
                                    : Container(),
                              ],
                            ),
                          const SizedBox(height: 20),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8),
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: Row(
                                children: [
                                  Expanded(
                                    child: ButtonTheme(
                                      height: 55,
                                      child: RaisedButton(
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(15.0),
                                          // side: BorderSide(color: Colors.red)
                                        ),
                                        elevation: 0,
                                        onPressed: () {
                                          if (shippingMethodModel
                                              .shippingMethods.isNotEmpty) {
                                            Provider.of<CartModel>(context,
                                                    listen: false)
                                                .setShippingMethod(
                                                    shippingMethodModel
                                                            .shippingMethods[
                                                        selectedIndex]);
                                            Navigator.of(context).push(
                                                MaterialPageRoute(
                                                    builder: (BuildContext
                                                            context) =>
                                                        PaymentMethods(
                                                          onFinish: (order) {
                                                            Provider.of<CartModel>(
                                                                    context,
                                                                    listen:
                                                                        false)
                                                                .clearCart();
                                                          },
                                                        )));
                                            // ReviewScreen();

                                            // widget.onNext();
                                          }
                                        },
                                        textColor: Colors.white,
                                        color: Theme.of(context).primaryColor,
                                        child: Text(S
                                            .of(context)
                                            .payment
                                            .toUpperCase()),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ),
            ),

            // Center(
            //   child: FlatButton(
            //     onPressed: () {
            //       widget.onBack();
            //     },
            //     child: Text(
            //       S.of(context).goBackToAddress,
            //       textAlign: TextAlign.center,
            //       style: const TextStyle(
            //           decoration: TextDecoration.underline,
            //           fontSize: 15,
            //           color: kGrey400),
            //     ),
            //   ),
            // )
          ],
        ),
      ),
    );
  }
}

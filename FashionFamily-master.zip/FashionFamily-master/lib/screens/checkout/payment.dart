import 'package:appsflyer_sdk/appsflyer_sdk.dart';
import 'package:fashion/models/shipping_method_model.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:quiver/strings.dart';

import '../../common/config.dart';
import '../../common/constants.dart';
import '../../common/tools.dart';
import '../../generated/l10n.dart';
import '../../models/index.dart'
    show
        AppModel,
        CartModel,
        Order,
        BookingInfo,
        PaymentMethodModel,
        Product,
        TaxModel,
        UserModel;
import '../../services/index.dart';
import '../../widgets/payment/credit/index.dart';
import '../../widgets/payment/paypal/index.dart';
import '../../widgets/payment/razor/index.dart';
import '../../widgets/payment/stripe/index.dart';
import '../../widgets/payment/tap/index.dart';
import 'package:shimmer/shimmer.dart';
import 'package:fashion/screens/checkout/processing_dialog.dart';
import 'package:fashion/screens/checkout/success.dart';
import 'package:fashion/widgets/product/cart_item.dart';
import 'package:flutter_svg/svg.dart';

class PaymentMethods extends StatefulWidget {
  final Function onBack;
  final Function onFinish;
  final Function(bool) onLoading;

  PaymentMethods({this.onBack, this.onFinish, this.onLoading});

  @override
  _PaymentMethodsState createState() => _PaymentMethodsState();
}

class _PaymentMethodsState extends State<PaymentMethods> {
  String selectedId;
  int selectedIndex = 0;
  bool isPaying = false;

  @override
  void initState() {
    super.initState();

    Future.delayed(Duration.zero, () {
      final cartModel = Provider.of<CartModel>(context, listen: false);
      final userModel = Provider.of<UserModel>(context, listen: false);
      Provider.of<PaymentMethodModel>(context, listen: false).getPaymentMethods(
          cartModel: cartModel,
          shippingMethod: cartModel.shippingMethod,
          token: userModel.user != null ? userModel.user.cookie : null);

      if (kPaymentConfig["EnableReview"] != true) {
        Provider.of<TaxModel>(context, listen: false).getTaxes(
            Provider.of<CartModel>(context, listen: false), (taxesTotal) {
          Provider.of<CartModel>(context, listen: false).taxesTotal =
              taxesTotal;
          setState(() {});
        });
      }
    });
    Future.delayed(
      Duration.zero,
          () async {
        final shippingMethod =
            Provider.of<CartModel>(context, listen: false).shippingMethod;
        final shippingMethods =
            Provider.of<ShippingMethodModel>(context, listen: false)
                .shippingMethods;
        if (shippingMethods != null &&
            shippingMethods.isNotEmpty &&
            shippingMethod != null) {
          final index = shippingMethods
              .indexWhere((element) => element.id == shippingMethod.id);
          if (index > -1) {
            setState(() {
              selectedIndex = index;
            });
          }
        }
      },
    );
  }



  @override
  Widget build(BuildContext context) {
    final cartModel = Provider.of<CartModel>(context);
    final currencyRate = Provider.of<AppModel>(context).currencyRate;
    final shippingMethodModel = Provider.of<ShippingMethodModel>(context);
    final paymentMethodModel = Provider.of<PaymentMethodModel>(context);
    final taxModel = Provider.of<TaxModel>(context);
    final screenSize = MediaQuery.of(context).size;
    final address = cartModel.address;
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      // appBar: AppBar(
      //   backgroundColor: const Color(0xff4f3933),
      //   leading: IconButton(
      //       icon: const Icon(
      //         Icons.arrow_back_ios,
      //         size: 20,
      //         color: Colors.white,
      //       ),
      //       onPressed: () {
      //         Navigator.of(context).pop();
      //       }),
      //   centerTitle: true,
      //   title: const Text(
      //     "تأكيد الطلب",
      //     style: TextStyle(
      //         fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
      //   ),
      // ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    elevation: 5,
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          // border: Border.all(
                          //     color: Theme.of(context).primaryColor, width: 1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                            child: Icon(
                              Icons.arrow_back_ios,
                              color: Theme.of(context).primaryColor,
                              size: 20,
                            )),
                      ),
                    ),
                  ),
                  Text(S.of(context).payment,
                      style: GoogleFonts.tajawal(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.black)),
                  Card(
                    color: Colors.transparent,
                    elevation: 0.0,
                    child: Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 30,
                  width: 30,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Theme.of(context).primaryColor,
                  ),
                  child: Icon(Icons.check, color: Colors.white,),
                ),
                Container(
                  height: 5,
                  width: 100,
                  color: Theme.of(context).primaryColor,
                ),
                Container(
                  height: 30,
                  width: 30,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color:Theme.of(context).primaryColor,
                  ),
                  child: Icon(Icons.check, color: Colors.white,),

                ),
                Container(
                  height: 5,
                  width: 100,
                  color: Theme.of(context).primaryColor,
                ),
                Container(
                  height: 30,
                  width: 30,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Theme.of(context).primaryColor,
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    S.of(context).shippingAddress,
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 12
                    ),
                  ),
                  Text(
                    S.of(context).shippingMethod,
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 12
                    ),
                  ),
                  Text(
                    S.of(context).payment,
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 12
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),

            Expanded(
              child: Container(
                height: MediaQuery.of(context).size.height,
                padding: EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(30),
                    topLeft: Radius.circular(30),
                  )
                ),
                child: SingleChildScrollView(
                  child: ListenableProvider.value(
                      value: paymentMethodModel,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          const SizedBox(height: 20),

                          // ...getProducts(
                          //     Provider.of<CartModel>(context, listen: false),
                          //     context),
                          Consumer<PaymentMethodModel>(
                              builder: (context, model, child) {
                            if (model.isLoading) {
                              return Container(
                                  height: 100,
                                  child: Shimmer.fromColors(
                                    period: Duration(milliseconds: 300),
                                    baseColor: Colors.white,
                                    highlightColor: Color(0xff4f3933),
                                    child: Container(
                                      width: double.infinity,
                                      child: Container(
                                        margin: const EdgeInsets.all(8.0),
                                        height: 150.0,
                                        decoration: BoxDecoration(
                                          color: Colors.black
                                              .withOpacity(0.2),
                                          borderRadius:
                                              BorderRadius.circular(12.0),
                                        ),
                                      ),
                                    ),
                                  ));
                            }

                            if (model.message != null) {
                              return Container(
                                height: 100,
                                child: Center(
                                    child: Text(model.message,
                                        style: const TextStyle(
                                            color: kErrorRed))),
                              );
                            }

                            if (selectedId == null &&
                                model.paymentMethods.isNotEmpty) {
                              selectedId = model.paymentMethods
                                  .firstWhere((item) => item.enabled)
                                  .id;
                            }

                            return Column(
                              children: <Widget>[
                                for (int i = 0;
                                    i < model.paymentMethods.length;
                                    i++)
                                  model.paymentMethods[i].enabled
                                      ? Column(
                                          children: <Widget>[
                                            InkWell(
                                              onTap: () {
                                                setState(() {
                                                  selectedId = model
                                                      .paymentMethods[i]
                                                      .id;
                                                });
                                              },
                                              child: Padding(
                                                padding: const EdgeInsets
                                                        .symmetric(
                                                    horizontal: 0),
                                                child: Container(
                                                  decoration:
                                                      BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .all(
                                                            Radius
                                                                .circular(
                                                                    10),
                                                          ),
                                                          border: Border.all(
                                                              color: Theme.of(context).primaryColor),
                                                          color: model
                                                                      .paymentMethods[
                                                                          i]
                                                                      .id ==
                                                                  selectedId
                                                              ? Colors
                                                                  .white
                                                              : Colors
                                                                  .transparent),
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets
                                                                .symmetric(
                                                            vertical: 15,
                                                            horizontal:
                                                                10),
                                                    child: Row(
                                                      children: <Widget>[
                                                        Radio(
                                                            activeColor:
                                                                Theme.of(context).primaryColor,
                                                            value: model
                                                                .paymentMethods[
                                                                    i]
                                                                .id,
                                                            groupValue:
                                                                selectedId,
                                                            onChanged:
                                                                (i) {
                                                              setState(
                                                                  () {
                                                                selectedId =
                                                                    i;
                                                              });
                                                            }),
                                                        const SizedBox(
                                                            width: 10),
                                                        Expanded(
                                                          child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: <
                                                                Widget>[
                                                              if (Payments[model
                                                                      .paymentMethods[
                                                                          i]
                                                                      .id] !=
                                                                  null)
                                                                Image
                                                                    .asset(
                                                                  Payments[model
                                                                      .paymentMethods[i]
                                                                      .id],
                                                                  width:
                                                                      120,
                                                                  height:
                                                                      30,
                                                                ),
                                                              if (Payments[model
                                                                      .paymentMethods[
                                                                          i]
                                                                      .id] ==
                                                                  null)
                                                                Services()
                                                                    .widget
                                                                    .renderShippingPaymentTitle(
                                                                        context,
                                                                        model.paymentMethods[i].title),
                                                            ],
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        )
                                      : Container()
                              ],
                            );
                          }),
                          const SizedBox(height: 0),
                          //     SizedBox(
                          //   height: 20,
                          // ),
                          // Text(
                          //   "عنوان الشحن",
                          //   style: TextStyle(
                          //     fontSize: 16,
                          //     fontWeight: FontWeight.bold,
                          //     color: Theme.of(context).accentColor,
                          //   ),
                          // ),
                          SizedBox(
                            height: 20,
                          ),

                          Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.all(
                                  Radius.circular(10),
                                  // topLeft: Radius.circular(30)
                                ),
                                color: Colors.grey.withOpacity(.1)),
                            padding: const EdgeInsets.symmetric(
                                vertical: 10, horizontal: 30),
                            child: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 5,
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: <Widget>[
                                      Container(
                                        width: 120,
                                        child: Text(
                                          S.of(context).firstName + " :",
                                          style: TextStyle(
                                              fontSize: 14,
                                              color: Theme.of(context)
                                                  .accentColor,
                                              fontWeight:
                                                  FontWeight.bold),
                                        ),
                                      ),
                                      Expanded(
                                        child: Text(
                                          address.firstName,
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Theme.of(context)
                                                .accentColor,
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                // Padding(
                                //   padding: const EdgeInsets.symmetric(
                                //       vertical: 5),
                                //   child: Row(
                                //     mainAxisAlignment:
                                //         MainAxisAlignment.spaceBetween,
                                //     crossAxisAlignment:
                                //         CrossAxisAlignment.center,
                                //     children: <Widget>[
                                //       Container(
                                //         width: 120,
                                //         child: Text(
                                //           S.of(context).email + " :",
                                //           style: TextStyle(
                                //             fontSize: 14,
                                //             color: Theme.of(context)
                                //                 .accentColor,
                                //           ),
                                //         ),
                                //       ),
                                //       Expanded(
                                //         child: Text(
                                //           " address.email",
                                //           style: TextStyle(
                                //             fontSize: 14,
                                //             color: Theme.of(context)
                                //                 .accentColor,
                                //           ),
                                //         ),
                                //       )
                                //     ],
                                //   ),
                                // ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 5),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: <Widget>[
                                      Container(
                                        width: 120,
                                        child: Text(
                                          S.of(context).streetName + " :",
                                          style: TextStyle(
                                              fontSize: 14,
                                              color: Theme.of(context)
                                                  .accentColor,
                                              fontWeight:
                                                  FontWeight.bold),
                                        ),
                                      ),
                                      Expanded(
                                        child: Text(
                                          address.street,
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Theme.of(context)
                                                .accentColor,
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 5),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: <Widget>[
                                      Container(
                                        width: 120,
                                        child: Text(
                                          S.of(context).city + " :",
                                          style: TextStyle(
                                              fontSize: 14,
                                              color: Theme.of(context)
                                                  .accentColor,
                                              fontWeight:
                                                  FontWeight.bold),
                                        ),
                                      ),
                                      Expanded(
                                        child: Text(
                                          address.city,
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Theme.of(context)
                                                .accentColor,
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                ),

                                FutureBuilder(
                                  future: Services()
                                      .widget
                                      .getCountryName(context, "EG"),
                                  builder: (context, snapshot) {
                                    print(address.country);
                                    if (snapshot.hasData) {
                                      return Padding(
                                        padding:
                                            const EdgeInsets.symmetric(
                                                vertical: 5),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment
                                                  .spaceBetween,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: <Widget>[
                                            Container(
                                              width: 120,
                                              child: Text(
                                                S.of(context).country +
                                                    " :",
                                                style: TextStyle(
                                                    fontSize: 14,
                                                    color:
                                                        Theme.of(context)
                                                            .accentColor,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                            ),
                                            Expanded(
                                              child: Text(
                                                snapshot.data,
                                                style: TextStyle(
                                                  fontSize: 14,
                                                  color: Theme.of(context)
                                                      .accentColor,
                                                ),
                                              ),
                                            )
                                          ],
                                        ),
                                      );
                                    } else {
                                      return Container();
                                    }
                                  },
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 5),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: <Widget>[
                                      Container(
                                        width: 120,
                                        child: Text(
                                          S.of(context).phoneNumber +
                                              " :",
                                          style: TextStyle(
                                              fontSize: 14,
                                              color: Theme.of(context)
                                                  .accentColor,
                                              fontWeight:
                                                  FontWeight.bold),
                                        ),
                                      ),
                                      Expanded(
                                        child: Text(
                                          address.phoneNumber,
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Theme.of(context)
                                                .accentColor,
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                // const SizedBox(height: 20),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          // ListenableProvider.value(
                          //   value: shippingMethodModel,
                          //   child: Consumer<ShippingMethodModel>(
                          //     builder: (context, model, child) {
                          //       if (model.isLoading) {
                          //         return Column(
                          //           children: [
                          //             Container(
                          //                 height: 100,
                          //                 child: Shimmer.fromColors(
                          //                   period: Duration(milliseconds: 300),
                          //                   baseColor: Color(0xff4f3933),
                          //                   highlightColor: Colors.white,
                          //                   child: Container(
                          //                     width: double.infinity,
                          //                     child: Container(
                          //                       margin: const EdgeInsets.all(8.0),
                          //                       height: 50.0,
                          //                       decoration: BoxDecoration(
                          //                         color: Colors.black.withOpacity(0.2),
                          //                         borderRadius:
                          //                         BorderRadius.circular(12.0),
                          //                       ),
                          //                     ),
                          //                   ),
                          //                 )),
                          //             Container(
                          //               height: 50,
                          //               child: Shimmer.fromColors(
                          //                 period: Duration(milliseconds: 300),
                          //                 baseColor: Color(0xff4f3933),
                          //                 highlightColor: Colors.white,
                          //                 child: Container(
                          //                   margin: const EdgeInsets.all(8.0),
                          //                   height: 50.0,
                          //                   decoration: BoxDecoration(
                          //                     color: Colors.black.withOpacity(0.2),
                          //                     borderRadius: BorderRadius.circular(12.0),
                          //                   ),
                          //                 ),
                          //               ),
                          //             )
                          //           ],
                          //         );
                          //       }
                          //
                          //       if (model.message != null) {
                          //         return Container(
                          //           height: 100,
                          //           padding: const EdgeInsets.symmetric(
                          //               horizontal: 20, vertical: 20),
                          //           child: Center(
                          //               child: Text(model.message,
                          //                   style: const TextStyle(color: kErrorRed))),
                          //         );
                          //       }
                          //
                          //       return Column(
                          //         children: <Widget>[
                          //           // SizedBox(
                          //           //   height: 10,
                          //           // ),
                          //           for (int i = 0;
                          //           i < model.shippingMethods.length;
                          //           i++)
                          //             Column(
                          //               children: <Widget>[
                          //                 Padding(
                          //                   padding: const EdgeInsets.symmetric(
                          //                       horizontal: 10),
                          //                   child: Container(
                          //                     decoration: BoxDecoration(
                          //                       borderRadius: BorderRadius.all(
                          //                         Radius.circular(10),
                          //                         // bottomRight: Radius.circular(30),
                          //                       ),
                          //                       border: Border.all(
                          //                         color: Color(0xff4f3933),
                          //                       ),
                          //                       color: i == selectedIndex
                          //                           ? Colors.white
                          //                           : Colors.transparent,
                          //                     ),
                          //                     child: Padding(
                          //                       padding: const EdgeInsets.symmetric(
                          //                           vertical: 15, horizontal: 10),
                          //                       child: Row(
                          //                         children: <Widget>[
                          //                           Radio(
                          //                             activeColor: Theme.of(context).primaryColor,
                          //                             value: i,
                          //                             groupValue: selectedIndex,
                          //                             onChanged: (i) {
                          //                               setState(() {
                          //                                 selectedIndex = i;
                          //                               });
                          //                             },
                          //                           ),
                          //                           const SizedBox(width: 10),
                          //                           Expanded(
                          //                             child: Column(
                          //                               crossAxisAlignment:
                          //                               CrossAxisAlignment.start,
                          //                               children: <Widget>[
                          //                                 Services()
                          //                                     .widget
                          //                                     .renderShippingPaymentTitle(
                          //                                     context,
                          //                                     model
                          //                                         .shippingMethods[
                          //                                     i]
                          //                                         .title),
                          //                                 const SizedBox(height: 5),
                          //                                 if (model.shippingMethods[i]
                          //                                     .cost >
                          //                                     0.0 ||
                          //                                     !isNotBlank(model
                          //                                         .shippingMethods[i]
                          //                                         .classCost))
                          //                                   Text(
                          //                                     '${model.shippingMethods[i].cost}' + 'ج.م.',
                          //                                     style: const TextStyle(
                          //                                         fontSize: 14,
                          //                                         color: kGrey400),
                          //                                   ),
                          //                                 if (model.shippingMethods[i]
                          //                                     .cost ==
                          //                                     0.0 &&
                          //                                     isNotBlank(model
                          //                                         .shippingMethods[i]
                          //                                         .classCost))
                          //                                   Text(
                          //                                     model.shippingMethods[i]
                          //                                         .classCost,
                          //                                     style: const TextStyle(
                          //                                         fontSize: 14,
                          //                                         color: kGrey400),
                          //                                   )
                          //                               ],
                          //                             ),
                          //                           )
                          //                         ],
                          //                       ),
                          //                     ),
                          //                   ),
                          //                 ),
                          //                 i < model.shippingMethods.length - 1
                          //                     ? const Divider(height: 1)
                          //                     : Container(),
                          //               ],
                          //             ),
                          //           const SizedBox(height: 20),
                          //         ],
                          //       );
                          //     },
                          //   ),
                          // ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 8, horizontal: 5),
                            child: Row(
                              mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                              crossAxisAlignment:
                                  CrossAxisAlignment.center,
                              children: <Widget>[
                                Text(
                                  S.of(context).total,
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w400,
                                    color: Theme.of(context).accentColor,
                                  ),
                                ),
                                Text(
                                    '${cartModel.getSubTotal()}' +' '+ S.of(context).currency,
                                    style: const TextStyle(
                                        fontSize: 14,
                                        color: Colors.black))
                              ],
                            ),
                          ),
                          Services()
                              .widget
                              .renderShippingMethodInfo(context),
                          if (cartModel.getCoupon() != '')
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 8, horizontal: 5),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment:
                                    CrossAxisAlignment.center,
                                children: <Widget>[
                                  Text(
                                    S.of(context).discount,
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Theme.of(context)
                                          .accentColor
                                          .withOpacity(0.8),
                                    ),
                                  ),
                                  Text(
                                    cartModel.getCoupon(),
                                    style: Theme.of(context)
                                        .textTheme
                                        .subtitle1
                                        .copyWith(
                                          fontSize: 14,
                                          color: Theme.of(context)
                                              .accentColor
                                              .withOpacity(0.8),
                                        ),
                                  )
                                ],
                              ),
                            ),
                          Services()
                              .widget
                              .renderTaxes(taxModel, context),
                          Services().widget.renderRewardInfo(context),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 8, horizontal: 5),
                            child: Row(
                              mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                              crossAxisAlignment:
                                  CrossAxisAlignment.center,
                              children: <Widget>[
                                Text(
                                  S.of(context).subtotal,
                                  style: TextStyle(
                                      fontSize: 15,
                                      color: Theme.of(context).primaryColor,
                                      fontWeight: FontWeight.bold),
                                ),
                                Text(
                                  '${cartModel.getTotal()}' +' '+ S.of(context).currency,
                                  style: TextStyle(
                                    fontSize: 15,
                                    color: Theme.of(context).primaryColor,

                                    fontWeight: FontWeight.w600,
                                    // decoration: TextDecoration.underline,
                                  ),
                                )
                              ],
                            ),
                          ),
                          const SizedBox(height: 20),
                          Align(
                            alignment: Alignment.bottomCenter,
                            child: Row(children: [
                              Expanded(
                                child: ButtonTheme(
                                  height: 55,
                                  child: RaisedButton(
                                    shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadius.circular(15.0),
                                      // side: BorderSide(color: Colors.red)
                                    ),
                                    elevation: 0,
                                    onPressed: () =>
                                        Provider.of<PaymentMethodModel>(
                                                        context,
                                                        listen: false)
                                                    .message ==
                                                null
                                            ? placeOrder(
                                                paymentMethodModel,
                                                cartModel)
                                            : null,
                                    textColor: Colors.white,
                                    color: Theme.of(context).primaryColor,
                                    child: Text(S
                                        .of(context)
                                        .placeMyOrder
                                        .toUpperCase()),
                                  ),
                                ),
                              ),
                            ]),
                          ),
                        ],
                      )),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void showSnackbar() {
    Tools.showSnackBar(
        Scaffold.of(context), S.of(context).orderStatusProcessing, context);
  }

  Future<void> placeOrder(paymentMethodModel, cartModel) async {
    // widget.onLoading(true);
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return ProcessingDialog(
          message: "جاري تنفيذ طلبك",
        );
      },
    );
    Map appsFlyerOptions = {
      "afDevKey": "ZZparsHDZ68cKuxsNbvpUJ",
      "afAppId": "1614618732",
      "isDebug": true
    };

    AppsflyerSdk appsflyerSdk = await AppsflyerSdk(appsFlyerOptions);
    appsflyerSdk.logEvent(
      "purchase",
      {
        'af_revenue': Provider.of<CartModel>(context, listen: false).getTotal(),
        'af_currency': "EGP"
        // 'pro'
      },
    );
    isPaying = true;
    if (paymentMethodModel.paymentMethods?.isNotEmpty ?? false) {
      final paymentMethod = paymentMethodModel.paymentMethods
          .firstWhere((item) => item.id == selectedId);

      Provider.of<CartModel>(context, listen: false)
          .setPaymentMethod(paymentMethod);
      Services().widget.placeOrder(
        context,
        cartModel: cartModel,
        onLoading: widget.onLoading,
        paymentMethod: paymentMethod,
        success: (Order order) async {
          // for (var item in order.lineItems) {
          //   Product product = cartModel.getProductById(item.productId);
          // }
          // widget.onFinish(order);
          // widget.onLoading(false);
          isPaying = false;
          Provider.of<CartModel>(context, listen: false).clearCart();
          print("donnnnnnnnnnnnnnnnnne");
          Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(
                  builder: (BuildContext context) => OrderedSuccess(
                        order: order,
                      )),
              ModalRoute.withName('/dashboard'));
          // MainTabs()
        },
        error: (message) {
          widget.onLoading(false);

          if (message != null) {
            // Tools.showSnackBar(Scaffold.of(context), message);
          }

          isPaying = false;
        },
      );
    }
  }

  Future<bool> createBooking(BookingInfo bookingInfo) async {
    return Services().createBooking(bookingInfo);
  }

  List<Widget> getProducts(CartModel model, BuildContext context) {
    return model.productsInCart.keys.map(
      (key) {
        String productId = Product.cleanProductID(key);

        return ShoppingCartRow(
          product: model.getProductById(productId),
          variation: model.getProductVariationById(key),
          quantity: model.productsInCart[key],
          options: model.productsMetaDataInCart[key],
        );
      },
    ).toList();
  }

  Future<void> createOrder({paid = false, cod = true}) async {
    // widget.onLoading(true);
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return ProcessingDialog(
          message: "جاري تنفيذ طلبك",
        );
      },
    );
    print(selectedId);
    print("crateORder");
    await Services().widget.createOrder(
      context,
      paid: paid,
      cod: cod,
      onLoading: widget.onLoading,
      success: (order) {
        Provider.of<CartModel>(context, listen: false).clearCart();
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (BuildContext context) => OrderedSuccess(
                      order: order,
                    )));
      },
      error: (message) {
        Navigator.pop(context);
        // Tools.showSnackBar(Scaffold.of(context), message, context);
      },
    );

    print("done");
    // widget.onLoading(false);
  }
}

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import '../../generated/l10n.dart';
import '../../models/index.dart' show Order, UserModel, PointModel;
import '../../screens/base.dart';
import '../../services/index.dart';
import 'package:flutter_svg/svg.dart';

class OrderedSuccess extends StatefulWidget {
  final Order order;
  final bool isModal;
  final PageController controller;

  OrderedSuccess({this.order, this.isModal, this.controller});

  @override
  _OrderedSuccessState createState() => _OrderedSuccessState();
}

class _OrderedSuccessState extends BaseScreen<OrderedSuccess> {
  @override
  void afterFirstLayout(BuildContext context) {
    final user = Provider.of<UserModel>(context, listen: false).user;
    if (user != null && user.cookie != null) {
      // Services().updatePoints(user.cookie, widget.order);
      // Provider.of<PointModel>(context, listen: false).getMyPoint(user.cookie);
    }
  }

  @override
  Widget build(BuildContext context) {
    final userModel = Provider.of<UserModel>(context);
    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      // resizeToAvoidBottomPadding: false,
      backgroundColor: Colors.grey.shade200,
      body: SafeArea(
        top: false,
        bottom: false,
        child: Column(
          children: [
            Container(
              height: 150,
              width: double.infinity,
              color: Colors.grey.shade200,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 40,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                          S.of(context).thanks,
                          style: GoogleFonts.tajawal(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.black)
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: 30,
                        width: 30,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Theme.of(context).primaryColor,
                        ),
                        child: Icon(Icons.check, color: Colors.white,),
                      ),
                      Container(
                        height: 5,
                        width: 100,
                        color: Theme.of(context).primaryColor,
                      ),
                      Container(
                        height: 30,
                        width: 30,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Theme.of(context).primaryColor,
                        ),
                        child: Icon(Icons.check, color: Colors.white,),

                      ),
                      Container(
                        height: 5,
                        width: 100,
                        color: Theme.of(context).primaryColor,
                      ),
                      Container(
                        height: 30,
                        width: 30,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Theme.of(context).primaryColor,
                        ),
                        child: Icon(Icons.check, color: Colors.white,),

                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 30),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          S.of(context).shippingAddress,
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 12
                          ),
                        ),
                        Text(
                          S.of(context).shippingMethod,
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 12
                          ),
                        ),
                        Text(
                          S.of(context).payment,
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 12
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              height: screenSize.height - 160,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(topRight: Radius.circular(30), topLeft: Radius.circular(30)),
                color: Colors.white
              ),


              alignment: Alignment.center,
              width: screenSize.width,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Image.asset(
                          "assets/fashion/icons8-checkmark-400.png",
                          width: screenSize.width/2,
                          color: Theme.of(context).primaryColor,

                          fit: BoxFit.fitWidth,
                        ),
                        Text(
                          S.of(context).thanks,
                          style: TextStyle(
                              fontSize: 20,
                              color: Colors.green,
                              fontWeight: FontWeight.bold),
                        ),
                        Text(
                          S.of(context).processingorder +' '+ widget.order.number ,
                          maxLines: 2,
                          style: TextStyle(
                              fontSize: 17,
                              color: Colors.green,
                              fontWeight: FontWeight.bold),
                        ),



                      ],
                    ),
                  ),
                  Text(
                    S.of(context).deliveredBy,
                    style: TextStyle(
                        fontSize: 14,
                        color: Colors.black38,
                        fontWeight: FontWeight.bold),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 10, horizontal: 30),
                    child: Row(
                      children: [
                        Expanded(
                          child: FlatButton(
                            // borderSide:
                            //     BorderSide(color: Theme.of(context).accentColor),
                            color: Theme.of(context).primaryColor,

                            child: Text(
                              S.of(context).backToShop.toUpperCase(),
                              style: TextStyle(color: Colors.white),
                            ),
                            onPressed: () {
                              if (widget.isModal != null &&
                                  widget.isModal == true) {
                                Navigator.of(context)
                                    .pushNamedAndRemoveUntil(
                                    '/dashboard', (route) => false);
                                Navigator.of(context)
                                    .popUntil((route) => route.isFirst);
                              } else {
                                Navigator.of(context)
                                    .pushNamedAndRemoveUntil(
                                    '/dashboard', (route) => false);
                              }
                            },
                            height: 45,
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                BorderRadius.circular(10.0)),
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
            // Positioned(
            //   bottom: 40,
            //   left: 0,
            //   right: 0,
            //   child: Column(
            //     children: [
            //       SizedBox(
            //         height: 15,
            //       ),
            //       Row(
            //         crossAxisAlignment: CrossAxisAlignment.start,
            //         mainAxisAlignment: MainAxisAlignment.center,
            //         children: [
            //           Image.asset(
            //             "assets/fashion/fashionLogo.jpg",
            //             width: 55,
            //             color: Colors.white,
            //             // height: screenSize.height / 2,
            //           ),
            //         ],
            //       ),
            //       SizedBox(
            //         height: 20,
            //       ),
            //       Text(
            //         "All rights reserved fashion © 2020 \n              Dokkan Agency©  ",
            //         style: TextStyle(
            //             color: Colors.white,
            //             fontWeight: FontWeight.bold,
            //             fontSize: 10),
            //       )
            //     ],
            //   ),
            // )
          ],
        ),
      ),
    );

    // Scaffold(
    //   backgroundColor: Colors.black,
    //   body: Stack(
    //     children: [
    //       ClipRRect(
    //         child: Container(
    //           // height: screenSize.height / 2,
    //           decoration: BoxDecoration(
    //             // color: Colors.red,
    //             borderRadius: BorderRadius.only(
    //                 // bottomLeft: Radius.circular(70),
    //                 // bottomRight: Radius.circular(800),
    //                 // topRight: Radius.circular(700),
    //                 ),
    //           ),
    //           child: Directionality(
    //             textDirection: TextDirection.ltr,
    //             child: SvgPicture.asset(
    //               "assets/fashion/back.svg",
    //               width: screenSize.width,

    //               // height: screenSize.height / 2,
    //               fit: BoxFit.fitWidth,
    //             ),
    //           ),
    //         ),
    //       ),

    //     ],
    //   ),
    // );
  }
}

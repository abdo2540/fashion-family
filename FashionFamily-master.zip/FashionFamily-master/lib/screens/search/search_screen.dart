import 'dart:io';

import 'package:fashion/models/entities/category.dart';
import 'package:fashion/models/entities/filter_attribute.dart';
import 'package:fashion/models/entities/filter_tags.dart';
import 'package:fashion/screens/search/widgets/filters/filter_search_attributes.dart';
import 'package:fashion/screens/search/widgets/filters/filter_search_category.dart';
import 'package:fashion/tabbar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:fashion/caco/size_config.dart';
import '../../common/constants.dart';
import '../../generated/l10n.dart';
import '../../models/app_model.dart';
import '../../models/category_model.dart';
import '../../models/filter_attribute_model.dart';
import '../../models/filter_tags_model.dart';
import '../../models/search_model.dart';
import 'package:shimmer/shimmer.dart';
import '../../share.dart';
import 'widgets/filters/filter_search.dart';
import 'widgets/recent/recent_search_custom.dart';
import 'widgets/search_box.dart';
import 'widgets/search_results_custom.dart';
import 'package:fashion/caco/shimmer_product_list_item.dart';
import 'package:flutter_svg/svg.dart';

class SearchScreen extends StatefulWidget {
  final isModal;
  final bool showChat;

  SearchScreen({Key key, this.isModal, this.showChat}) : super(key: key);

  @override
  _StateSearchScreen createState() => _StateSearchScreen();
}

class _StateSearchScreen extends State<SearchScreen>
    with AutomaticKeepAliveClientMixin<SearchScreen> {
  final Map<String, List> _listResult = Map();
  String _slugAttribute = '';


  @override
  bool get wantKeepAlive => true;

  final _searchFieldNode = FocusNode();
  final _searchFieldController = TextEditingController();

  bool isVisibleSearch = false;
  bool _showResult = false;
  List<String> _suggestSearch;

  SearchModel get _searchModel =>
      Provider.of<SearchModel>(context, listen: false);

  String get _searchKeyword => _searchFieldController.text;

//
  List<String> get suggestSearch =>
      _suggestSearch
          ?.where((s) => s.toLowerCase().contains(_searchKeyword.toLowerCase()))
          ?.toList() ??
      <String>[];

  void _onFocusChange() {
    if (_searchKeyword.isEmpty && !_searchFieldNode.hasFocus) {
      _showResult = false;
    } else {
      _showResult = !_searchFieldNode.hasFocus;
    }

    // Delayed keyboard hide and show
    Future.delayed(const Duration(milliseconds: 120), () {
      setState(() {
        isVisibleSearch = _searchFieldNode.hasFocus;
      });
    });
  }

  List<FilterTag> get _listTag {
    if (_listResult['tags'] == null) _listResult['tags'] = const <FilterTag>[];
    return _listResult['tags'];
  }

  set _listTag(value) => _listResult['tags'] = value;

  List<Category> get _listCategory {
    if (_listResult['categories'] == null) {
      _listResult['categories'] = const <Category>[];
    }
    return _listResult['categories'];
  }

  set _listCategory(value) => _listResult['categories'] = value;

  List<SubAttribute> get _listAttribute {
    if (_listResult[_slugAttribute] == null) {
      _listResult[_slugAttribute] = const <SubAttribute>[];
    }
    return _listResult[_slugAttribute];
  }

  set _listAttribute(value) => _listResult[_slugAttribute] = value;

  @override
  void initState() {
    super.initState();
    printLog("[SearchScreen] initState");
    _searchFieldNode.addListener(_onFocusChange);
  }

  @override
  void dispose() {
    printLog("[SearchScreen] dispose");
    _searchFieldNode?.dispose();
    _searchFieldController.dispose();
    super.dispose();
  }

  void _onSearchTextChange(String value) {
    if (value.isEmpty) {
      _showResult = false;
      setState(() {});
      return;
    }
    if (_searchFieldNode.hasFocus) {
      if (suggestSearch.isEmpty) {
        setState(() {
          _showResult = true;
          _searchModel.loadProduct(name: value);
        });
      } else {
        setState(() {
          _showResult = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    printLog("[SearchScreen] build");
    super.build(context);
    _suggestSearch = List<String>.from(
        Provider.of<AppModel>(context).appConfig['searchSuggestion'] ?? ['']);
    final screenSize = MediaQuery.of(context).size;
    double widthSearchBox =
        screenSize.width / (2 / (screenSize.height / screenSize.width));

    return Scaffold(
      // resizeToAvoidBottomPadding: false,
      resizeToAvoidBottomInset: false,
      backgroundColor:  Colors.grey.shade200,
      // appBar: _renderHeader(),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Container(
              width: double.infinity,
                child: _renderHeader()
            ),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(topRight: Radius.circular(30), topLeft: Radius.circular(30))
                ),
                child: ListView(
                  children: [
                    SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: SearchBox(
                        width: double.infinity,
                        controller: _searchFieldController,
                        focusNode: _searchFieldNode,
                        onChanged: _onSearchTextChange,
                        onSubmitted: _onSubmit,
                        onCancel: () {
                          setState(() {
                            isVisibleSearch = true;
                          });
                        },
                      ),
                    ),
                    SizedBox(
                      width: getProportionateScreenWidth(10),
                    ),
                    // Padding(
                    //   padding: const EdgeInsets.only(top: 5),
                    //   child: Container(
                    //     width: 50,
                    //     height: 50,
                    //     // color: Theme.of(context).primaryColor,
                    //     child: FilterSearch(
                    //       onChange: (searchFilter) {
                    //         _searchModel.searchByFilter(
                    //           searchFilter,
                    //           _searchKeyword,
                    //         );
                    //       },
                    //     ),
                    //   ),
                    // ),
                    const SizedBox(height: 8),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        // boxShadow: kElevationToShadow[12],
                        color: Theme.of(context).backgroundColor,
                      ),
                      child: Material(
                        child: Container(
                          color: Theme.of(context).backgroundColor,
                          child: SingleChildScrollView(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              // mainAxisSize: MainAxisSize.min,
                              children: <Widget>[
                                // FilterSearchTags(
                                //   onSelect: (tag, currentSlug) {
                                //     if (tag.isEmpty) {
                                //       _listResult.remove('tags');
                                //       return;
                                //     }
                                //     _listTag = tag;
                                //     setState(() {});
                                //   },
                                //   listSelected: _listTag,
                                // ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 10),
                                  child: Text(
                                    S.of(context).byCate,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 15,
                                    ),
                                  ),
                                ),
                                FilterSearchCategory(
                                  onSelect: (category, currentSlug) {
                                    if (category.isEmpty) {
                                      _listResult.remove('categories');
                                      return;
                                    }
                                    _listCategory = category;
                                    setState(() {});
                                  },
                                  listSelected: _listCategory,
                                ),
                                FilterSearchAttributes(
                                  listSelected: _listAttribute,
                                  slug: _slugAttribute,
                                  onSelect: (attributes, currentSlug) {
                                    if (attributes.isEmpty) {
                                      _listResult.remove(_slugAttribute);
                                      return;
                                    }
                                    _listAttribute = attributes;
                                    _slugAttribute = currentSlug;
                                    _listResult.removeWhere((key, value) =>
                                    !key.contains('categories') &&
                                        !key.contains('tags') &&
                                        !key.contains('$currentSlug'));
                                    if (mounted) {
                                      setState(() {});
                                    }
                                  },
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 300),
                      reverseDuration: const Duration(milliseconds: 300),
                      child: _showResult
                          ? buildResult()
                          : Align(
                        alignment: Alignment.topCenter,
                        child: Consumer<FilterTagModel>(
                          builder: (context, tagModel, child) {
                            return Consumer<CategoryModel>(
                              builder: (context, categoryModel, child) {
                                return Consumer<FilterAttributeModel>(
                                  builder:
                                      (context, attributeModel, child) {
                                    if (tagModel.isLoading ||
                                        categoryModel.isLoading ||
                                        attributeModel.isLoading) {
                                      return Container(
                                        width: double.infinity,
                                        height:
                                        getProportionateScreenHeight(
                                            200),
                                        child: ListView.separated(
                                          padding:
                                          const EdgeInsets.symmetric(
                                              horizontal: 16.0),
                                          shrinkWrap: true,
                                          scrollDirection: Axis.vertical,
                                          itemCount: 5,
                                          itemBuilder: (context, index) {
                                            return Padding(
                                              padding: EdgeInsets.symmetric(
                                                  vertical: 10),
                                              child: Shimmer.fromColors(
                                                period: Duration(
                                                    milliseconds: 500),
                                                baseColor: Colors.white
                                                    .withOpacity(0.5),
                                                highlightColor: Colors.black
                                                    .withOpacity(0.5),
                                                child: Container(
                                                  width: 150.0,
                                                  padding:
                                                  EdgeInsets.symmetric(
                                                      vertical: 10),
                                                  margin:
                                                  EdgeInsets.symmetric(
                                                      vertical: 10),
                                                  child: Padding(
                                                    padding: EdgeInsets
                                                        .symmetric(
                                                        vertical: 10,
                                                        horizontal: 10),
                                                    child:
                                                    ShimmerProductListItem(),
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                          separatorBuilder:
                                              (context, index) {
                                            return SizedBox(
                                              width: 20.0,
                                            );
                                          },
                                        ),
                                      );
                                    }
                                    var child = _buildRecentSearch();

                                    if (_searchFieldNode.hasFocus &&
                                        suggestSearch.isNotEmpty) {
                                      // child = _buildSuggestions();
                                    }

                                    return child;
                                  },
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

          ],
        ),
      ),
      floatingActionButton: Padding(
        padding: Platform.isIOS ?  EdgeInsets.only(bottom:20) : EdgeInsets.only(bottom:20),
        child: SpeedDial(
          foregroundColor: Theme.of(context).primaryColor,
          backgroundColor: Colors.white,
          icon: Icons.phone_rounded,
          activeIcon: Icons.dangerous,
          children: [
            SpeedDialChild(
                backgroundColor: Colors.transparent,
                child: SvgPicture.asset('assets/icons/phonee.svg'),
                label: 'اتصل بنا',
                onTap: (){ShareFunction().launchCaller();}),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/whatsapp.svg'),
                label: 'واتساب',
                onTap: (){ShareFunction().launchWhatApp();}),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/messenger.svg'),
                label: 'ماسنجر',
                onTap: (){ShareFunction().launchMessanger();}),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/ig.svg'),
                label: 'انستجرام',
                onTap: () {
                  ShareFunction().launchInstagram();
                }
            ),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/tiktok.svg'),
                label: 'تيك توك',
                onTap: () {
                  ShareFunction().launchTiktok();
                }
            ),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/facebook.svg'),
                label: 'صفحة الفيس بوك',
                onTap: () {
                  ShareFunction().launchFacebook();
                }
            ),

          ],
        ),
      ),

    );
  }

  PreferredSizeWidget _renderAppbar(Size screenSize) {
    //  appBar: AppBar(
    //     title: Text('Search'),
    //     centerTitle: true,
    //     automaticallyImplyLeading: false,
    //   ),
    return AppBar(
      automaticallyImplyLeading: false,
      centerTitle: true,
      backgroundColor: Theme.of(context).backgroundColor,
      title: Container(
        width: screenSize.width,
        child: Container(
          width:
              screenSize.width / (2 / (screenSize.height / screenSize.width)),
          child: Center(
            child: Text(
              S.of(context).recentSearches,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _renderHeader() {
    final screenSize = MediaQuery.of(context).size;
    Widget _headerContent = const SizedBox(height: 10.0);
    if (widget.isModal == null) {
      _headerContent = Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              elevation: 5,
              child: InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=> MainTabs()));
                },
                child: Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    // border: Border.all(color: Theme.of(context).primaryColor, width: 1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Center(child: Icon(
                    Icons.arrow_back_ios,
                    color: Theme.of(context).primaryColor,size: 20,)),
                ),
              ),
            ),

            Text(S.of(context).search,
                style: GoogleFonts.tajawal(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black)),
            Card(
              color: Colors.transparent,
              elevation: 0.0,
              child: Container(
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      width: screenSize.width,
      child: Container(
        width: screenSize.width / (2 / (screenSize.height / screenSize.width)),
        child: _headerContent,
      ),
    );
  }

  Widget _buildRecentSearch() {
    return RecentSearchesCustom(onTap: _onSubmit);
  }

  // Widget _buildSuggestions() {
  //   return Card(
  //     elevation: 0,
  //
  //     shape: RoundedRectangleBorder(
  //       borderRadius: BorderRadius.all(
  //         Radius.circular(15),
  //       ),
  //
  //     ),
  //
  //     // margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
  //     color: Theme.of(context).primaryColor.withOpacity(.1),
  //     child: ListView.builder(
  //       shrinkWrap: true,
  //       padding: const EdgeInsets.only(
  //         left: 10,
  //         right: 10,
  //       ),
  //       itemCount: suggestSearch.length,
  //       itemBuilder: (_, index) {
  //         final keyword = suggestSearch[index];
  //         return GestureDetector(
  //           onTap: () => _onSubmit(keyword),
  //           child: ListTile(
  //
  //             title: Text(keyword,style: TextStyle(color: Colors.black),),
  //           ),
  //         );
  //       },
  //     ),
  //   );
  // }

  Widget buildResult() {
    return SearchResultsCustom(
      name: _searchKeyword,
    );
  }

  void _onSubmit(String name) {
    _searchFieldController.text = name;
    setState(() {
      _showResult = true;
      _searchModel.loadProduct(name: name);
    });
    FocusScopeNode currentFocus = FocusScope.of(context);
    if (!currentFocus.hasPrimaryFocus) {
      currentFocus.unfocus();
    }
  }
}

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:fashion/caco/constants.dart';
import '../../../generated/l10n.dart';

class SearchBox extends StatefulWidget {
  final double width;
  final bool showCancelButton;
  final bool showSearchIcon;
  final bool autoFocus;
  final String initText;
  final FocusNode focusNode;
  final TextEditingController controller;
  final Function() onCancel;
  final Function(String value) onChanged;
  final Function(String value) onSubmitted;

  SearchBox({
    Key key,
    this.focusNode,
    this.onCancel,
    this.width,
    this.onChanged,
    this.controller,
    this.initText,
    this.onSubmitted,
    this.autoFocus = false,
    this.showSearchIcon = true,
    this.showCancelButton = true,
  }) : super(key: key);

  @override
  _SearchBoxState createState() => _SearchBoxState();
}

class _SearchBoxState extends State<SearchBox> {
  TextEditingController _textController;

  double get widthButtonCancel =>
      _textController.text?.isEmpty ?? true ? 0 : 50;

  String _oldSearchText = '';
  Timer _debounceQuery;

  Function(String value) get onChanged => widget.onChanged;

  @override
  void initState() {
    super.initState();
    _textController =
        widget.controller ?? TextEditingController(text: widget.initText ?? '');
    _textController.addListener(_onSearchTextChange);
  }

  @override
  void dispose() {
    if (widget.controller == null) {
      _textController.dispose();
    }
    super.dispose();
  }

  void _onSearchTextChange() {
    if (_oldSearchText != _textController.text) {
      if (_textController.text.isEmpty) {
        _oldSearchText = _textController.text;
        setState(() {});
        widget.onChanged?.call(_textController.text);
        return;
      }

      if (_debounceQuery?.isActive ?? false) _debounceQuery.cancel();
      _debounceQuery = Timer(const Duration(milliseconds: 800), () {
        _oldSearchText = _textController.text;
        widget.onChanged?.call(_textController.text);
      });
    }
  }

  // UnderlineInputBorder underlineInputBorder = UnderlineInputBorder(
  //   borderRadius: BorderRadius.circular(10),
  //   borderSide: BorderSide(color: Colors.transparent, width: .5),
  //   // gapPadding: 10,
  // );
  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(
        child: Container(
          height: 60,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(
                child: TextField(
                  decoration: InputDecoration(
                    // filled: true,
                    fillColor: Theme.of(context).primaryColor.withOpacity(.5),
                    prefixIcon: Icon(Icons.search, color: Theme.of(context).primaryColor),
                    floatingLabelBehavior: FloatingLabelBehavior.always,
                    hintText: S.of(context).searchForItems,
                    hintStyle: TextStyle(color: Colors.black),
                    alignLabelWithHint: true,
                    enabledBorder: UnderlineInputBorder(),
                    focusedBorder: UnderlineInputBorder(),
                    border: UnderlineInputBorder(),
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 0, vertical: 10),
                  ),
                  controller: _textController,
                  autofocus: widget.autoFocus ?? false,
                  focusNode: widget.focusNode,
                  onSubmitted: (value) => widget.onSubmitted?.call(value),
                ),
              ),
              if (widget.showCancelButton ?? false)
                AnimatedContainer(
                  width: widthButtonCancel,
                  // color: Colors.grey.withOpacity(.5),
                  child: GestureDetector(
                    onTap: () {
                      widget.onCancel?.call();
                      _textController.clear();
                      FocusScopeNode currentFocus = FocusScope.of(context);
                      if (!currentFocus.hasPrimaryFocus) {
                        currentFocus.unfocus();
                      }
                    },
                    child: Container(
                      child: Center(
                        child: Text(
                          S.of(context).cancel,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                  ),
                  duration: const Duration(milliseconds: 250),
                )
            ],
          ),
        ),
      ),
    ]);
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fashion/caco/home/components/home_featured_list_item.dart';
import 'package:fashion/caco/components/product_list_item.dart';
import '../../../../common/constants.dart';
import '../../../../generated/l10n.dart';
import '../../../../models/search_model.dart';
import '../../../../widgets/product/product_card_view.dart';
import 'package:fashion/models/index.dart'
    show AppModel, RecentModel, CartModel, Product;

class RecentProductsCustom extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        var screenWidth = constraints.maxWidth;

        return Consumer<SearchModel>(builder: (context, model, child) {
          if (model.products?.isEmpty ?? true) {
            return const SizedBox();
          }

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Text(
                  S.of(context).recents,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Container(
                height: 1,
                margin: const EdgeInsets.symmetric(horizontal: 10),
                color: kGrey200,
              ),
              const SizedBox(height: 10),
              Container(
                height: screenWidth ,
                child: ListView.builder(
                  scrollDirection: Axis.vertical,
                  itemCount: model.products.length,
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  itemBuilder: (_, index) => ProductListItem(product: model.products[index])

                  //     FittedBox(
                  //   child: Container(
                  //       // margin: const EdgeInsets.symmetric(horizontal: 10),
                  //       child: Container(
                  //     width: 150,
                  //     height: 180,
                  //     child: Card(
                  //       clipBehavior: Clip.antiAliasWithSaveLayer,
                  //       margin:
                  //           EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                  //       elevation: 0,
                  //       // shadowColor: kCardBackgroundColor,
                  //       shape: RoundedRectangleBorder(
                  //         borderRadius: BorderRadius.circular(15),
                  //       ),
                  //       child: Container(
                  //         margin: EdgeInsets.symmetric(horizontal: 10),
                  //         child: InkWell(
                  //           onTap: () {
                  //             Navigator.of(
                  //               context,
                  //               rootNavigator: true,
                  //               // rootNavigator: !isBigScreen(context),
                  //               // Push in tab for tablet (IPad)
                  //             ).pushNamed(
                  //               RouteList.productDetail,
                  //               arguments: model.products[index],
                  //             );
                  //           },
                  //           child: SizedBox(
                  //             width: 110,
                  //             child: Column(
                  //               crossAxisAlignment: CrossAxisAlignment.start,
                  //               mainAxisAlignment: MainAxisAlignment.start,
                  //               mainAxisSize: MainAxisSize.max,
                  //               children: [
                  //                 AspectRatio(
                  //                   aspectRatio: 1 / .9,
                  //                   child: Card(
                  //                     clipBehavior: Clip.antiAliasWithSaveLayer,
                  //                     margin: EdgeInsets.symmetric(
                  //                         horizontal: 0, vertical: 10),
                  //                     elevation: 0,
                  //                     // shadowColor: kCardBackgroundColor,
                  //                     shape: RoundedRectangleBorder(
                  //                       borderRadius: BorderRadius.circular(15),
                  //                     ),
                  //                     child: Stack(
                  //                       children: [
                  //                         GestureDetector(
                  //                           onTap: () {
                  //                             if (model.products[index]
                  //                                     .imageFeature ==
                  //                                 '') return;
                  //                             Provider.of<RecentModel>(context,
                  //                                     listen: false)
                  //                                 .addRecentProduct(
                  //                                     model.products[index]);
                  //                             //Load update product detail screen for FluxBuilder
                  //                             eventBus.fire('detail');
                  //                             Navigator.of(
                  //                               context,
                  //                               // rootNavigator: !isBigScreen(context), // Push in tab for tablet (IPad)
                  //                             ).pushNamed(
                  //                               RouteList.productDetail,
                  //                               arguments:
                  //                                   model.products[index],
                  //                             );
                  //                           },
                  //                           child: Image.network(
                  //                             model
                  //                                 .products[index].imageFeature,
                  //                             fit: BoxFit.cover,
                  //                             width: double.infinity,
                  //                             height: double.infinity,
                  //                           ),
                  //                         ),
                  //                       ],
                  //                     ),
                  //                   ),
                  //                 ),
                  //                 const SizedBox(height: 5),
                  //                 Padding(
                  //                   padding: const EdgeInsets.symmetric(
                  //                       horizontal: 0),
                  //                   child: Text(
                  //                     model.products[index].name,
                  //                     // softWrap: true,
                  //                     textAlign: TextAlign.start,
                  //                     maxLines: 2,
                  //                     overflow: TextOverflow.ellipsis,
                  //                     style: TextStyle(
                  //                       fontWeight: FontWeight.bold,
                  //                       fontSize: 15,
                  //                       // color: Colors.black.withOpacity(0.7),
                  //                     ),
                  //                   ),
                  //                 ),
                  //                 Padding(
                  //                   padding: const EdgeInsets.symmetric(
                  //                       horizontal: 5),
                  //                   child: Row(
                  //                     children: [
                  //                       // Text(
                  //                       //   // widget.product.type != 'grouped'
                  //                       //   //     ?
                  //                       //   Tools.getCurrencyFormatted(
                  //                       //       product
                  //                       //               .futcherProduct[
                  //                       //                   index]
                  //                       //               .price ??
                  //                       //           "0.0",
                  //                       //       currencyRate,
                  //                       //       currency:
                  //                       //           currency),
                  //                       //   //     :
                  //                       //   // Provider.of<ProductModel>(context).detailPriceRange,
                  //                       //   style: Theme.of(
                  //                       //           context)
                  //                       //       .textTheme
                  //                       //       .subtitle1
                  //                       //       .copyWith(
                  //                       //         fontSize:
                  //                       //             13,
                  //                       //         fontWeight:
                  //                       //             FontWeight
                  //                       //                 .w600,
                  //                       //         color: Colors
                  //                       //             .red,
                  //                       //       ),
                  //                       // ),
                  //                       // Text(
                  //                       //   '${model.products[index].price} ',
                  //                       //   style: TextStyle(
                  //                       //     fontSize: 15,
                  //                       //     fontWeight: FontWeight.w600,
                  //                       //     color: Colors.amber,
                  //                       //   ),
                  //                       // ),
                  //                       // Text(
                  //                       //   "ج.م",
                  //                       //   style: TextStyle(
                  //                       //     fontSize: 13,
                  //                       //     fontWeight: FontWeight.w600,
                  //                       //     color: Colors.amber,
                  //                       //   ),
                  //                       // )
                  //
                  //                       // (widget.product.salePrice != 0)
                  //                       //     ? Text(
                  //                       //         '\$${widget.product.salePrice}',
                  //                       //         style: TextStyle(
                  //                       //             fontSize: 14.5,
                  //                       //             color: Colors.grey,
                  //                       //             decoration: TextDecoration.lineThrough),
                  //                       //       )
                  //                       //
                  //                     ],
                  //                   ),
                  //                 ),
                  //                 // SizedBox(width: 3),
                  //                 // (model.products[index].regularPrice != "")
                  //                 //     ? Padding(
                  //                 //         padding: const EdgeInsets.symmetric(
                  //                 //             horizontal: 5),
                  //                 //         child: Text(
                  //                 //           "${model.products[index].regularPrice}\ج.م",
                  //                 //           style: Theme.of(context)
                  //                 //               .textTheme
                  //                 //               .subtitle1
                  //                 //               .copyWith(
                  //                 //                 fontSize: 11.5,
                  //                 //                 color: Theme.of(context)
                  //                 //                     .accentColor
                  //                 //                     .withOpacity(0.6),
                  //                 //                 fontWeight: FontWeight.w400,
                  //                 //                 decoration: TextDecoration
                  //                 //                     .lineThrough,
                  //                 //               ),
                  //                 //         ),
                  //                 //       )
                  //                 //     : Container()
                  //               ],
                  //             ),
                  //           ),
                  //         ),
                  //       ),
                  //     ),
                  //   )),
                  //
                  //   //  ProductCard(
                  //   //   item: model.products[index],
                  //   //   width: screenWidth * 0.35,
                  //   // ),
                  // ),
                ),
              ),
            ],
          );
        });
      },
    );
  }
}

import 'dart:io';

import 'package:fashion/screens/index.dart';
import 'package:fashion/tabbar.dart';
import 'package:flutter/cupertino.dart' show CupertinoIcons;
import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:notification_permissions/notification_permissions.dart';
import 'package:provider/provider.dart';
import 'package:rate_my_app/rate_my_app.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../common/config.dart' as config;
import 'package:flutter_widget_from_html/src/html_widget.dart';

import '../../common/config.dart';
import '../../common/constants.dart';
import '../../common/tools.dart';
import '../../generated/l10n.dart';
import 'package:fashion/screens/detail/review.dart';
import 'package:fashion/screens/detail/product_variant.dart';
import 'package:fashion/screens/detail/product_title.dart';
import 'package:fashion/screens/detail/product_description.dart';
import '../../models/index.dart' show AppModel, User, UserModel, WishListModel;
import 'package:fashion/widgets/product/heart_button.dart';
import '../../screens/blogs/post_screen.dart';
import '../../services/index.dart';
import '../../share.dart';
import '../../widgets/common/webview.dart';
import '../custom/smartchat.dart';
import '../users/user_point.dart';
import '../users/user_update.dart';
import 'currencies.dart';
import 'language.dart';
import 'notification.dart';
import 'package:flutter_svg/svg.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:sizer/sizer.dart';

class SettingScreen extends StatefulWidget {
  final List<dynamic> settings;
  final String background;
  final User user;
  final VoidCallback onLogout;
  final bool showChat;

  SettingScreen({
    this.user,
    this.onLogout,
    this.settings,
    this.background,
    this.showChat,
  });

  @override
  State<StatefulWidget> createState() {
    return SettingScreenState();
  }
}

class SettingScreenState extends State<SettingScreen>
    with
        TickerProviderStateMixin,
        WidgetsBindingObserver,
        AutomaticKeepAliveClientMixin<SettingScreen> {
  @override
  bool get wantKeepAlive => true;

  final bannerHigh = 150.0;
  bool enabledNotification = true;
  final RateMyApp _rateMyApp = RateMyApp(
      // rate app on store
      minDays: 3,
      minLaunches: 3,
      remindDays: 1,
      remindLaunches: 10,
      googlePlayIdentifier: kStoreIdentifier['android'],
      appStoreIdentifier: kStoreIdentifier['ios']);

  @override
  void initState() {
    super.initState();

    Future.delayed(Duration.zero, () async {
      await checkNotificationPermission();
    });
    _rateMyApp.init().then((_) {
      // state of rating the app
      if (_rateMyApp.shouldOpenDialog) {
        _rateMyApp.showRateDialog(
          context,

          title: S.of(context).rateTheApp,
          // The dialog title.
          message: S.of(context).rateThisAppDescription,
          // The dialog message.
          rateButton: S.of(context).rate.toUpperCase(),
          // The dialog "rate" button text.
          noButton: S.of(context).noThanks.toUpperCase(),
          // The dialog "no" button text.
          laterButton: S.of(context).maybeLater.toUpperCase(),

          // The dialog "later" button text.
          listener: (button) {
            // The button click listener (useful if you want to cancel the click event).
            switch (button) {
              case RateMyAppDialogButton.rate:
                break;
              case RateMyAppDialogButton.later:
                break;
              case RateMyAppDialogButton.no:
                break;
            }

            return true; // Return false if you want to cancel the click event.
          },
          // Set to false if you want to show the native Apple app rating dialog on iOS.
          dialogStyle: const DialogStyle(
              titleStyle: TextStyle(color: Color(0xff4f3933))),
          // Custom dialog styles.
          // Called when the user dismissed the dialog (either by taping outside or by pressing the "back" button).
          // actionsBuilder: (_) => [], // This one allows you to use your own buttons.
        );
      }
    });
  }

  @override
  void dispose() {
    Utils.setStatusBarWhiteForeground(false);
    super.dispose();
  }

  Future<void> checkNotificationPermission() async {
    if (!isAndroid || isIos) {
      return;
    }

    try {
      await NotificationPermissions.getNotificationPermissionStatus()
          .then((status) {
        if (mounted) {
          setState(() {
            enabledNotification = status == PermissionStatus.granted;
          });
        }
      });
    } catch (err) {
      printLog('[Settings Screen] : ${err.toString()}');
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      checkNotificationPermission();
    }
  }

  User firebaseUser;
  @override
  Widget build(BuildContext context) {
    Utils.setStatusBarWhiteForeground(false);
    super.build(context);

    bool loggedIn = Provider.of<UserModel>(context).loggedIn;
    final screenSize = MediaQuery.of(context).size;
    List<dynamic> settings = widget.settings ?? kDefaultSettings;
    String background = widget.background ?? kProfileBackground;
    final bool showChat = widget.showChat ?? false;
    const textStyle = TextStyle(fontSize: 20, fontWeight: FontWeight.bold);
    var width = MediaQuery.of(context).size.width;
    var height = MediaQuery.of(context).size.height;
    return Scaffold(
        backgroundColor: Theme.of(context).primaryColor.withOpacity(0.1),
        body: Container(
          width: double.infinity,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(
                    left: 10, right: 10, top: 25, bottom: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      elevation: 5,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => MainTabs()));
                        },
                        child: Container(
                          height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            // border: Border.all(color: Theme.of(context).primaryColor, width: 1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Icon(
                            Icons.arrow_back_ios,
                            color: Theme.of(context).primaryColor,
                            size: 20,
                          ),
                        ),
                      ),
                    ),
                    Text(
                      S.of(context).settings,
                      style: const TextStyle(
                        fontSize: 18,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Card(
                      color: Colors.transparent,
                      elevation: 0.0,
                      child: Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                          color: Colors.transparent,
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                  width: 30.0.w,
                  height: 30.0.w,
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor,
                    shape: BoxShape.circle,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(25.0),
                    child: Image.asset(
                      "assets/fashion/user (1).png",
                      width: 20.0.w,
                      color: Colors.white,
                    ),
                  )),
              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      loggedIn
                          ? Column(
                              children: [
                                Text(
                                  widget.user.name != null
                                      ? widget.user.name
                                      : "",
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w400,
                                      color: Colors.black),
                                ),
                                Text(
                                  widget.user.email != null
                                      ? widget.user.email
                                      : "",
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w400,
                                      color: Colors.black),
                                ),
                              ],
                            )
                          : InkWell(
                              onTap: () {
                                if (!loggedIn) {
                                  Navigator.of(
                                    context,
                                    rootNavigator: true,
                                  ).pushNamed(RouteList.login);
                                  return;
                                }
                                Provider.of<UserModel>(context, listen: false)
                                    .logout();
                                if (kLoginSetting['IsRequiredLogin'] ?? false) {
                                  Navigator.of(
                                    context,
                                    rootNavigator: true,
                                  ).pushNamedAndRemoveUntil(
                                    RouteList.login,
                                    (route) => false,
                                  );
                                }
                              },
                              child: Column(
                                children: [
                                  Text(
                                    S.of(context).userName,
                                    style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.black),
                                  ),
                                  Text(
                                    S.of(context).pressTo,
                                    style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.black),
                                  ),
                                ],
                              )),
                      // loggedIn
                      //     ? Text(
                      //         widget.user.email != null
                      //             ? widget.user.email
                      //             : "",
                      //         style: TextStyle(
                      //             fontSize: 20,
                      //             fontWeight: FontWeight.w400,
                      //             color: Colors.black),
                      //       )
                      //     : InkWell(
                      //         onTap: () {
                      //           if (!loggedIn) {
                      //             Navigator.of(
                      //               context,
                      //               rootNavigator: true,
                      //             ).pushNamed(RouteList.login);
                      //             return;
                      //           }
                      //           Provider.of<UserModel>(context,
                      //                   listen: false)
                      //               .logout();
                      //           if (kLoginSetting[
                      //                   'IsRequiredLogin'] ??
                      //               false) {
                      //             Navigator.of(
                      //               context,
                      //               rootNavigator: true,
                      //             ).pushNamedAndRemoveUntil(
                      //               RouteList.login,
                      //               (route) => false,
                      //             );
                      //           }
                      //         },
                      //         child: Column(
                      //           children: [
                      //             Text(
                      //               "اسم المستخدم",
                      //               style: TextStyle(
                      //                   fontSize: 20,
                      //                   fontWeight: FontWeight.w400,
                      //                   color: Colors.black),
                      //             ),
                      //             Text(
                      //               "اضغط لتسجيل الدخول",
                      //               style: TextStyle(
                      //                   fontSize: 20,
                      //                   fontWeight: FontWeight.w400,
                      //                   color: Colors.black),
                      //             ),
                      //           ],
                      //         )
                      //       )
                    ],
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                ],
              ),
              SizedBox(height: 20,),
              Expanded(
                child: Container(
                    width: double.infinity,
                    // height: screenSize.height * .54,
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        // color: Color(0xff4f3933),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(24),
                          topRight: Radius.circular(24),
                          bottomLeft: Radius.circular(24),
                          bottomRight: Radius.circular(24),
                        )),
                    child: ListView(
                      scrollDirection: Axis.vertical,
                      physics: BouncingScrollPhysics(),
                      // mainAxisAlignment: MainAxisAlignment.start,
                      // crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        InkWell(
                          onTap: () {
                            loggedIn
                                ? Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => UserUpdate()))
                                : Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => LoginScreen()));
                          },
                          child: Container(
                              width: double.infinity,
                              height: 70,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                color: Colors.white,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        height: 50,
                                        width: 50,
                                        decoration: BoxDecoration(
                                          color: Theme.of(context)
                                              .primaryColor
                                              .withOpacity(0.1),
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                        child: Stack(
                                          children: [
                                            Center(
                                                child: Icon(
                                              Icons.person_outline,
                                              color:
                                                  Theme.of(context).primaryColor,
                                              size: 30,
                                            )),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  right: 10, top: 10),
                                              child: Icon(
                                                Icons.settings_outlined,
                                                color: Theme.of(context)
                                                    .primaryColor,
                                                size: 15,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        S.of(context).generalSetting,
                                        style: TextStyle(
                                          color: Theme.of(context).primaryColor,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Card(
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    elevation: 5,
                                    child: Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        // border: Border.all(color: Theme.of(context).primaryColor, width: 1),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Center(
                                          child: Icon(
                                        Icons.arrow_forward_ios,
                                        color: Theme.of(context).primaryColor,
                                        size: 20,
                                      )),
                                    ),
                                  ),
                                ],
                              )),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Language()));
                          },
                          child: Container(
                              width: double.infinity,
                              height: 70,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                color: Colors.white,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        height: 50,
                                        width: 50,
                                        decoration: BoxDecoration(
                                          color: Theme.of(context)
                                              .primaryColor
                                              .withOpacity(0.1),
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                        child: Center(
                                            child: Icon(
                                          Icons.language,
                                          color: Theme.of(context).primaryColor,
                                        )),
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        S.of(context).language,
                                        style: TextStyle(
                                          color: Theme.of(context).primaryColor,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Card(
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    elevation: 5,
                                    child: Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        // border: Border.all(color: Theme.of(context).primaryColor, width: 1),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Center(
                                          child: Icon(
                                        Icons.arrow_forward_ios,
                                        color: Theme.of(context).primaryColor,
                                        size: 20,
                                      )),
                                    ),
                                  ),
                                ],
                              )),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        InkWell(
                          onTap: () {
                            loggedIn
                                ? Navigator.pushNamed(context, "/orders")
                                : Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => LoginScreen()));
                          },
                          child: Container(
                              width: double.infinity,
                              height: 70,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                color: Colors.white,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        height: 50,
                                        width: 50,
                                        decoration: BoxDecoration(
                                          color: Theme.of(context)
                                              .primaryColor
                                              .withOpacity(0.1),
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                        child: Center(
                                            child: SvgPicture.asset(
                                          'assets/fashion/check-list.svg',
                                          height: 30,
                                          width: 30,
                                          color: Theme.of(context).primaryColor,
                                        )),
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        S.of(context).orderHistory,
                                        style: TextStyle(
                                          color: Theme.of(context).primaryColor,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Card(
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    elevation: 5,
                                    child: Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        // border: Border.all(color: Theme.of(context).primaryColor, width: 1),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Center(
                                          child: Icon(
                                        Icons.arrow_forward_ios,
                                        color: Theme.of(context).primaryColor,
                                        size: 20,
                                      )),
                                    ),
                                  ),
                                ],
                              )),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        InkWell(
                          onTap: () {
                            launch('tel:01094575555');
                          },
                          child: Container(
                              width: double.infinity,
                              height: 70,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                color: Colors.white,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        height: 50,
                                        width: 50,
                                        decoration: BoxDecoration(
                                          color: Theme.of(context)
                                              .primaryColor
                                              .withOpacity(0.1),
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                        child: Icon(
                                          Icons.support_agent_outlined,
                                          size: 30,
                                          color: Theme.of(context).primaryColor,
                                        ),
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        S.of(context).complain,
                                        style: TextStyle(
                                          color: Theme.of(context).primaryColor,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Card(
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    elevation: 5,
                                    child: Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        // border: Border.all(color: Theme.of(context).primaryColor, width: 1),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Center(
                                          child: Icon(
                                        Icons.arrow_forward_ios,
                                        color: Theme.of(context).primaryColor,
                                        size: 20,
                                      )),
                                    ),
                                  ),
                                ],
                              )),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        InkWell(
                          onTap: () {
                            if (!loggedIn) {
                              Navigator.of(
                                context,
                                rootNavigator: true,
                              ).pushNamed(RouteList.login);
                              return;
                            }
                            Provider.of<UserModel>(context, listen: false)
                                .logout();
                            if (kLoginSetting['IsRequiredLogin'] ?? false) {
                              Navigator.of(
                                context,
                                rootNavigator: true,
                              ).pushNamedAndRemoveUntil(
                                RouteList.login,
                                (route) => false,
                              );
                            }
                          },
                          child: Container(
                            width: double.infinity,
                            height: 70,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: Colors.white,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                        color: Theme.of(context)
                                            .primaryColor
                                            .withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Center(
                                        child: SvgPicture.asset(
                                          loggedIn
                                              ? 'assets/fashion/logout.svg'
                                              : 'assets/fashion/login.svg',
                                          color: Theme.of(context).primaryColor,
                                          height: 30,
                                          width: 30,
                                          fit: BoxFit.scaleDown,
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      loggedIn
                                          ? S.of(context).signOut
                                          : S.of(context).signIn,
                                      style: TextStyle(
                                        color: Theme.of(context).primaryColor,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 15,
                                      ),
                                    ),
                                  ],
                                ),
                                Card(
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  elevation: 5,
                                  child: Container(
                                    height: 50,
                                    width: 50,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      // border: Border.all(color: Theme.of(context).primaryColor, width: 1),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Center(
                                        child: Icon(
                                      Icons.arrow_forward_ios,
                                      color: Theme.of(context).primaryColor,
                                      size: 20,
                                    )),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                      ],
                    )),
              ),

            ],
          ),
        ),
      floatingActionButton: Padding(
        padding: Platform.isIOS ?  EdgeInsets.only(bottom:90) : EdgeInsets.only(bottom:60),
        child: SpeedDial(
          foregroundColor: Theme.of(context).primaryColor,
          backgroundColor: Colors.white,
          icon: Icons.phone_rounded,
          activeIcon: Icons.dangerous,
          children: [
            SpeedDialChild(
                backgroundColor: Colors.transparent,
                child: SvgPicture.asset('assets/icons/phonee.svg'),
                label: 'اتصل بنا',
                onTap: (){ShareFunction().launchCaller();}),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/whatsapp.svg'),
                label: 'واتساب',
                onTap: (){ShareFunction().launchWhatApp();}),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/messenger.svg'),
                label: 'ماسنجر',
                onTap: (){ShareFunction().launchMessanger();}),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/ig.svg'),
                label: 'انستجرام',
                onTap: () {
                  ShareFunction().launchInstagram();
                }
            ),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/tiktok.svg'),
                label: 'تيك توك',
                onTap: () {
                  ShareFunction().launchTiktok();
                }
            ),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/facebook.svg'),
                label: 'صفحة الفيس بوك',
                onTap: () {
                  ShareFunction().launchFacebook();
                }
            ),

          ],
        ),
      ),

    );
  }

  void _showSheet(context, product) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20), topRight: Radius.circular(20)),
      ),
      builder: (context) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: .7,
          maxChildSize: .9,
          builder: (context, controller) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    width: 90,
                    height: 10,
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [],
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Expanded(
                  child: Center(
                    child: ListView(
                      controller: controller,
                      physics: BouncingScrollPhysics(),
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: ProductTitle(product),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 20),
                              child: ProductDescription(product),
                            ),
                            SizedBox(
                              height: 30,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: ProductVariant(product),
                            ),
                            Reviews(product.id),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _makePhoneCall(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../common/tools.dart';
import '../../generated/l10n.dart';
import '../../models/app_model.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_svg/svg.dart';

class Language extends StatefulWidget {
  @override
  _LanguageState createState() => _LanguageState();
}

class _LanguageState extends State<Language> {
  final GlobalKey<ScaffoldState> _scaffordKey = GlobalKey<ScaffoldState>();

  void _showLoading(String language) {
    final snackBar = SnackBar(
      content: Text(
        S.of(context).languageSuccess,
        style: GoogleFonts.tajawal(fontSize: 16),
      ),
      duration: const Duration(seconds: 2),
      backgroundColor: Theme.of(context).primaryColor,
      action: SnackBarAction(
        label: language,
        onPressed: () {},
      ),
    );
    // ignore: deprecated_member_use
    _scaffordKey.currentState.showSnackBar(snackBar);
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    List<Widget> list = [];
    List<Map<String, dynamic>> languages = Utils.getLanguagesList(context);
    for (var i = 0; i < languages.length; i++) {
      list.add(
        Card(
          margin: const EdgeInsets.all(10.0),
          elevation: 7,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15.0),
          ),
          child: ListTile(
            leading: Icon(Icons.language, color: Theme.of(context).primaryColor,),
            title: Text(
              languages[i]["name"],
              style: GoogleFonts.tajawal(fontSize: 16, color: Theme.of(context).primaryColor),
            ),
            onTap: () async {
              await Provider.of<AppModel>(context, listen: false)
                  .changeLanguage(languages[i]["code"], context);
              setState(() {});
              // _showLoading(languages[i]["text"]);
            },
          ),
        ),
      );
      if (i < languages.length - 1) {
        list.add(
          const Divider(
            color: Colors.transparent,
            height: 1.0,
            //endIndent: 20,
          ),
        );
      }
    }
    return Scaffold(
      key: _scaffordKey,
      backgroundColor: Theme.of(context).backgroundColor,
      // appBar: AppBar(
      //   title: Text(
      //     S.of(context).language,
      //     style: GoogleFonts.tajawal(
      //         fontSize: 20, color: Colors.black),
      //   ),
      //   backgroundColor: Colors.grey.shade200,
      //   centerTitle: true,
      //   leading: Center(
      //     child: GestureDetector(
      //       child: const Icon(
      //         Icons.arrow_back_ios,
      //         color: Colors.white,
      //       ),
      //       onTap: () => Navigator.pop(context),
      //     ),
      //   ),
      // ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            children: [
              Container(
                color: Theme.of(context).primaryColor.withOpacity(0.1),
                height: 60,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      InkWell(
                        onTap: () {
                          Navigator.pop(context);
                          },
                        child: Card(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          elevation: 5,
                          child: Container(
                            height: 50,
                            width: 50,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              // border: Border.all(color: Theme.of(context).primaryColor, width: 1),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Center(
                              child: Icon(
                                  Icons.arrow_back_ios,
                                  color: Colors.black,
                                size: 20,
                                ),
                            ),


                          ),
                        ),
                      ),
                      Text(
                        S.of(context).language,
                        style: const TextStyle(
                          fontSize: 18,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(
                          Icons.arrow_back_ios,
                          color: Colors.transparent,
                        ),
                        onPressed: () {},
                      ),
                      // Container()
                    ],
                  ),
                ),
              ),

              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30),
                  )
                ),
                child: Column(
                  children: [
                    SizedBox(
                      height: 20,
                    ),
                    ...list,
                    const SizedBox(height: 100),


                  ],
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}

import 'package:apple_sign_in/apple_sign_in.dart';
import 'package:fashion/screens/checkout/processing_dialog.dart';
import 'package:fashion/text_field.dart';
import 'package:fashion/widgets/common/login_animation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_styled_toast/flutter_styled_toast.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../common/config.dart';
import '../../common/constants.dart';
import '../../common/tools.dart';
import '../../generated/l10n.dart';
// import 'package:steng/widgets/processing_dialog.dart';
import '../../models/cart/cart_base.dart';
import '../../models/cart/cart_model.dart';
import '../../models/point_model.dart';
import '../../models/user_model.dart';
import '../../screens/base.dart';
import '../../services/index.dart';

import 'dart:async';

import 'package:country_code_picker/country_code.dart';
import 'package:sizer/sizer.dart';

import 'login_sms/verify.dart';

class LoginScreen extends StatefulWidget {
  final bool fromCart;
  final Function onLoginSuccess;

  LoginScreen({this.fromCart = false, this.onLoginSuccess});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends BaseScreen<LoginScreen>
    with TickerProviderStateMixin {
  final TextEditingController username = TextEditingController();
  final TextEditingController password = TextEditingController();

  final usernameNode = FocusNode();
  final passwordNode = FocusNode();
  CountryCode countryCode;
  String phoneNumber;
  String _phone;
  var parentContext;
  final _auth = FirebaseAuth.instance;
  bool isLoading = false;
  bool isAvailableApple = false;
  final StreamController<PhoneAuthCredential> _verifySuccessStream =
  StreamController<PhoneAuthCredential>.broadcast();
  AnimationController _loginButtonController;
  final TextEditingController _controller = TextEditingController(text: '');
  @override
  void initState() {
    super.initState();
    _loginButtonController = AnimationController(
        duration: const Duration(milliseconds: 3000), vsync: this);
    _loginButtonController = AnimationController(
      duration: const Duration(milliseconds: 3000),
      vsync: this,
    );

    _phone = '';
    countryCode = CountryCode(
      code: LoginSMSConstants.countryCodeDefault,
      dialCode: LoginSMSConstants.dialCodeDefault,
      name: LoginSMSConstants.nameDefault,
    );
    _controller.addListener(() {
      if (_controller.text != _phone && _controller.text != '') {
        _phone = _controller.text;
        onPhoneNumberChange(
          _phone,
          '+20$_phone',
          countryCode.code,
        );
      }
    });
  }

  Future<Null> _playAnimation() async {
    try {
      setState(() {
        isLoading = true;
      });
    } on TickerCanceled {
      printLog('[_playAnimation] error');
    }
  }

  Future<Null> _stopAnimation(context) async {
    try {
      await _loginButtonController.reverse();
      setState(() {
        isLoading = false;
      });
      // Navigator.pop(context);
    } on TickerCanceled {
      printLog('[_stopAnimation] error');
    }
  }

  void _failMessage(message, context) {
    /// Showing Error messageSnackBarDemo
    /// Ability so close message
    final snackBar = showToast('$message',
        context: context,
        animation: StyledToastAnimation.slideFromTopFade,
        reverseAnimation: StyledToastAnimation.slideToTopFade,
        backgroundColor: Theme.of(context).primaryColor,
        position: StyledToastPosition(align: Alignment.topCenter, offset: 6.0),
        startOffset: Offset(0.0, 2),
        reverseEndOffset: Offset(0.0, 2),
        duration: Duration(seconds: 2),
        //Animation duration   animDuration * 2 <= duration
        animDuration: Duration(milliseconds: 500),
        curve: Curves.fastLinearToSlowEaseIn,
        reverseCurve: Curves.fastOutSlowIn);

    // Scaffold.of(context)
    //   // ignore: deprecated_member_use
    //   ..removeCurrentSnackBar()
    //   // ignore: deprecated_member_use
    //   ..showSnackBar(snackBar);
  }

  void onPhoneNumberChange(
      String number,
      String internationalizedPhoneNumber,
      String isoCode,
      ) {
    if (internationalizedPhoneNumber.isNotEmpty) {
      phoneNumber = internationalizedPhoneNumber;
    } else {
      phoneNumber = null;
    }
  }

  _loginGoogle(context) async {
    // await _playAnimation();
    showUpdatingDialog();
    await Provider.of<UserModel>(context, listen: false).loginGoogle(
        success: (user) {
          //hideLoading();

          Navigator.pop(context);
          _stopAnimation(context);
          _welcomeMessage(user, context);
        },
        fail: (message) {
          //hideLoading();

          Navigator.pop(context);
          _failMessage(message, context);
        },
        context: context);
  }

  Future<void> _loginSMS(context) async {
    if (phoneNumber == null) {
      Tools.showSnackBar(
          Scaffold.of(context), S.of(context).pleaseInput, context);
    } else {
      await _playAnimation();
      final PhoneCodeAutoRetrievalTimeout autoRetrieve = (String verId) {
        _stopAnimation(context);
      };

      final PhoneCodeSent smsCodeSent = (String verId, [int forceCodeResend]) {
        _stopAnimation(context);

        // Navigator.push(
        //   context,
        //   MaterialPageRoute(
        //     builder: (context) => VerifyCode(
        //       fromCart: widget.fromCart,
        //       verId: verId,
        //       phoneNumber: phoneNumber,
        //       verifySuccessStream: _verifySuccessStream.stream,
        //     ),
        //   ),
        // );
      };

      final PhoneVerificationCompleted verifiedSuccess =
          _verifySuccessStream.add;

      final PhoneVerificationFailed veriFailed =
          (FirebaseAuthException exception) {
        _stopAnimation(context);
        _failMessage(exception.message, context);
      };

      await FirebaseAuth.instance.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        codeAutoRetrievalTimeout: autoRetrieve,
        codeSent: smsCodeSent,
        timeout: const Duration(seconds: 120),
        verificationCompleted: verifiedSuccess,
        verificationFailed: veriFailed,
      );
    }
  }

  @override
  Future<void> afterFirstLayout(BuildContext context) async {
    try {
      isAvailableApple = await AppleSignIn.isAvailable();
      setState(() {});
    } catch (e) {
      printLog('[Login] afterFirstLayout error');
    }
  }

  @override
  void dispose() {
    _loginButtonController.dispose();
    super.dispose();
  }

  void _preloadAddress(BuildContext context) {
    Provider.of<CartModel>(context, listen: false).getAddress();
  }

  Future _welcomeMessage(user, context) async {
    Provider.of<CartModel>(context, listen: false).setUser(user);
    if (user.cookie != null &&
        (kAdvanceConfig["EnableSyncCartFromWebsite"] ?? true)) {
      await Services().widget.syncCartFromWebsite(user.cookie, context);
      // await Provider.of<PointModel>(context, listen: false)
      //     .getMyPoint(user.cookie);
    }

    _preloadAddress(context);

    if (widget.onLoginSuccess != null) {
      widget.onLoginSuccess(context);
    } else {
      if (widget.fromCart) {
        Navigator.of(context).pop(user);
      } else {
        if (user.name != null) {
          Tools.showSnackBar(Scaffold.of(context),
              S.of(context).welcome + ' ${user.name} !', context);
        }

        await Navigator.of(context, rootNavigator: true)
            .pushReplacementNamed(RouteList.dashboard);
      }
    }
  }

  _loginFacebook(context) async {
    //showLoading();
    await _playAnimation();
    await Provider.of<UserModel>(context, listen: false).loginFB(
        success: (user) {
          //hideLoading();
          _stopAnimation(context);
          _welcomeMessage(user, context);
        },
        fail: (message) {
          //hideLoading();

          _failMessage(message, context);
          _stopAnimation(context);
        },
        context: context);
  }

  _loginApple(context) async {
    showUpdatingDialog();
    await Provider.of<UserModel>(context, listen: false).loginApple(
        success: (user) {
          // Navigator.pop(context);
          _welcomeMessage(user, context);
        },
        fail: (message) {
          Navigator.pop(context);
          _failMessage(message, context);
        },
        context: context);
  }

  showUpdatingDialog() async {
    return showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return ProcessingDialog(
          message: S.of(context).pleaseWait,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    parentContext = context;
    Future<void> _loginSMS(context) async {
      if (phoneNumber == null) {
        Tools.showSnackBar(
            Scaffold.of(context), S.of(context).pleaseInput, context);
      } else {
        await _playAnimation();
        showUpdatingDialog();
        final PhoneCodeAutoRetrievalTimeout autoRetrieve = (String verId) {
          _stopAnimation(context);
        };

        final PhoneCodeSent smsCodeSent =
            (String verId, [int forceCodeResend]) {
          Navigator.pop(context);
          _stopAnimation(context);

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => VerifyCode(
                fromCart: widget.fromCart,
                verId: verId,
                phoneNumber: phoneNumber,
                verifySuccessStream: _verifySuccessStream.stream,
              ),
            ),
          );
        };

        final PhoneVerificationCompleted verifiedSuccess =
            _verifySuccessStream.add;

        final PhoneVerificationFailed veriFailed =
            (FirebaseAuthException exception) {
          _stopAnimation(context);
          Navigator.pop(context);
          _failMessage(exception.message, context);
        };

        await FirebaseAuth.instance.verifyPhoneNumber(
          phoneNumber: phoneNumber,
          codeAutoRetrievalTimeout: autoRetrieve,
          codeSent: smsCodeSent,
          timeout: const Duration(seconds: 120),
          verificationCompleted: verifiedSuccess,
          verificationFailed: veriFailed,
        );
      }
    }

    _loginGoogle(context) async {
      // await _playAnimation();
      showUpdatingDialog();
      await Provider.of<UserModel>(context, listen: false).loginGoogle(
          success: (user) {
            //hideLoading();

            Navigator.pop(context);
            _stopAnimation(context);
            _welcomeMessage(user, context);
          },
          fail: (message) {
            //hideLoading();

            Navigator.pop(context);
            _failMessage(message, context);
          },
          context: context);
    }

    var screenSize = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomPadding: false,
      backgroundColor: Colors.white,
      body: SafeArea(
        top: false,
        child: LayoutBuilder(
          builder: (context, constraints) =>
              OrientationBuilder(builder: (context, orientation) {
                SizerUtil().init(constraints, orientation);
                return Builder(
                  builder: (context) => GestureDetector(
                    onTap: () => Utils.hideKeyboard(context),
                    child: Center(
                      child: Stack(
                        children: [
                          Image.asset(
                            "assets/fashion/login2.jpg",
                            width: double.infinity,
                            height: double.infinity,
                            // height: 80,
                            fit: BoxFit.cover,
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              SizedBox(
                                height: 30,
                              ),
                              Container(
                                  height: MediaQuery.of(context).size.height*0.4,
                                  decoration: new BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(30),
                                        topRight: Radius.circular(30),
                                      )), //so you don't have to change MaterialApp canvasColor
                                  child: ListenableProvider.value(
                                    value: Provider.of<UserModel>(context),
                                    child: Consumer<UserModel>(
                                        builder: (context, model, child) {
                                          return // constraints: const BoxConstraints(maxWidth: 700),
                                            SingleChildScrollView(
                                              physics: NeverScrollableScrollPhysics(),
                                              child: Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                MainAxisAlignment.start,
                                                children: <Widget>[
                                                  // Center(
                                                  //   child: Image.asset(
                                                  //     'assets/icons/wall.png',
                                                  //     height: 120,
                                                  //     width: 120.0,
                                                  //   ),
                                                  // ),
                                                  // SizedBox(
                                                  //   height: 4.0.h,
                                                  // ),
                                                  // Padding(
                                                  //   padding: const EdgeInsets.symmetric(
                                                  //       horizontal: 18),
                                                  //   child: Text(
                                                  //     'تسجيل الدخول',
                                                  //     style: TextStyle(
                                                  //       fontSize: 30,
                                                  //       fontWeight: FontWeight.bold,
                                                  //       color: Colors.black,
                                                  //     ),
                                                  //   ),
                                                  // ),
                                                  // Container(
                                                  //   margin: EdgeInsets.only(
                                                  //       right: 20.0, top: 10.0),
                                                  //   child: Text(
                                                  //     ' برقم الهاتف ',
                                                  //     style: TextStyle(
                                                  //       fontSize: 28,
                                                  //       fontWeight: FontWeight.bold,
                                                  //     ),
                                                  //   ),
                                                  // ),

                                                  Column(
                                                    // crossAxisAlignment: CrossAxisAlignment.start,
                                                    // mainAxisAlignment: MainAxisAlignment.center,
                                                    children: [
                                                      Column(
                                                        crossAxisAlignment:
                                                        CrossAxisAlignment.center,
                                                        children: <Widget>[
                                                          // Divider(),
                                                          SizedBox(
                                                            height: 20,
                                                          ),
                                                          Align(
                                                            alignment:
                                                            Alignment.topCenter,
                                                            child: Container(
                                                              // margin: EdgeInsets.only(
                                                              //     right: 20.0,
                                                              //     top: 10.0),
                                                              child: Text(
                                                                S.of(context).phoneNumber,
                                                                style: TextStyle(
                                                                  fontSize: 15,
                                                                  fontWeight:
                                                                  FontWeight.bold,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            height: 10,
                                                          ),
                                                          Padding(
                                                            padding: EdgeInsets.symmetric(horizontal: 30),
                                                            child: Container(
                                                              width: double.infinity,
                                                              height: 50,
                                                              child: EntryField(
                                                                hint:
                                                                S.of(context).phoneNumber,
                                                                textAlign:
                                                                TextAlign.start,
                                                                prefixIcon:
                                                                Icons.phone_iphone,
                                                                controller: _controller,
                                                                textInputType:
                                                                TextInputType
                                                                    .number,
                                                              ),
                                                            ),
                                                          )
                                                        ],
                                                      ),
                                                      SizedBox(
                                                        height: 20,
                                                      ),
                                                      Padding(
                                                        padding: EdgeInsets.symmetric(horizontal: 30),

                                                        child: StaggerAnimation(
                                                          titleButton:
                                                          S.of(context).signIn,
                                                          buttonController:
                                                          _loginButtonController
                                                              .view,
                                                          onTap: () {
                                                            _loginSMS(context);
                                                            // if (!isLoading) {
                                                            //   _loginSMS(context);
                                                            // }
                                                          },
                                                        ),
                                                      ),
                                                      SizedBox(
                                                        height: 30,
                                                      ),

                                                      Padding(
                                                        padding:
                                                        const EdgeInsets.symmetric(
                                                            horizontal: 28.0),
                                                        child: Row(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment.start,
                                                          mainAxisAlignment:
                                                          MainAxisAlignment.spaceBetween,
                                                          children: [
                                                            Card(
                                                              shape: RoundedRectangleBorder(
                                                                borderRadius: BorderRadius.circular(10),
                                                              ),
                                                              elevation: 5,
                                                              child: InkWell(
                                                                onTap: () =>
                                                                    _loginApple(context),
                                                                child: Container(
                                                                  width: 40.0.w,
                                                                  height: 50,
                                                                  child: Row(
                                                                    mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceEvenly,
                                                                    crossAxisAlignment: CrossAxisAlignment.center,

                                                                    children: [
                                                                      const Icon(
                                                                        FontAwesomeIcons
                                                                            .apple,
                                                                        color:
                                                                        Colors.black,
                                                                        size: 28.0,
                                                                      ),
                                                                      Container(
                                                                        margin: EdgeInsets
                                                                            .only(top: 7),
                                                                        child: Text(
                                                                          S.of(context).appleAcc,
                                                                          style: TextStyle(
                                                                              color: Colors
                                                                                  .black,
                                                                              fontWeight: FontWeight.w600,

                                                                              fontSize:
                                                                              15),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                  padding:
                                                                  const EdgeInsets
                                                                      .all(8),
                                                                  decoration:
                                                                  BoxDecoration(
                                                                    borderRadius:
                                                                    BorderRadius
                                                                        .circular(10),
                                                                    color: Colors.white,
                                                                    // border: Border.all(
                                                                    //     color:
                                                                    //         Theme.of(context).primaryColor)
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Card(
                                                              shape: RoundedRectangleBorder(
                                                                borderRadius: BorderRadius.circular(10),
                                                              ),
                                                              elevation: 5,
                                                              child: InkWell(
                                                                onTap: () =>
                                                                    _loginGoogle(context),
                                                                child: Container(
                                                                  width: 40.0.w,
                                                                  height: 50,

                                                                  child: Row(
                                                                    mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceEvenly,
                                                                    children: [
                                                                      Icon(
                                                                        FontAwesomeIcons
                                                                            .google,
                                                                        color: Colors.red,
                                                                        size: 24.0,
                                                                      ),
                                                                      Container(
                                                                        margin: EdgeInsets
                                                                            .only(top: 7),
                                                                        child: Text(
                                                                          S.of(context).googleAcc,
                                                                          style: TextStyle(
                                                                              color: Colors
                                                                                  .red,
                                                                              fontWeight: FontWeight.w600,
                                                                              fontSize:
                                                                              15),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                  padding:
                                                                  const EdgeInsets
                                                                      .all(12),
                                                                  decoration:
                                                                  BoxDecoration(
                                                                    borderRadius:
                                                                    BorderRadius
                                                                        .circular(10),
                                                                    color: Colors.white,
                                                                      // border: Border.all(
                                                                      //     color:
                                                                      //     Theme.of(context).primaryColor)
                                                                  ),
                                                                ),
                                                              ),
                                                            ),

                                                          ],
                                                        ),
                                                      ),
                                                      SizedBox(
                                                        height: 25,
                                                      ),
                                                      SizedBox(
                                                        height: 5,
                                                      ),
                                                      Center(
                                                        child: Column(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment.start,
                                                          children: [
                                                            // Container(
                                                            //   // margin: EdgeInsets.only(
                                                            //   //     right: 30.0),
                                                            //   child: Text(
                                                            //     'سوف تستلم الكـــــــود الذي سوف تقوم بادخاله',
                                                            //     style: TextStyle(
                                                            //       fontSize: 15,
                                                            //       color: Colors.grey,
                                                            //     ),
                                                            //   ),
                                                            // ),
                                                            // Container(
                                                            //   margin: EdgeInsets.only(
                                                            //       right: 27.0),
                                                            //   child: Text(
                                                            //     ' في رسالة نصية على رقم هاتفك',
                                                            //     style: TextStyle(
                                                            //       fontSize: 15,
                                                            //       color: Colors.grey,
                                                            //     ),
                                                            //   ),
                                                            // ),
                                                          ],
                                                        ),
                                                      ),
                                                      SizedBox(
                                                        height: 3.5.h,
                                                      ),
                                                      SizedBox(
                                                        height: 15.0,
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            );
                                        }),
                                  )),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 50),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,

                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Container(

                                      height: 70,
                                      width: screenSize.width*.4,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.only(topRight: Radius.circular(10), topLeft: Radius.circular(30), bottomLeft: Radius.circular(10), bottomRight: Radius.circular(30)),
                                      ),
                                      child: Image.asset(
                                        "assets/fashion/fashion logo app.png",
                                        height: 14.0.w,
                                        width: 25.0.w,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          Container(
                            height: 150,
                            width: double.infinity,
                            color: Colors.transparent,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Card(
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  elevation: 5,
                                  child: InkWell(
                                    onTap: (){
                                      Navigator.pop(context);
                                    },
                                    child: Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        // border: Border.all(color: Theme.of(context).primaryColor, width: 1),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Center(child: Icon(
                                        Icons.arrow_back_ios,
                                        color: Theme.of(context).primaryColor,size: 20,)),
                                    ),
                                  ),
                                ),
                                Text(
                                  ' ',
                                  style: const TextStyle(
                                    fontSize: 18,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Card(
                                  color: Colors.transparent,
                                  elevation: 0.0,
                                  child: Container(
                                    height: 50,
                                    width: 50,
                                    decoration: BoxDecoration(
                                      color: Colors.transparent,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),


                        ],
                      ),
                    ),
                  ),
                );
              }),
        ),
      ),
      // floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
      // floatingActionButton: FloatingActionButton(
      //   onPressed: _modalBottomSheetMenu,
      //   child: Container(
      //     decoration: BoxDecoration(
      //       shape: BoxShape.circle,
      //       color: Colors.red,
      //     ),
      //     width: 90,
      //     height: 90,
      //     child: Icon(
      //       Icons.arrow_upward_outlined,
      //       color: Colors.white,
      //     ),
      //   ),
      // ),
    );
  }

  // void _modalBottomSheetMenu() {
  //   showModalBottomSheet(
  //       context: context,
  //       shape: RoundedRectangleBorder(
  //           borderRadius: BorderRadius.only(
  //         topLeft: Radius.circular(25),
  //         topRight: Radius.circular(25),
  //       )),
  //       builder: (builder) {
  //         return
  //       });
  // }

  void showLoading() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Center(
            child: Container(
              padding: const EdgeInsets.all(50.0),
              child: kLoadingWidget(context),
            ));
      },
    );
  }

  void hideLoading() {
    Navigator.of(context).pop();
  }
}

class PrimaryColorOverride extends StatelessWidget {
  const PrimaryColorOverride({Key key, this.color, this.child})
      : super(key: key);

  final Color color;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Theme(
      child: child,
      data: Theme.of(context).copyWith(primaryColor: color),
    );
  }
}

class CustomClipPath extends CustomClipper<Path> {
  var radius = 10.0;
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(0, size.height - 100);
    path.quadraticBezierTo(
        size.width / 2.2, size.height, size.width, size.height);
    path.lineTo(size.width, 0);
    path.close();

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
// // Row(
// //   mainAxisAlignment:
// //       MainAxisAlignment.spaceAround,
// //   children: <Widget>[
// //     // if (kLoginSetting['showAppleLogin'] &&
// //     //     isAvailableApple)
// //     //   InkWell(
// //     //     onTap: () => _loginApple(context),
// //     //     child: Container(
// //     //       width: 320,
// //     //       height: 50,
// //     //       child: const Icon(
// //     //         FontAwesomeIcons.apple,
// //     //         color: Colors.white,
// //     //         size: 24.0,
// //     //       ),
// //     //       padding: const EdgeInsets.all(12),
// //     //       decoration: BoxDecoration(
// //     //         borderRadius:
// //     //             BorderRadius.circular(40),
// //     //         color: Colors.black87,
// //     //       ),
// //     //     ),
// //     //   ),
// //     // if (kLoginSetting['showFacebook'])
// //
// //     // if (kLoginSetting['showGoogleLogin'])
// //     InkWell(
// //       onTap: () => _loginGoogle(context),
// //       child: Container(
// //         width: 320,
// //         height: 50,
// //         child: const Icon(
// //           FontAwesomeIcons.google,
// //           color: Colors.white,
// //           size: 24.0,
// //         ),
// //         padding: const EdgeInsets.all(12),
// //         decoration: BoxDecoration(
// //           borderRadius: BorderRadius.circular(40),
// //           color: const Color(0xFFEA4336),
// //         ),
// //       ),
// //     ),
// //     // if (kLoginSetting['showSMSLogin'])
// //   ],
// // ),
// // const SizedBox(
// //   height: 10.0,
// // ),
// InkWell(
//   onTap: () => _loginFacebook(context),
//   child: Container(
//     child: const Icon(
//       FontAwesomeIcons.facebookF,
//       color: Colors.white,
//       size: 24.0,
//     ),
//     padding: const EdgeInsets.all(12),
//     decoration: BoxDecoration(
//       borderRadius: BorderRadius.circular(40),
//       color: const Color(0xFF4267B2),
//     ),
//   ),
// ),
// const SizedBox(
//   height: 10.0,
// ),

////////////////////////////////////////////

/*   Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 18.0),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                InkWell(
                                                  onTap: () =>
                                                      _loginApple(context),
                                                  child: Container(
                                                    width: 90.0.w,
                                                    height: 60,
                                                    child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceEvenly,
                                                      children: [
                                                        const Icon(
                                                          FontAwesomeIcons
                                                              .apple,
                                                          color: Colors.black,
                                                          size: 28.0,
                                                        ),
                                                        Container(
                                                          margin:
                                                              EdgeInsets.only(
                                                                  top: 7),
                                                          child: Text(
                                                            'تسجيل الدخول باستخدام Apple  ',
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .black,
                                                                fontSize: 15),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    padding:
                                                        const EdgeInsets.all(8),
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              15),
                                                      color: Colors.white,
                                                      // border: Border.all(
                                                      //     color:
                                                      //         Colors.black)
                                                    ),
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 20.0,
                                                ),
                                                InkWell(
                                                  onTap: () =>
                                                      _loginGoogle(context),
                                                  child: Container(
                                                    width: 90.0.w,
                                                    height: 60,
                                                    alignment: Alignment.center,
                                                    child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceEvenly,
                                                      children: [
                                                        Icon(
                                                          FontAwesomeIcons
                                                              .google,
                                                          color: Colors.red,
                                                          size: 24.0,
                                                        ),
                                                        Container(
                                                          margin:
                                                              EdgeInsets.only(
                                                                  top: 7),
                                                          child: Text(
                                                            'تسجيل الدخول باستخدام Google  ',
                                                            style: TextStyle(
                                                                color:
                                                                    Colors.red,
                                                                fontSize: 15),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    padding:
                                                        const EdgeInsets.all(
                                                            12),
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              15),
                                                      color: Colors.white,
                                                    ),
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 20.0,
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 18),
                                            child: Row(children: <Widget>[
                                              Expanded(
                                                  child: const Divider(
                                                color: Colors.grey,
                                              )),
                                              Text(
                                                "      او      ",
                                                style: TextStyle(
                                                    color: Colors.grey,
                                                    fontSize: 18,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                              Expanded(
                                                  child: const Divider(
                                                color: Colors.grey,
                                              )),
                                            ]),
                                          ),
                                          SizedBox(
                                            height: 25,
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 18),
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: <Widget>[
                                                // Divider(),
                                                Container(
                                                  width: 90.0.w,
                                                  height: 60,
                                                  child: EntryField(
                                                    hint: "      رقم الهاتف ",
                                                    textAlign: TextAlign.start,
                                                    // prefixIcon:
                                                    //     Icons.phone_iphone,
                                                    // color: ,
                                                    controller: _controller,
                                                    textInputType:
                                                        TextInputType.number,
                                                  ),
                                                )
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Center(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                // Container(
                                                //   // margin: EdgeInsets.only(
                                                //   //     right: 30.0),
                                                //   child: Text(
                                                //     'سوف تستلم الكـــــــود الذي سوف تقوم بادخاله',
                                                //     style: TextStyle(
                                                //       fontSize: 15,
                                                //       color: Colors.grey,
                                                //     ),
                                                //   ),
                                                // ),
                                                // Container(
                                                //   margin: EdgeInsets.only(
                                                //       right: 27.0),
                                                //   child: Text(
                                                //     ' في رسالة نصية على رقم هاتفك',
                                                //     style: TextStyle(
                                                //       fontSize: 15,
                                                //       color: Colors.grey,
                                                //     ),
                                                //   ),
                                                // ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 3.5.h,
                                          ),

                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 18),
                                            child: StaggerAnimation(
                                              titleButton: S.of(context).signIn,
                                              buttonController:
                                                  _loginButtonController.view,
                                              onTap: () {
                                                _loginSMS(context);
                                                // if (!isLoading) {
                                                //   _loginSMS(context);
                                                // }
                                              },
                                            ),
                                          ),
                                          SizedBox(
                                            height: 15.0,
                                          ),*/

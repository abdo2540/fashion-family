import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:provider/provider.dart';

import '../../common/tools.dart';
import '../../generated/l10n.dart';
import '../../models/user_model.dart';
import '../../screens/base.dart';
import '../../services/index.dart';
import 'package:flutter_svg/svg.dart';

class UserUpdate extends StatefulWidget {
  @override
  _StateUserUpdate createState() => _StateUserUpdate();
}

class _StateUserUpdate extends BaseScreen<UserUpdate> {
  TextEditingController userEmail;
  TextEditingController userPassword;
  TextEditingController userDisplayName;
  TextEditingController userNiceName;
  TextEditingController userUrl;
  TextEditingController userPhone;
  TextEditingController currentPassword;

  String avatar;
  bool isLoading = false;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void afterFirstLayout(BuildContext context) {
    final user = Provider.of<UserModel>(context, listen: false).user;
    final alphanumeric = RegExp(r'^[a-zA-Z0-9]+$');
    setState(() {
      userEmail = TextEditingController(text: user.email);
      userPassword = TextEditingController(text: "");
      currentPassword = TextEditingController(text: "");
      userDisplayName = TextEditingController(text: user.name);
      userNiceName = TextEditingController(text: user.nicename);
      userUrl = TextEditingController(text: user.userUrl);
      if (user.firstName != null && alphanumeric.hasMatch(user.firstName)) {
        userPhone = TextEditingController(text: user.firstName);
      }
      avatar = user.picture;
    });
  }

  void updateUserInfo() {
    final user = Provider.of<UserModel>(context, listen: false).user;
    setState(() {
      isLoading = true;
    });
    Services().widget.updateUserInfo(
        loggedInUser: user,
        onError: (e) {
          // ignore: deprecated_member_use
          _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text(e)));
          setState(() {
            isLoading = false;
          });
        },
        onSuccess: (param) {
          Provider.of<UserModel>(context, listen: false).updateUser(param);
          setState(() {
            isLoading = false;
          });
          Navigator.pop(context);
        },
        currentPassword: currentPassword.text,
        userDisplayName: userDisplayName.text,
        userEmail: userEmail.text,
        userNiceName: userNiceName.text,
        userUrl: userUrl.text,
        userPassword: userPassword.text);
  }

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserModel>(context).user;
    final screenSize = MediaQuery.of(context).size;
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.grey.shade200,
      // appBar: AppBar(
      //   backgroundColor: Color(0xff4f3933),
      //   centerTitle: true,
      //   title: Text(
      //     S.of(context).settings,
      //     style: const TextStyle(
      //       fontSize: 18,
      //       color: Colors.white,
      //       fontWeight: FontWeight.bold,
      //     ),
      //   ),
      //   leading: GestureDetector(
      //     onTap: () => Navigator.pop(context),
      //     child: Container(
      //       padding: const EdgeInsets.all(10),
      //       margin: const EdgeInsets.only(left: 10),
      //       child: const Icon(
      //         Icons.arrow_back_ios,
      //         color: Colors.white,
      //       ),
      //     ),
      //   ),
      // ),
      body: GestureDetector(
        onTap: () {
          Utils.hideKeyboard(context);
        },
        child: SafeArea(
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(12.0),
                child: Align(
                  alignment: Alignment.topCenter,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        elevation: 5,
                        child: InkWell(
                          onTap: (){
                            Navigator.pop(context);
                          },
                          child: Container(
                            height: 50,
                            width: 50,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              // border: Border.all(color: Theme.of(context).primaryColor, width: 1),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Center(child: Icon(
                              Icons.arrow_back_ios,
                              color: Theme.of(context).primaryColor,size: 20,)),
                          ),
                        ),
                      ),
                      Text(
                        S.of(context).generalSetting,
                        style: const TextStyle(
                          fontSize: 18,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Card(
                        color: Colors.transparent,
                        elevation: 0.0,
                        child: Container(
                          height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                            color: Colors.transparent,
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(topLeft: Radius.circular(15), topRight: Radius.circular(15))
                  ),
                  child: SingleChildScrollView(
                    physics: BouncingScrollPhysics(),
                    child: Container(
                      child: Column(
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 20, horizontal: 15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                const SizedBox(
                                  height: 10,
                                ),
                                Text(S.of(context).email,
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: Theme.of(context).accentColor,
                                    )),
                                Container(
                                  child: TextField(
                                    decoration: const InputDecoration(
                                      border: InputBorder.none,
                                    ),
                                    controller: userEmail,
                                    enabled: !user.isSocial,
                                  ),
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Text(S.of(context).displayName,
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: Theme.of(context).accentColor,
                                    )),
                                const SizedBox(
                                  height: 5,
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      color:
                                          Theme.of(context).primaryColorLight,
                                      border: Border.all(
                                          color: Theme.of(context)
                                              .primaryColorLight,
                                          width: 1.5)),
                                  child: TextField(
                                    decoration: const InputDecoration(
                                        border: InputBorder.none),
                                    controller: userDisplayName,
                                  ),
                                ),
                                const SizedBox(
                                  height: 20,
                                ),
                                Text(S.of(context).niceName,
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: Theme.of(context).accentColor,
                                    )),
                                const SizedBox(
                                  height: 5,
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                    color: Theme.of(context).primaryColorLight,
                                    border: Border.all(
                                      color:
                                          Theme.of(context).primaryColorLight,
                                      width: 1.5,
                                    ),
                                  ),
                                  child: TextField(
                                    decoration: const InputDecoration(
                                        border: InputBorder.none),
                                    controller: userNiceName,
                                  ),
                                ),
                                const SizedBox(height: 20),
                                Text(S.of(context).url,
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: Theme.of(context).accentColor,
                                    )),
                                const SizedBox(height: 5),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10),
                                  decoration: BoxDecoration(
                                      color:
                                          Theme.of(context).primaryColorLight,
                                      borderRadius: BorderRadius.circular(5),
                                      border: Border.all(
                                          color: Theme.of(context)
                                              .primaryColorLight,
                                          width: 1.5)),
                                  child: TextField(
                                    decoration: const InputDecoration(
                                        border: InputBorder.none),
                                    controller: userUrl,
                                  ),
                                ),
                                const SizedBox(height: 15),
                                Services()
                                    .widget
                                    .renderCurrentPassInputforEditProfile(
                                        context: context,
                                        currentPasswordController:
                                            currentPassword),
                                if (!user.isSocial)
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Text(S.of(context).newPassword,
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600,
                                            color:
                                                Theme.of(context).accentColor,
                                          )),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            border: Border.all(
                                                color: Theme.of(context)
                                                    .primaryColorLight,
                                                width: 1.5)),
                                        child: TextField(
                                          obscureText: true,
                                          decoration: const InputDecoration(
                                              border: InputBorder.none),
                                          controller: userPassword,
                                        ),
                                      ),
                                    ],
                                  ),
                                const SizedBox(
                                  height: 30,
                                ),
                                Center(
                                  child: GestureDetector(
                                    onTap: updateUserInfo,
                                    child: Container(
                                      height: 55,
                                      width: double.infinity,
                                      decoration: BoxDecoration(
                                        color: Theme.of(context).primaryColor,
                                        borderRadius:
                                            BorderRadius.circular(15.0),
                                      ),
                                      child: isLoading
                                          ? const SpinKitCircle(
                                              color: Colors.white,
                                              size: 20.0,
                                            )
                                          : Center(
                                              child: Text(
                                                S.of(context).update,
                                                style: const TextStyle(
                                                    fontSize: 18,
                                                    fontWeight:
                                                        FontWeight.w600,
                                                    color: Colors.white),
                                              ),
                                            ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_spinkit/src/circle.dart';
import 'package:sizer/sizer.dart';
class ProcessingDialog extends StatelessWidget {
  final String message;
  ProcessingDialog({@required this.message});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return AlertDialog(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(
          Radius.circular(15.0),
        ),
      ),
      elevation: 5.0,
      contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
      content: Container(
        width: 100,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[

            Text(
              message,
              style: GoogleFonts.tajawal(
                fontSize: 14.0,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.3,

              ),
            ),
            const SizedBox(
              height: 15.0,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Container(
                  height: 1.0.h,
                  width: 30.0.w,

                  child: LinearProgressIndicator(
                    minHeight: 1,

                    semanticsLabel: 'wait',
                    valueColor: AlwaysStoppedAnimation<Color>(Color(0xff4f3933)),
                    backgroundColor: Colors.grey,
                  )
                ),


              ],
            ),

          ],
        ),
      ),
    );
  }
}

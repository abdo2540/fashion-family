import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:transparent_image/transparent_image.dart';

import '../../common/constants.dart';
import '../../generated/l10n.dart';
import '../../models/index.dart' show Category, ProductModel;
import '../../screens/base.dart';
import '../../widgets/common/skeleton.dart';
import '../../widgets/common/tree_view.dart';

class CardCategories extends StatefulWidget {
  static const String type = 'card';

  final List<Category> categories;

  CardCategories(this.categories);

  @override
  _StateCardCategories createState() => _StateCardCategories();
}

class _StateCardCategories extends BaseScreen<CardCategories> {
  ScrollController controller = ScrollController();
  double page;

  @override
  void initState() {
    page = 0.0;
    super.initState();
  }

  @override
  void afterFirstLayout(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    controller.addListener(() {
      setState(() {
        page = _getPage(controller.position, screenSize.width * 0.30 + 10);
      });
    });
  }

  bool hasChildren(id) {
    return widget.categories.where((o) => o.parent == id).toList().isNotEmpty;
  }

  double _getPage(ScrollPosition position, double width) {
    return position.pixels / width;
  }

  List<Category> getSubCategories(id) {
    return widget.categories.where((o) => o.parent == id).toList();
  }

  Widget getChildCategoryList(category) {
    return ChildList(
      children: [
        SubItem(
          category,
          seeAll: S.of(context).seeAll,
        ),
        for (var category in getSubCategories(category.id))
          Parent(
            parent: SubItem(category),
            childList: ChildList(
              children: [
                for (var cate in getSubCategories(category.id))
                  Parent(
                    parent: SubItem(cate, level: 1),
                    childList: ChildList(
                      children: [
                        for (var _cate in getSubCategories(cate.id))
                          Parent(
                            parent: SubItem(_cate, level: 2),
                            childList: ChildList(children: []),
                          ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final _categories =
        widget.categories.where((item) => item.parent == '0').toList();

    return SingleChildScrollView(
      controller: controller,
      scrollDirection: Axis.vertical,
      child: Column(
        children: [
          TreeView(
            parentList: List.generate(
              _categories.length,
              (index) {
                return Parent(
                  parent: CategoryCardItem(
                    _categories[index],
                    hasChildren: hasChildren(_categories[index].id),
                    offset: page - index,
                  ),
                  childList: getChildCategoryList(_categories[index]),
                );
              },
            ),
          ),
          const SizedBox(height: 100)
        ],
      ),
    );
  }
}

class CategoryCardItem extends StatelessWidget {
  final Category category;
  final bool hasChildren;
  final offset;

  CategoryCardItem(this.category, {this.hasChildren = false, this.offset});

  /// Render category Image support caching on ios/android
  /// also fix loading on Web
  Widget renderCategoryImage(maxWidth) {
    if (category.image.contains('http') && kIsWeb) {
      return FadeInImage.memoryNetwork(
        image: '$kImageProxy${category.image}',
        fit: BoxFit.cover,
        width: maxWidth,
        height: maxWidth * 0.35,
        placeholder: kTransparentImage,
      );
    }

    return category.image.contains('http')
        ? CachedNetworkImage(
            imageUrl: category.image,
            fit: BoxFit.cover,
            alignment: Alignment(
              0.0,
              (offset >= -1 && offset <= 1)
                  ? offset
                  : (offset > 0)
                      ? 1.0
                      : -1.0,
            ),
            // fadeInCurve: Curves.easeIn,
            imageBuilder:
                (BuildContext context, ImageProvider<dynamic> imageProvider) {
              return Image(
                width: maxWidth,
                image: imageProvider,
                fit: BoxFit.cover,
              );
            },
            placeholder: (context, url) => Skeleton(
              width: maxWidth,
              height: maxWidth * 0.35,
            ),
          )
        : Image.asset(
            category.image,
            fit: BoxFit.cover,
            width: maxWidth,
            height: maxWidth * 0.35,
            alignment: Alignment(
              0.0,
              (offset >= -1 && offset <= 1)
                  ? offset
                  : (offset > 0)
                      ? 1.0
                      : -1.0,
            ),
          );
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: hasChildren
          ? null
          : () {
              // print(category.id);
              ProductModel.showList(
                context: context,
                cateId: category.id,
                cateName: category.name,
              );
            },
      child: LayoutBuilder(
        builder: (context, constraints) {
          return Container(
            height: constraints.maxWidth * 0.35,
            padding: const EdgeInsets.only(left: 10, right: 10),
            margin: const EdgeInsets.only(bottom: 10),
            // decoration: BoxDecoration(
            //   borderRadius: BorderRadius.circular(30),
            // ),

            child: Stack(
              children: <Widget>[
                ClipRRect(
                    borderRadius: const BorderRadius.all(Radius.circular(34.0)),
                    child: renderCategoryImage(constraints.maxWidth)),
                Container(
                  width: constraints.maxWidth,
                  height: constraints.maxWidth * 0.35,
                  decoration: BoxDecoration(
                    color: const Color.fromRGBO(0, 0, 0, 0.3),
                    borderRadius: BorderRadius.circular(34.0),
                  ),
                  child: Container(
                    width: constraints.maxWidth /
                        (2 / (screenSize.height / constraints.maxWidth)),
                    height: constraints.maxWidth * 0.35,
                    child: Center(
                      child: Text(
                        category.name.toUpperCase(),
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class SubItem extends StatelessWidget {
  final Category category;
  final String seeAll;
  final int level;

  SubItem(this.category, {this.seeAll = '', this.level = 0});

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    print(category.id);
    return Padding(
      padding: const EdgeInsets.only(left: 15, right: 15, top: 0, bottom: 5),
      child: InkWell(
        onTap: () {
          print(category.id);
          ProductModel.showList(
              context: context, cateId: category.id, cateName: category.name);
        },
        child: Card(
          elevation: .9,
          color: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15.0),
            side: BorderSide(
              color: Colors.grey.withOpacity(.5),
              width: 1.0,
            ),
          ),
          child: Container(
            width:
                screenSize.width,
            // decoration: BoxDecoration(
            //   border: Border(
            //       // top: BorderSide(
            //       //   width: 0.5,
            //       //   color: Theme.of(context)
            //       //       .accentColor
            //       //       .withOpacity(level == 0 && seeAll == '' ? 0.2 : 0),
            //       // ),
            //       ),
            // ),
            padding: const EdgeInsets.symmetric(vertical: 5,horizontal: 0),
            // margin: const EdgeInsets.symmetric(horizontal: 5),
            child: Row(
              mainAxisAlignment:MainAxisAlignment.spaceBetween ,
              crossAxisAlignment:CrossAxisAlignment.center ,
              children: <Widget>[
                const SizedBox(width: 15.0),
                for (int i = 1; i <= level; i++)
                  Container(
                    width: 0.0,
                    // margin: const EdgeInsets.only(top: 8.0, right: 0),
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.black,
                        //  BorderSide(
                        //   width: 1.5,
                        //   // color: Theme.of(context).primaryColor.withOpacity(0.5),
                        // ),
                      ),
                    ),
                  ),
                seeAll != ''
                    ? Container(
                        height: 70,
                        // width: 70,
                      )
                    : Container(
                        height: 70,
                        width: 70,
                        // margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal:5),
                        child: ClipRRect(
                            borderRadius:
                                const BorderRadius.all(Radius.circular(15.0)),
                            child: Image.network(category.image))),
                SizedBox(
                  width: 7,
                ),
                Expanded(
                  child: Text(
                    seeAll != '' ? seeAll : category.name,
                    style: TextStyle(
                      fontSize: 17,
                      color: Theme.of(context).primaryColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Text(
                  "تسوق",
                  style: TextStyle(
                      fontSize: 15, color: Theme.of(context).primaryColor,fontWeight: FontWeight.bold),
                ),
                const SizedBox(width: 15.0),
                // IconButton(
                //   icon: const Icon(Icons.keyboard_arrow_right),
                //   onPressed: () {
                //     print(category.id);
                //     ProductModel.showList(
                //         context: context,
                //         cateId: category.id,
                //         cateName: category.name);
                //   },
                // )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

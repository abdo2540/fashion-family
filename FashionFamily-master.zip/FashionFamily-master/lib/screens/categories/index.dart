import 'dart:io';

import 'package:flutter/animation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:provider/provider.dart';
import 'package:fashion/caco/categories/components/category_list_item.dart';
import 'package:fashion/caco/components/search_text_field.dart';
import 'package:fashion/caco/constants.dart';
import 'package:fashion/caco/size_config.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../common/constants.dart';
import '../../generated/l10n.dart';
import '../../models/index.dart'
    show AppModel, Category, CategoryModel, ProductModel;
import '../../share.dart';
import '../../tabbar.dart';
import '../../widgets/cardlist/index.dart';
import '../custom/smartchat.dart';
import 'card.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shimmer/shimmer.dart';
import 'column.dart';
import 'grid_category.dart';
import 'side_menu.dart';
import 'side_menu_with_sub.dart';
import 'sub.dart';
import 'package:fashion/caco/shimmer_product_list_item.dart';
import 'package:flutter_svg/svg.dart';

class CategoriesScreen extends StatefulWidget {
  final String layout;
  final List<dynamic> categories;
  final List<dynamic> images;
  final bool showChat;
  final bool showSearch;

  CategoriesScreen(
      {Key key,
      this.layout,
      this.categories,
      this.images,
      this.showChat,
      this.showSearch = true})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CategoriesScreenState();
  }
}

class CategoriesScreenState extends State<CategoriesScreen>
    with AutomaticKeepAliveClientMixin, SingleTickerProviderStateMixin {
  @override
  bool get wantKeepAlive => true;

  FocusNode _focus;
  bool isVisibleSearch = false;
  String searchText;
  var textController = TextEditingController();

  Animation<double> animation;
  AnimationController controller;

  @override
  void initState() {
    super.initState();
    controller = AnimationController(
        duration: const Duration(milliseconds: 300), vsync: this);
    animation = Tween<double>(begin: 0, end: 60).animate(controller);
    animation.addListener(() {
      setState(() {});
    });

    _focus = FocusNode();
    _focus.addListener(_onFocusChange);
  }

  void _onFocusChange() {
    if (_focus.hasFocus && animation.value == 0) {
      controller.forward();
      setState(() {
        isVisibleSearch = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    final category = Provider.of<CategoryModel>(context);
    final screenSize = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      body: Stack(
        children: [
          // Positioned(
          //   top: -80,
          //   child: Container(
          //     width: screenSize.width,
          //     child: SvgPicture.asset(
          //       "assets/fashion/bg.svg",
          //       width: screenSize.width,
          //       // height: screenSize.height / 2,
          //       fit: BoxFit.fitWidth,
          //     ),
          //   ),
          // ),
          SafeArea(
            bottom: false,
            child: Column(
              children: [
                renderHeader(),
                // SizedBox(height: getProportionateScreenHeight(20)),
                Expanded(
                  child: Container(
                    padding: EdgeInsets.only(top: 10),

                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(topLeft: Radius.circular(30), topRight: Radius.circular(30))
                    ),
                    child: ListenableProvider.value(
                      value: category,
                      child: Consumer<CategoryModel>(
                        builder: (context, value, child) {
                          if (value.isLoading) {
                            return Container(
                              width: double.infinity,
                              height: getProportionateScreenHeight(200),
                              child: ListView.separated(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16.0, vertical: 10),
                                shrinkWrap: true,
                                scrollDirection: Axis.vertical,
                                itemCount: 5,
                                itemBuilder: (context, index) {
                                  return Container(
                                    height: 150,
                                    margin: EdgeInsets.symmetric(
                                        horizontal: 16.0, vertical: 10),
                                    child: Shimmer.fromColors(
                                      period: Duration(milliseconds: 800),
                                      baseColor: Colors.grey.withOpacity(0.5),
                                      highlightColor:
                                          Colors.black.withOpacity(0.5),
                                      child: Container(
                                        width: 150.0,
                                        child: ShimmerProductListItem(),
                                      ),
                                    ),
                                  );
                                },
                                separatorBuilder: (context, index) {
                                  return SizedBox(
                                    width: 20.0,
                                  );
                                },
                              ),
                            );
                          }

                          if (value.categories == null) {
                            return Container(
                              width: double.infinity,
                              height: double.infinity,
                              alignment: Alignment.center,
                              child: Text(S.of(context).dataEmpty),
                            );
                          }


                          List<Category> categories = value.categories;
                          List<Category> showCategories = [];
                          bool hasChildren(id) {
                            return categories.where((o) => o.parent == id).toList().isNotEmpty;
                          }

                          // categories = value.categories;
                          categories = value.categories
                              .where((item) => item.id != '115' && item.id != "116")
                              .toList();
                          if (showCategories.isEmpty) {
                            for (int i = 0; i < categories.length; i++) {
                              if (hasChildren(categories[i].id) == true) {
                                showCategories.add(categories[i]);
                              }
                            }
                          }

                          return Padding(
                            padding: EdgeInsets.symmetric(
                              horizontal: getProportionateScreenWidth(11),
                            ),
                            child: GridView.builder(
                                physics: BouncingScrollPhysics(),
                                gridDelegate:
                                    SliverGridDelegateWithFixedCrossAxisCount(
                                        crossAxisCount: 1,
                                        childAspectRatio: 1.8 / 1,
                                        crossAxisSpacing: 0),
                                // SliverGridDelegateWithFixedCrossAxisCount(
                                //     crossAxisCount: 2,
                                //     childAspectRatio: 3 / 2,
                                //     crossAxisSpacing: 3),
                                shrinkWrap: true,
                                itemCount: categories.length,
                                itemBuilder: (context, index) {
                                  return InkWell(
                                    onTap: () {
                                      ProductModel.showList(
                                        context: context,
                                        cateId: categories[index].id,
                                        cateName: categories[index].name,
                                      );
                                    },
                                    child: CategoryListItem(
                                      category: categories[index],
                                    ),
                                  );
                                }),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: Padding(
        padding: Platform.isIOS ?  EdgeInsets.only(bottom:90) : EdgeInsets.only(bottom:60),
        child: SpeedDial(
          foregroundColor: Theme.of(context).primaryColor,
          backgroundColor: Colors.white,
          icon: Icons.phone_rounded,
          activeIcon: Icons.dangerous,
          children: [
            SpeedDialChild(
                backgroundColor: Colors.transparent,
                child: SvgPicture.asset('assets/icons/phonee.svg'),
                label: 'اتصل بنا',
                onTap: (){ShareFunction().launchCaller();}),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/whatsapp.svg'),
                label: 'واتساب',
                onTap: (){ShareFunction().launchWhatApp();}),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/messenger.svg'),
                label: 'ماسنجر',
                onTap: (){ShareFunction().launchMessanger();}),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/ig.svg'),
                label: 'انستجرام',
                onTap: () {
                  ShareFunction().launchInstagram();
                }
            ),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/tiktok.svg'),
                label: 'تيك توك',
                onTap: () {
                  ShareFunction().launchTiktok();
                }
            ),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/facebook.svg'),
                label: 'صفحة الفيس بوك',
                onTap: () {
                  ShareFunction().launchFacebook();
                }
            ),

          ],
        ),
      ),

    );
  }


  Widget renderHeader() {
    final screenSize = MediaQuery.of(context).size;
    return Container(
      width: screenSize.width,
      child: Container(
        width:
            screenSize.width / (2 / (screenSize.height / screenSize.width)),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                elevation: 5,
                child: InkWell(
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> MainTabs()));
                  },
                  child: Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      // border: Border.all(color: Theme.of(context).primaryColor, width: 1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                      Icons.arrow_back_ios,
                      color: Theme.of(context).primaryColor,size: 20,),
                  ),
                ),
              ),

              Text(S.of(context).categories,
                  style: GoogleFonts.tajawal(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black)),
              Card(
                color: Colors.transparent,
                elevation: 0.0,
                child: Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }


  Widget renderCategories(List<Category> categories) {
    switch (widget.layout) {
      case CardCategories.type:
        return CardCategories(categories);
      case ColumnCategories.type:
        return ColumnCategories(categories);
      case SubCategories.type:
        return SubCategories(categories);
      case SideMenuCategories.type:
        return SideMenuCategories(categories);
      case SideMenuSubCategories.type:
        return SideMenuSubCategories(categories);
      case HorizonMenu.type:
        return HorizonMenu(categories);
      case GridCategory.type:
        return GridCategory(
          categories,
          icons: widget.images,
        );
      default:
        return HorizonMenu(categories);
    }
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }
}

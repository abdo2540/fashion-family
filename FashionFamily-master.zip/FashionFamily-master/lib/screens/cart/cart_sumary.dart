import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../common/config.dart';
import '../../common/tools.dart';
import '../../generated/l10n.dart';
import '../../models/index.dart' show AppModel, CartModel, Coupons, Discount;
import '../../services/index.dart';
import 'point_reward.dart';
import 'package:flutter_styled_toast/flutter_styled_toast.dart';
class ShoppingCartSummary extends StatefulWidget {
  ShoppingCartSummary({this.model, this.onApplyCoupon});

  final CartModel model;
  final Function onApplyCoupon;

  @override
  _ShoppingCartSummaryState createState() => _ShoppingCartSummaryState();
}

class _ShoppingCartSummaryState extends State<ShoppingCartSummary> {
  final services = Services();
  Coupons coupons;
  bool _enable = true;
  bool _loading = false;
  Map<String, dynamic> defaultCurrency = kAdvanceConfig['DefaultCurrency'];

  @override
  void initState() {
    super.initState();
    if (widget.model.couponObj != null && widget.model.couponObj.amount > 0) {
      _enable = false;
    }
    getCoupon();
  }

  Future<void> getCoupon() async {
    try {
      coupons = await services.getCoupons();
    } catch (e) {
//      print(e.toString());
    }
  }

  void showError(String message) {
    setState(() => _loading = false);
    print(message);
    showToast('${message.replaceAll("Exception:", "")}',
        context: context,
        animation: StyledToastAnimation.slideFromLeftFade,
        reverseAnimation: StyledToastAnimation.fadeScale,
        position:
        StyledToastPosition(align: Alignment.topCenter, offset: 0.0),
        startOffset: Offset(0.0, -3.0),
        reverseEndOffset: Offset(0.0, -3.0),
        duration: Duration(seconds: 2),
        //Animation duration   animDuration * 2 <= duration
        animDuration: Duration(milliseconds: 700),
        backgroundColor: Color(0xff4f3933),
        curve: Curves.fastLinearToSlowEaseIn,
        reverseCurve: Curves.fastOutSlowIn);
  }

  /// Check coupon code
  void checkCoupon(String couponCode) {
    if (couponCode.isEmpty) {
      showError(S.of(context).pleaseFillCode);
      return;
    }

    setState(() => _loading = true);

    Services().widget.applyCoupon(context, coupons: coupons, code: couponCode,
        success: (Discount discount) async {
      await widget.model.updateDiscount(discount: discount);
      setState(() {
        _enable = false;
        _loading = false;
      });
      showError("تم التطبيق بنجاح");
    }, error: showError);
  }

  @override
  Widget build(BuildContext context) {
    OutlineInputBorder outlineInputBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(20),
      borderSide: BorderSide(color: Theme.of(context).primaryColor),
      gapPadding: 10,
    );
    final currency = Provider.of<AppModel>(context).currency;
    final currencyRate = Provider.of<AppModel>(context).currencyRate;
    final smallAmountStyle =
        GoogleFonts.tajawal(color: Color(0xff4f3933), fontSize: 13);
    final largeAmountStyle = GoogleFonts.tajawal(
        color: Color(0xff4f3933), fontSize: 13, fontWeight: FontWeight.bold);
    final formatter = NumberFormat.currency(
        symbol: defaultCurrency['symbol'],
        decimalDigits: defaultCurrency['decimalDigits']);
    final couponController = TextEditingController();

    String couponMsg = S.of(context).couponMsgSuccess;
    if (widget.model.couponObj != null) {
      if (widget.model.couponObj.discountType == "percent") {
        couponMsg += "${widget.model.couponObj.amount}%";
      } else {
        couponMsg += " - ${formatter.format(widget.model.couponObj.amount)}";
      }
    }
    final screenSize = MediaQuery.of(context).size;

    return Container(
      width: screenSize.width,
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),),
      child: Container(
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20)),
        width: screenSize.width / (2 / (screenSize.height / screenSize.width)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 7.0, vertical: 0.0),
              child: Container(
                decoration: BoxDecoration(
                    // color: Color(0xffffd900),
                    borderRadius: BorderRadius.circular(30)),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: 5.0, horizontal: 15.0),
                  child: Column(
                    children: [
                      Container(
                        height: 35,
                        child: Row(
                          children: [
                            Expanded(
                              child: TextFormField(
                                controller: couponController,
                                maxLines: 1,
                                textAlign: TextAlign.center,
                                textAlignVertical: TextAlignVertical.center,
                                enabled: _enable && !_loading,
                                decoration: InputDecoration(
                                  // prefixIcon:
                                  //     Icon(prefixIcon, color: Theme.of(context).primaryColor),
                                  // suffixIcon: Icon(suffixIcon),
                                  hintText: S.of(context).inserttCopoun,
                                  contentPadding: EdgeInsets.all(5),
                                  hintStyle: TextStyle(
                                      fontSize: 13,
                                      textBaseline: TextBaseline.alphabetic,
                                      color: Theme.of(context).primaryColor),
                                  filled: true,
                                  fillColor: Theme.of(context).primaryColor.withOpacity(.3),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide.none,
                                  ),
                                ),
                              ),
                            ),
                            GestureDetector(
                              onTap: !widget.model.calculatingDiscount
                                  ? () {
                                      if (_enable) {
                                        checkCoupon(couponController.text);
                                      } else {
                                        setState(() {
                                          _enable = true;
                                          widget.model.resetCoupon();
                                          widget.model.discountAmount = 0.0;
                                        });
                                      }
                                    }
                                  : null,
                              child: Container(
                                margin: EdgeInsetsDirectional.only(start: 8),
                                width: 90,
                                decoration: BoxDecoration(
                                  color: Theme.of(context).primaryColor,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      _loading ||
                                              widget.model.calculatingDiscount
                                          ? S.of(context).loading
                                          : _enable
                                              ? S.of(context).apply
                                              : S.of(context).remove,
                                      style: GoogleFonts.tajawal(fontSize: 13, color: Colors.white),
                                    )
                                  ],
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                      // Padding(
                      //   padding: const EdgeInsets.symmetric(
                      //       horizontal: 15.0, vertical: 0),
                      //   child: Row(
                      //     crossAxisAlignment: CrossAxisAlignment.center,
                      //     children: <Widget>[
                      //       Expanded(
                      //         child: Container(
                      //           margin: const EdgeInsets.only(
                      //               top: 20.0, bottom: 20.0),
                      //           decoration: _enable
                      //               ? BoxDecoration(
                      //                   borderRadius: BorderRadius.circular(0),
                      //                   color:
                      //                       Theme.of(context).backgroundColor)
                      //               : const BoxDecoration(
                      //                   color: Color(0xFFF1F2F3)),
                      //           child: TextField(
                      //             controller: couponController,
                      //             enabled: _enable && !_loading,
                      //             decoration: InputDecoration(
                      //                 labelStyle: GoogleFonts.tajawal(),
                      //                 labelText: _enable
                      //                     ? S.of(context).couponCode
                      //                     : widget.model.couponObj.code,

                      //                 //hintStyle: TextStyle(color: _enable ? Colors.grey : Colors.black),
                      //                 contentPadding:
                      //                     const EdgeInsets.symmetric(
                      //                         vertical: 15, horizontal: 15)),
                      //           ),
                      //         ),
                      //       ),
                      //       Container(
                      //         width: 10,
                      //       ),
                      //       RaisedButton.icon(
                      //         shape: RoundedRectangleBorder(
                      //             borderRadius: BorderRadius.circular(8)),
                      //         elevation: 0.0,
                      //         label: Text(
                      //           _loading || widget.model.calculatingDiscount
                      //               ? S.of(context).loading
                      //               : _enable
                      //                   ? S.of(context).apply
                      //                   : S.of(context).remove,
                      //           style: GoogleFonts.tajawal(),
                      //         ),
                      //         icon: const Icon(
                      //           FontAwesomeIcons.clipboardCheck,
                      //           size: 15,
                      //         ),
                      //         color: Theme.of(context).primaryColorLight,
                      //         textColor: Theme.of(context).primaryColor,
                      //         onPressed: !widget.model.calculatingDiscount
                      //             ? () {
                      //                 if (_enable) {
                      //                   checkCoupon(couponController.text);
                      //                 } else {
                      //                   setState(() {
                      //                     _enable = true;
                      //                     widget.model.resetCoupon();
                      //                     widget.model.discountAmount = 0.0;
                      //                   });
                      //                 }
                      //               }
                      //             : null,
                      //       )
                      //     ],
                      //   ),
                      // ),
                      // _enable
                      //     ? Container()
                      //     : Padding(
                      //         padding: const EdgeInsets.only(
                      //             left: 40, right: 40, bottom: 15),
                      //         child: Text(
                      //           couponMsg,
                      //           style: GoogleFonts.tajawal(
                      //               color: Theme.of(context).primaryColor),
                      //           textAlign: TextAlign.center,
                      //         ),
                      //       ),
                      SizedBox(
                        height: 10,
                      ),
                      if (widget.model.rewardTotal > 0)
                        const SizedBox(height: 5),
                      if (widget.model.rewardTotal > 0)
                        Row(
                          children: [
                            Expanded(
                              child: Text(S.of(context).cartDiscount,
                                  style: smallAmountStyle),
                            ),
                            Text(
                              '${widget.model.rewardTotal}' + 'ج.م.',
                            ),
                          ],
                        ),
                      const SizedBox(height: 7),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        // padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text('${S.of(context).total}:',
                                  style: largeAmountStyle),
                            ),
                            widget.model.calculatingDiscount
                                ? const SizedBox(
                                    width: 20,
                                    height: 10,
                                  )
                                : Text(

                              '${widget.model.getTotal() - widget.model.getShippingCost()}' + ' ' + S.of(context).currency,
                                  ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

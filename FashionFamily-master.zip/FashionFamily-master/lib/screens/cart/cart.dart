import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../common/config/advertise.dart';
import '../../models/app_model.dart';
import '../../services/index.dart';
import '../custom/smartchat.dart';

class CartScreen extends StatefulWidget {
  final bool isModal;
  final bool isBuyNow;
  final bool showChat;

  CartScreen({this.isModal, this.isBuyNow = false, this.showChat});

  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  PageController pageController = PageController(
    initialPage: 0,
    keepPage: true,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).backgroundColor,
      body: Container(
        child: SafeArea(
          top: false,
          bottom: false,
          child: Services().widget.renderCartPageView(
              isModal: widget.isModal,
              isBuyNow: widget.isBuyNow,
              pageController: pageController,
              context: context),
        ),
      ),
    );
  }
}

import 'package:appsflyer_sdk/appsflyer_sdk.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flash/flash.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fashion/screens/checkout/shipping_address.dart';
import '../../common/config.dart';
import '../../common/constants.dart';
import '../../common/tools.dart';
import '../../generated/l10n.dart';
import '../../models/index.dart' show AppModel, CartModel, Product, UserModel;
import '../../services/index.dart';
import '../../tabbar.dart';
import '../../widgets/product/cart_item.dart';
import '../../widgets/product/product_bottom_sheet.dart';
import '../users/login.dart';
import 'cart_sumary.dart';
import 'empty_cart.dart';
import 'wishlist.dart';
import '../../widgets/common/place_picker.dart';
import 'package:flutter_svg/svg.dart';

class MyCart extends StatefulWidget {
  final PageController controller;
  final bool isModal;
  final bool isBuyNow;

  MyCart({this.controller, this.isModal, this.isBuyNow = false});

  @override
  _MyCartState createState() => _MyCartState();
}

class _MyCartState extends State<MyCart> with SingleTickerProviderStateMixin {
  bool isLoading = false;
  String errMsg = '';

  List<Widget> _createShoppingCartRows(CartModel model, BuildContext context) {
    return model.productsInCart.keys.map(
      (key) {
        String productId = Product.cleanProductID(key);
        Product product = model.getProductById(productId);

        return ShoppingCartRow(
          product: product,
          addonsOptions: model.productAddonsOptionsInCart[key],
          variation: model.getProductVariationById(key),
          quantity: model.productsInCart[key],
          options: model.productsMetaDataInCart[key],
          onRemove: () {
            model.removeItemFromCart(key);
          },
          onChangeQuantity: (val) {
            String message = Provider.of<CartModel>(context, listen: false)
                .updateQuantity(product, key, val, context: context);
            if (message.isNotEmpty) {
              final snackBar = SnackBar(
                content: Text(message),
                duration: const Duration(seconds: 1),
              );
              Future.delayed(
                  const Duration(milliseconds: 300),
                  // ignore: deprecated_member_use
                  () => Scaffold.of(context).showSnackBar(snackBar));
            }
          },
        );
      },
    ).toList();
  }

  _loginWithResult(BuildContext context) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => LoginScreen(
          fromCart: true,
        ),
        fullscreenDialog: kIsWeb,
      ),
    );

    if (result != null && result.name != null) {
      Tools.showSnackBar(Scaffold.of(context),
          S.of(context).welcome + " ${result.name} !", context);

      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final localTheme = Theme.of(context);
    final screenSize = MediaQuery.of(context).size;
    var productDetail =
        Provider.of<AppModel>(context).appConfig['Setting']['ProductDetail'];
    var layoutType =
        productDetail ?? (kProductDetail['layout'] ?? 'simpleType');
    CartModel cartModel = Provider.of<CartModel>(context);

    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      resizeToAvoidBottomInset: false,
      // backgroundColor: Colors.black,
    //   floatingActionButton: Column(
    //     children: [
    //   Container(
    //   decoration: BoxDecoration(
    //   color: Colors.white, borderRadius: BorderRadius.circular(30)),
    //   child: Consumer<CartModel>(
    //     builder: (context, model, child) {
    //       return GestureDetector(
    //         onTap: () {
    //           FocusScopeNode currentFocus = FocusScope.of(context);
    //           if (!currentFocus.hasPrimaryFocus) {
    //             currentFocus.unfocus();
    //           }
    //         },
    //         child: Column(
    //           crossAxisAlignment: CrossAxisAlignment.center,
    //           mainAxisAlignment: MainAxisAlignment.center,
    //           children: [
    //             Column(
    //               crossAxisAlignment: CrossAxisAlignment.center,
    //               children: <Widget>[
    //                 if (model.totalCartQuantity > 0)
    //                   ShoppingCartSummary(model: model),
    //               ],
    //             ),
    //             Container(
    //               // width: double.infinity,
    //                 padding: EdgeInsets.symmetric(horizontal: 10),
    //                 // margin: EdgeInsets.symmetric(horizontal: 5),
    //                 child: FlatButton(
    //                   height: 45,
    //                   shape: new RoundedRectangleBorder(
    //                       borderRadius:
    //                       new BorderRadius.circular(10.0)),
    //                   color: Color(0xff4f3933),
    //                   onPressed: cartModel.calculatingDiscount
    //                       ? null
    //                       : () => onCheckout(cartModel),
    //
    //                   //  onCheckout(cartModel),
    //                   child: Row(
    //                     crossAxisAlignment: CrossAxisAlignment.center,
    //                     mainAxisAlignment: MainAxisAlignment.center,
    //                     children: [
    //                       Icon(
    //                         Icons.payment,
    //                         size: 15,
    //                         color: Colors.white,
    //                       ),
    //                       SizedBox(
    //                         width: 10,
    //                       ),
    //                       cartModel.totalCartQuantity > 0
    //                           ? (isLoading
    //                           ? Text(
    //                         S
    //                             .of(context)
    //                             .loading
    //                             .toUpperCase(),
    //                         style: GoogleFonts.tajawal(),
    //                       )
    //                           : Text("اكمل تفاصيل الطلب",
    //                           style: GoogleFonts.tajawal(
    //                               fontSize: 13,
    //                               color: Colors.white)))
    //                           : Text(
    //                           S
    //                               .of(context)
    //                               .startShopping
    //                               .toUpperCase(),
    //                           style: GoogleFonts.tajawal(
    //                               fontSize: 13,
    //                               color: Colors.white)),
    //                     ],
    //                   ),
    //                 )),
    //           ],
    //         ),
    //       );
    //     },
    //   ),
    // ),
    //
    //       // Container(
    //       //     // width: double.infinity,
    //       //     padding: EdgeInsets.symmetric(horizontal: 10),
    //       //     // margin: EdgeInsets.symmetric(horizontal: 5),
    //       //     child: FlatButton(
    //       //       shape: new RoundedRectangleBorder(
    //       //           // side: BorderSide(width: 0.9, color: Colors.black),
    //       //           borderRadius: new BorderRadius.circular(10.0)),
    //       //       color: Color(0xff4f3933),
    //       //       height: 45,
    //       //       onPressed: () {
    //       //         if (cartModel.totalCartQuantity != 0) {
    //       //           _showSheet();
    //       //         } else {
    //       //           if (Navigator.canPop(context)) {
    //       //             Navigator.pop(context);
    //       //           } else {
    //       //             MainTabControlDelegate.getInstance().tabAnimateTo(0);
    //       //           }
    //       //         }
    //       //       },
    //       //       //  onCheckout(cartModel),
    //       //       child: Row(
    //       //         crossAxisAlignment: CrossAxisAlignment.center,
    //       //         mainAxisAlignment: MainAxisAlignment.center,
    //       //         children: [
    //       //           Icon(
    //       //             Icons.payment,
    //       //             size: 15,
    //       //             color: Colors.white,
    //       //           ),
    //       //           SizedBox(
    //       //             width: 10,
    //       //           ),
    //       //           cartModel.totalCartQuantity > 0
    //       //               ? (isLoading
    //       //                   ? Text(
    //       //                       S.of(context).loading.toUpperCase(),
    //       //                       style: GoogleFonts.tajawal(),
    //       //                     )
    //       //                   : Text("رؤية تفاصيل الطلب",
    //       //                       style: GoogleFonts.tajawal(
    //       //                           fontSize: 13, color: Colors.white)))
    //       //               : Text(S.of(context).startShopping.toUpperCase(),
    //       //                   style: GoogleFonts.tajawal(
    //       //                       fontSize: 13, color: Colors.white)),
    //       //         ],
    //       //       ),
    //       //     )),
    //     ],
    //   ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      body: Provider.of<CartModel>(context, listen: false).totalCartQuantity == 0
          ? EmptyCart()
          : Stack(
            children: [
              SafeArea(
                  bottom: false,
                  child: Column(
                    children: [
                      renderHeader(),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(topRight: Radius.circular(30), topLeft: Radius.circular(30))

                          ),
                          // color: Colors.white,
                          child: Consumer<CartModel>(
                            builder: (context, model, child) {
                              return GestureDetector(
                                onTap: () {
                                  FocusScopeNode currentFocus =
                                      FocusScope.of(context);
                                  if (!currentFocus.hasPrimaryFocus) {
                                    currentFocus.unfocus();
                                  }
                                },
                                child: Column(
                                  children: [
                                    SizedBox(
                                      height:
                                          MediaQuery.of(context).size.height *
                                              .01,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 10),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            children: [
                                              Container(
                                                  width: 50,
                                                  height: 50,
                                                  decoration: BoxDecoration(
                                                    color: Theme.of(context).primaryColor.withOpacity(0.1),
                                                    borderRadius: BorderRadius.circular(10),

                                                  ),
                                                  child: Icon(Icons.shopping_cart_outlined,color: Theme.of(context).primaryColor,size: 30,),
                                              ),
                                              SizedBox(width: 10,),
                                              Text(
                                                S.of(context).totalCartItems,
                                              ),
                                            ],
                                          ),

                                          Text(
                                            "${model.totalCartQuantity} " + S.of(context).items,
                                          ),
                                        ],
                                      ),
                                    ),

                                    Expanded(
                                      child: SingleChildScrollView(
                                        physics: BouncingScrollPhysics(),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: <Widget>[
                                            // if (model.totalCartQuantity > 0)
                                            //   ShoppingCartSummary(model: model),
                                            if (model.totalCartQuantity > 0)
                                              Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 10),
                                                child: Column(
                                                  children:
                                                      _createShoppingCartRows(
                                                          model, context),
                                                ),
                                              ),

                                            // if (model.totalCartQuantity == 0)
                                            //   EmptyCart(),
                                            if (errMsg.isNotEmpty)
                                              Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 15,
                                                        vertical: 10),
                                                child: Text(
                                                  errMsg,
                                                  style: GoogleFonts.tajawal(
                                                      color: Colors.red),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            // const SizedBox(height: 4.0),
                                            //                 if (model.totalCartQuantity > 0)
                                            //                   Container(
                                            //                     margin: const EdgeInsets.symmetric(
                                            //                         vertical: 10, horizontal: 15),
                                            //                     decoration: BoxDecoration(
                                            //                         color: Theme.of(context)
                                            //                             .primaryColorLight,
                                            //                         borderRadius:
                                            //                             BorderRadius.circular(20)),
                                            //                     child: Padding(
                                            //                       padding: const EdgeInsets.only(
                                            //                           right: 15.0, top: 4.0),
                                            //                       child: Container(
                                            //                         width: screenSize.width,
                                            //                         decoration: BoxDecoration(
                                            //                             borderRadius:
                                            //                                 BorderRadius.circular(20)),
                                            //                         child: Container(
                                            //                           width: screenSize.width /
                                            //                               (2 /
                                            //                                   (screenSize.height /
                                            //                                       screenSize.width)),
                                            //                           decoration: BoxDecoration(
                                            //                               borderRadius:
                                            //                                   BorderRadius.circular(20)),
                                            //                           child: Row(
                                            // mainAxisAlignment:MainAxisAlignment.spaceBetween,
                                            //                             children: [
                                            //
                                            //                               Text(
                                            //                                 S
                                            //                                     .of(context)
                                            //                                     .total
                                            //                                     .toUpperCase(),
                                            //                                 style: GoogleFonts.tajawal(
                                            //                                     fontWeight:
                                            //                                         FontWeight.w600,
                                            //                                     color: Theme.of(context)
                                            //                                         .accentColor,
                                            //                                     fontSize: 14),
                                            //                               ),
                                            //                               // const SizedBox(width: 8.0),
                                            //                               Text(
                                            //                                 '${model.totalCartQuantity} ${S.of(context).items}',
                                            //                                 style: GoogleFonts.tajawal(
                                            //                                     color: Theme.of(context)
                                            //                                         .accentColor),
                                            //                               ),
                                            //                               RaisedButton(
                                            //                                 child: Text(
                                            //                                   S
                                            //                                       .of(context)
                                            //                                       .clearCart
                                            //                                       .toUpperCase(),
                                            //                                   style:
                                            //                                       GoogleFonts.tajawal(
                                            //                                           color:
                                            //                                               Colors.red),
                                            //                                 ),
                                            //                                 onPressed: () {
                                            //                                   if (model
                                            //                                           .totalCartQuantity >
                                            //                                       0) {
                                            //                                     model.clearCart();
                                            //                                   }
                                            //                                 },
                                            //                                 color: Theme.of(context)
                                            //                                     .primaryColorLight,
                                            //                                 textColor: Colors.white,
                                            //                                 elevation: 0.1,
                                            //                               )
                                            //                             ],
                                            //                           ),
                                            //                         ),
                                            //                       ),
                                            //                     ),
                                            //                   ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height:
                                          MediaQuery.of(context).size.height *
                                              .3,
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                      Container(
                        color: Colors.white,

                      ),
                    ],
                  ),
                ),
              Padding(
                padding: const EdgeInsets.only(bottom: 90, left: 10, right: 10),
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15)
                    ),
                    child: Container(
                      height: MediaQuery.of(context).size.height*0.19,
                      decoration: BoxDecoration(
                          color: Colors.white, borderRadius: BorderRadius.circular(30)),
                      child: Consumer<CartModel>(
                        builder: (context, model, child) {
                          return GestureDetector(
                            onTap: () {
                              FocusScopeNode currentFocus = FocusScope.of(context);
                              if (!currentFocus.hasPrimaryFocus) {
                                currentFocus.unfocus();
                              }
                            },
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    if (model.totalCartQuantity > 0)
                                      ShoppingCartSummary(model: model),
                                  ],
                                ),
                                Container(
                                  // width: double.infinity,
                                    padding: EdgeInsets.symmetric(horizontal: 10),
                                    // margin: EdgeInsets.symmetric(horizontal: 5),
                                    child: FlatButton(
                                      height: 45,
                                      shape: new RoundedRectangleBorder(
                                          borderRadius:
                                          new BorderRadius.circular(10.0)),
                                      color: Theme.of(context).primaryColor,
                                      onPressed: cartModel.calculatingDiscount
                                          ? null
                                          : () => onCheckout(cartModel),

                                      //  onCheckout(cartModel),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Icons.payment,
                                            size: 15,
                                            color: Colors.white,
                                          ),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          cartModel.totalCartQuantity > 0
                                              ? (isLoading
                                              ? Text(
                                            S
                                                .of(context)
                                                .loading
                                                .toUpperCase(),
                                            style: GoogleFonts.tajawal(),
                                          )
                                              : Text(S.of(context).proceedto,
                                              style: GoogleFonts.tajawal(
                                                  fontSize: 13,
                                                  color: Colors.white)))
                                              : Text(
                                              S
                                                  .of(context)
                                                  .startShopping
                                                  .toUpperCase(),
                                              style: GoogleFonts.tajawal(
                                                  fontSize: 13,
                                                  color: Colors.white)),
                                        ],
                                      ),
                                    )),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
    );
  }

  void _showSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(10), topRight: Radius.circular(10)),
      ),
      builder: (_) {
        CartModel cartModel = Provider.of<CartModel>(context);
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: .45,
          minChildSize: .20,
          builder: (_, controller) {
            return Container(
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(30)),
              child: Consumer<CartModel>(
                builder: (context, model, child) {
                  return GestureDetector(
                    onTap: () {
                      FocusScopeNode currentFocus = FocusScope.of(context);
                      if (!currentFocus.hasPrimaryFocus) {
                        currentFocus.unfocus();
                      }
                    },
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          child: SingleChildScrollView(
                            controller: controller,
                            physics: BouncingScrollPhysics(),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                if (model.totalCartQuantity > 0)
                                  ShoppingCartSummary(model: model),
                              ],
                            ),
                          ),
                        ),
                        Container(
                            // width: double.infinity,
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            // margin: EdgeInsets.symmetric(horizontal: 5),
                            child: FlatButton(
                              height: 45,
                              shape: new RoundedRectangleBorder(
                                  borderRadius:
                                      new BorderRadius.circular(10.0)),
                              color: Color(0xff4f3933),
                              onPressed: cartModel.calculatingDiscount
                                  ? null
                                  : () => onCheckout(cartModel),

                              //  onCheckout(cartModel),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.payment,
                                    size: 15,
                                    color: Colors.white,
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  cartModel.totalCartQuantity > 0
                                      ? (isLoading
                                          ? Text(
                                              S
                                                  .of(context)
                                                  .loading
                                                  .toUpperCase(),
                                              style: GoogleFonts.tajawal(),
                                            )
                                          : Text("اكمل تفاصيل الطلب",
                                              style: GoogleFonts.tajawal(
                                                  fontSize: 13,
                                                  color: Colors.white)))
                                      : Text(
                                          S
                                              .of(context)
                                              .startShopping
                                              .toUpperCase(),
                                          style: GoogleFonts.tajawal(
                                              fontSize: 13,
                                              color: Colors.white)),
                                ],
                              ),
                            )),
                      ],
                    ),
                  );
                },
              ),
            );
          },
        );
      },
    );
  }

  Widget renderHeader() {
    final screenSize = MediaQuery.of(context).size;
    return Container(
      width: screenSize.width,
      child: Container(
        width:
            screenSize.width / (2 / (screenSize.height / screenSize.width)),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                elevation: 5,
                child: InkWell(
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> MainTabs()));
                  },
                  child: Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      // border: Border.all(color: Theme.of(context).primaryColor, width: 1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(child: Icon(
                      Icons.arrow_back_ios,
                      color: Theme.of(context).primaryColor,size: 20,)),
                  ),
                ),
              ),

              Text(S.of(context).cart,
                  style: GoogleFonts.tajawal(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black)),
              Card(
                color: Colors.transparent,
                elevation: 0.0,
                child: Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> onCheckout(model) async {
    bool isLoggedIn = Provider.of<UserModel>(context, listen: false).loggedIn;
    final currencyRate =
        Provider.of<AppModel>(context, listen: false).currencyRate;
    final currency = Provider.of<AppModel>(context, listen: false).currency;
    Map appsFlyerOptions = {
      "afDevKey": "ZZparsHDZ68cKuxsNbvpUJ",
      "afAppId": "1614618732",
      "isDebug": true
    };

    AppsflyerSdk appsflyerSdk = await AppsflyerSdk(appsFlyerOptions);
    appsflyerSdk.logEvent(
      "send_to_checkout",
      {
        'send_to_checkout': 'the_clickme_button',
      },
    );

    if (isLoading) return;

    if (kCartDetail['minAllowTotalCartValue'] != null) {
      if (kCartDetail['minAllowTotalCartValue'].toString().isNotEmpty) {
        double totalValue = model.getSubTotal();
        String minValue = Tools.getCurrencyFormatted(
            kCartDetail['minAllowTotalCartValue'], currencyRate,
            currency: currency);
        if (totalValue < kCartDetail['minAllowTotalCartValue'] &&
            model.totalCartQuantity > 0) {
          showFlash(
            context: context,
            duration: const Duration(seconds: 3),
            builder: (context, controller) {
              return SafeArea(
                child: Flash(
                  borderRadius: BorderRadius.circular(3.0),
                  backgroundColor: Theme.of(context).errorColor,
                  controller: controller,
                  style: FlashStyle.grounded,
                  position: FlashPosition.top,
                  horizontalDismissDirection:
                      HorizontalDismissDirection.horizontal,
                  child: FlashBar(
                    icon: const Icon(
                      Icons.check,
                      color: Colors.white,
                    ),
                    message: Text(
                      'Total order\'s value must be at least $minValue',
                      style: GoogleFonts.tajawal(
                        color: Colors.white,
                        fontSize: 18.0,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              );
            },
          );

          return;
        }
      }
    }

    if (model.totalCartQuantity == 0) {
      if (widget.isModal == true) {
        try {
          ExpandingBottomSheet.of(context).close();
        } catch (e) {
          Navigator.of(context).pushNamed(RouteList.dashboard);
        }
      } else {
        Navigator.of(context).pushNamed(RouteList.dashboard);
      }
    } else if (isLoggedIn || kPaymentConfig['GuestCheckout'] == true) {
      doCheckout();
    } else {
      _loginWithResult(context);
    }
  }

  Future<void> doCheckout() async {
    showLoading();

    await Services().widget.doCheckout(context, success: () async {
      hideLoading('');
      await Provider.of<UserModel>(context, listen: false).loggedIn
          ? Navigator.of(context, rootNavigator: true).push(MaterialPageRoute(
              builder: (BuildContext context) => ShippingAddress()))
          : showDialog(
              barrierDismissible: true,
              context: context,
              builder: (context) {
                return AlertDialog(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(
                      Radius.circular(15.0),
                    ),
                  ),
                  elevation: 5.0,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
                  content: Container(
                    width: 100,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Text(
                          "يجب عليك تسجيل الدخول",
                          style: GoogleFonts.tajawal(
                            fontSize: 16.0,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.3,
                          ),
                        ),
                        SizedBox(
                          height: 15.0,
                        ),
                        Text(
                          "يجب عليك تسجيل الدخول\n لأكمال تفاصيل الطلب",
                          style: GoogleFonts.tajawal(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.3,
                          ),
                        ),
                        SizedBox(
                          height: 25.0,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            InkWell(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: Container(
                                child: Text(
                                  "لاحقاَ",
                                  style: GoogleFonts.tajawal(
                                    fontSize: 14.0,
                                    color: Colors.red,
                                    fontWeight: FontWeight.w600,
                                    letterSpacing: 0.3,
                                  ),
                                ),
                              ),
                            ),
                            InkWell(
                              onTap: () {
                                Navigator.of(
                                  context,
                                  rootNavigator: true,
                                ).pushNamedAndRemoveUntil(
                                  RouteList.login,
                                  (route) => false,
                                );
                              },
                              child: Container(
                                child: Text(
                                  " تسجيل الدخول",
                                  style: GoogleFonts.tajawal(
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 0.3,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
    }, error: (message) async {
      if (message ==
          Exception("Token expired. Please logout then login again")
              .toString()) {
        setState(() {
          isLoading = false;
        });
        //logout
        final userModel = Provider.of<UserModel>(context, listen: false);
        final _auth = FirebaseAuth.instance;
        await userModel.logout();
        await _auth.signOut();
        _loginWithResult(context);
      } else {
        hideLoading(message);
        Future.delayed(const Duration(seconds: 3), () {
          setState(() => errMsg = '');
        });
      }
    }, loading: (isLoading) {
      setState(() {
        this.isLoading = isLoading;
      });
    });
  }

  void showLoading() {
    setState(() {
      isLoading = true;
      errMsg = '';
    });
  }

  void hideLoading(error) {
    setState(() {
      isLoading = false;
      errMsg = error;
    });
  }
}

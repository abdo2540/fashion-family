import 'dart:io';

import 'package:fashion/caco/home/components/home_featured_list_item.dart';
import 'package:fashion/caco/shimmer_product_list_item.dart';
import 'package:fashion/common/constants/loading.dart';
import 'package:fashion/common/constants/route_list.dart';
import 'package:fashion/screens/cart/my_cart.dart';
import 'package:fashion/widgets/common/start_rating.dart';
import 'package:fashion/widgets/product/heart_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../services/index.dart';
import 'package:shimmer/shimmer.dart';
import 'package:pull_to_refresh/src/smart_refresher.dart';
import 'package:appsflyer_sdk/appsflyer_sdk.dart';
import 'package:pull_to_refresh/src/indicator/material_indicator.dart';
import 'package:pull_to_refresh/src/indicator/custom_indicator.dart';
import '../../generated/l10n.dart';
import '../../models/index.dart'
    show
    AppModel,
    CartModel,
    Category,
    CategoryModel,
    FilterAttributeModel,
    Product,
    ProductModel,
    RecentModel;
import '../../services/index.dart';
import '../../share.dart';
import '../../tabbar.dart';
import '../../widgets/asymmetric/asymmetric_view.dart';
import '../../widgets/backdrop/backdrop.dart';
import '../../widgets/backdrop/backdrop_menu.dart';
import '../../widgets/common/countdown_timer.dart';
import '../../widgets/product/product_bottom_sheet.dart';
import '../../widgets/product/product_list.dart';
import 'products_backdrop.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_styled_toast/src/styled_toast.dart';
import 'package:flutter_styled_toast/src/styled_toast_enum.dart';
import 'package:flutter_svg/svg.dart';
import 'package:sizer/sizer_ext.dart';

class ProductsPage extends StatefulWidget {
  final List<Product> products;
  final String categoryId;
  final String tagId;
  final Map<String, dynamic> config;
  final bool onSale;
  final bool showCountdown;
  final Duration countdownDuration;
  final String title;
  ProductsPage({
    this.products,
    this.categoryId,
    this.config,
    this.tagId,
    this.onSale,
    this.showCountdown = false,
    this.countdownDuration = Duration.zero,
    this.title,
  });

  @override
  State<StatefulWidget> createState() {
    return ProductsPageState();
  }
}

class ProductsPageState extends State<ProductsPage>
    with SingleTickerProviderStateMixin {
  AnimationController _controller;
  List<Category> categories = [];
  List<Category> showCategories = [];

  String newTagId;
  String newCategoryId;
  double minPrice;
  double maxPrice;
  String orderBy;
  String orDer;
  String attribute;

//  int attributeTerm;
  bool featured;
  bool onSale;

  bool isFiltering = false;
  List<Product> products = [];
  String errMsg;
  int _page = 1;
  RefreshController _refreshController;
  @override
  void initState() {
    super.initState();
    _refreshController = RefreshController(initialRefresh: false);
    setState(() {
      newCategoryId = widget.categoryId ?? '-1';
      newTagId = widget.tagId;
      onSale = widget.onSale;
    });
    // _controller = AnimationController(
    //   vsync: this,
    //   duration: const Duration(milliseconds: 450),
    //   value: 1.0,
    // );

    if (widget.config != null) {
      onRefresh();
    }
  }

  void onFilter(
      {minPrice,
        maxPrice,
        categoryId,
        tagId,
        attribute,
        currentSelectedTerms}) {
    // _controller.forward();

    final productModel = Provider.of<ProductModel>(context, listen: false);
    final filterAttr =
    Provider.of<FilterAttributeModel>(context, listen: false);
    newCategoryId = categoryId;
    newTagId = tagId;
    this.minPrice = minPrice;
    this.maxPrice = maxPrice;
    if (attribute != null && !attribute.isEmpty) this.attribute = attribute;
    String terms = '';

    if (currentSelectedTerms != null) {
      for (int i = 0; i < currentSelectedTerms.length; i++) {
        if (currentSelectedTerms[i]) {
          terms += '${filterAttr.lstCurrentAttr[i].id},';
        }
      }
    }

    productModel.setProductsList(List<Product>());

    productModel.getProductsList(
      categoryId: categoryId == -1 ? null : categoryId,
      minPrice: minPrice,
      maxPrice: maxPrice,
      page: 1,
      lang: Provider.of<AppModel>(context, listen: false).langCode,
      orderBy: orderBy,
      order: orDer,
      featured: featured,
      onSale: onSale,
      tagId: tagId,
      attribute: attribute,
      attributeTerm: terms.isEmpty ? null : terms,
    );
  }

  void onSort(order) {
    if (order == "date") {
      featured = null;
      onSale = null;
    } else {
      featured = order == "featured";
      onSale = order == "on_sale";
    }

    final filterAttr =
    Provider.of<FilterAttributeModel>(context, listen: false);
    String terms = '';
    for (int i = 0; i < filterAttr.lstCurrentSelectedTerms.length; i++) {
      if (filterAttr.lstCurrentSelectedTerms[i]) {
        terms += '${filterAttr.lstCurrentAttr[i].id},';
      }
    }
    Provider.of<ProductModel>(context, listen: false).getProductsList(
      categoryId: newCategoryId == '-1' ? null : newCategoryId,
      minPrice: minPrice,
      maxPrice: maxPrice,
      lang: Provider.of<AppModel>(context, listen: false).langCode,
      page: 1,
      orderBy: 'date',
      order: 'desc',
      featured: featured,
      onSale: onSale,
      attribute: attribute,
      attributeTerm: terms,
      tagId: newTagId,
    );
  }

  Future<void> onRefresh() async {
    _page = 1;
    if (widget.config == null) {
      final filterAttr =
      Provider.of<FilterAttributeModel>(context, listen: false);
      String terms = '';
      for (int i = 0; i < filterAttr.lstCurrentSelectedTerms.length; i++) {
        if (filterAttr.lstCurrentSelectedTerms[i]) {
          terms += '${filterAttr.lstCurrentAttr[i].id},';
        }
      }
      await Provider.of<ProductModel>(context, listen: false).getProductsList(
        categoryId: newCategoryId == '-1' ? null : newCategoryId,
        minPrice: minPrice,
        maxPrice: maxPrice,
        lang: Provider.of<AppModel>(context, listen: false).langCode,
        page: 1,
        orderBy: orderBy,
        order: orDer,
        attribute: attribute,
        attributeTerm: terms,
        tagId: newTagId,
      );
    } else {
      try {
        var newProducts = await Services().fetchProductsLayout(
            config: widget.config,
            lang: Provider.of<AppModel>(context, listen: false).langCode);
        setState(() {
          products = newProducts;
        });
      } catch (err) {
        setState(() {
          errMsg = err;
        });
      }
    }
  }

  Widget renderCategoryAppbar() {
    final category = Provider.of<CategoryModel>(context);
    String parentCategory = newCategoryId;
    var Categories = Provider.of<CategoryModel>(context);

    if (category.categories != null && category.categories.isNotEmpty) {
      parentCategory =
          getParentCategories(category.categories, parentCategory) ??
              parentCategory;
      final listSubCategory =
      getSubCategories(category.categories, parentCategory);

      // if (listSubCategory.length < 2)
      return ListenableProvider.value(
        value: category,
        child: Consumer<CategoryModel>(builder: (context, value, child) {
          if (value.isLoading) {
            return Center(child: kLoadingWidget(context));
          }

          if (value.categories != null) {
            List<Widget> _renderListCategory = List();
            _renderListCategory.add(const SizedBox(width: 10));

            _renderListCategory.add(_renderItemCategory(
                categoryId: parentCategory,
                categoryName: S.of(context).seeAll));

            _renderListCategory.addAll([
              for (var category
              in getSubCategories(value.categories, parentCategory))
                _renderItemCategory(
                    categoryId: category.id, categoryName: category.name)
            ]);

            return SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: _renderListCategory,
              ),
            );
          }

          return Container();
        }),
      );
    }
    return null;
  }

  List<Category> getSubCategories(categories, id) {
    return categories.where((o) => o.parent == id).toList();
  }

  String getParentCategories(categories, id) {
    for (var item in categories) {
      if (item.id == id) {
        return (item.parent == null || item.parent == '0') ? null : item.parent;
      }
    }
    return '0';
    // return categories.where((o) => ((o.id == id) ? o.parent : null));
  }

  Widget _renderItemCategory({String categoryId, String categoryName}) {
    return Stack(
      children: [
        GestureDetector(
          child: Container(
            // height: 40,
            // duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
            // margin: const EdgeInsets.symmetric(horizontal: 3),
            decoration: BoxDecoration(
              color: newCategoryId == categoryId
                  ? Colors.transparent
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(30),
            ),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 5),
              height: 40,
              decoration: BoxDecoration(

                  color: newCategoryId == categoryId
                      ? Theme.of(context).primaryColor
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(10)
              ),
              child: Center(
                child: Text(
                  categoryName.toUpperCase(),
                  style: TextStyle(
                    fontSize: 15.5,
                    letterSpacing: 0.5,
                    fontWeight: FontWeight.bold,
                    color: newCategoryId == categoryId
                        ? Colors.white
                        : Colors.grey,
                  ),
                ),
              ),
            ),
          ),
          onTap: () {
            _page = 1;
            Provider.of<ProductModel>(context, listen: false).getProductsList(
              categoryId: categoryId,
              page: _page,
              onSale: onSale,
              lang: Provider.of<AppModel>(context, listen: false).langCode,
              tagId: newTagId,
            );

            setState(() {
              newCategoryId = categoryId;
              onFilter(
                minPrice: minPrice,
                maxPrice: maxPrice,
                categoryId: newCategoryId,
                tagId: newTagId,
              );
            });
          },
        ),
      ],
    );
  }

  void onLoadMore() {
    _page = _page + 1;
    final filterAttr =
    Provider.of<FilterAttributeModel>(context, listen: false);
    String terms = '';
    for (int i = 0; i < filterAttr.lstCurrentSelectedTerms.length; i++) {
      if (filterAttr.lstCurrentSelectedTerms[i]) {
        terms += '${filterAttr.lstCurrentAttr[i].id},';
      }
    }
    Provider.of<ProductModel>(context, listen: false).getProductsList(
      categoryId: newCategoryId == '-1' ? null : newCategoryId,
      minPrice: minPrice,
      maxPrice: maxPrice,
      lang: Provider.of<AppModel>(context, listen: false).langCode,
      page: _page,
      orderBy: orderBy,
      order: orDer,
      featured: featured,
      onSale: onSale,
      attribute: attribute,
      attributeTerm: terms,
      tagId: widget.tagId,
    );
  }

  Widget kCustomFooter(context) => CustomFooter(
    builder: (BuildContext context, LoadStatus mode) {
      Widget body;
      if (mode == LoadStatus.idle) {
        body = Text(S.of(context).pullToLoadMore);
      } else if (mode == LoadStatus.loading) {
        body = kLoadingWidget(context);
      } else if (mode == LoadStatus.failed) {
        body = Text(S.of(context).loadFail);
      } else if (mode == LoadStatus.canLoading) {
        body = Text(S.of(context).releaseToLoadMore);
      } else {
        body = Text(S.of(context).noData);
      }
      return Container(
        height: 55.0,
        child: Center(child: body),
      );
    },
  );
  @override
  Widget build(BuildContext context) {
    var proList = Provider.of<ProductModel>(context);
    var totalCart = Provider.of<CartModel>(context).totalCartQuantity;
    final screenSize = MediaQuery.of(context).size;
    return Scaffold(
      body: Column(
        children: [
          SizedBox(
            height: 30,
          ),
          buildPaddingAppBAr(),
          SizedBox(height: 5),
          renderCategoryAppbar2(),

          Expanded(
            child: Container(
              width: 100.0.w,
              // height: 89.5.h,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(topLeft: Radius.circular(30), topRight: Radius.circular(30)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10.0,
                    spreadRadius: 2.0,
                    offset: const Offset(0.0, 10.0),
                  ),
                ],
              ),
              child: Column(
                children: [
                  SizedBox(
                    height: 20,
                  ),
                  renderCategoryAppbar(),
                  Expanded(
                    child: ListenableProvider.value(
                      value: proList,
                      child: Consumer<ProductModel>(
                          builder: (context, value, child) {
                            if (value.productsList.length == 0) {
                              return GridView.builder(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 6, horizontal: 6),
                                  physics: const BouncingScrollPhysics(),
                                  shrinkWrap: true,
                                  itemCount: 10,
                                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 2,
                                    crossAxisSpacing: 1,
                                    mainAxisSpacing: 1,
                                    childAspectRatio: 1.5 / 2,
                                  ),
                                  itemBuilder: (context, index) {
                                    return Container(
                                      height: 150,
                                      child: Shimmer.fromColors(
                                        period: Duration(milliseconds: 300),
                                        baseColor: Colors.black,
                                        highlightColor: Colors.white,
                                        child: Container(
                                          width: 150.0,
                                          height: 120,
                                          child: ShimmerProductListItem(),
                                        ),
                                      ),
                                    );
                                  });
                            }
                            return Container(
                              padding:
                              EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                              // color: Theme.of(context).backgroundColor,
                              decoration: BoxDecoration(
                                // color: Theme.of(context).backgroundColor,
                                // borderRadius: BorderRadius.only(
                                //     topRight: Radius.circular(30),
                                //     topLeft: Radius.circular(30)),
                              ),
                              child: SmartRefresher(
                                header: MaterialClassicHeader(
                                  backgroundColor: Theme.of(context).backgroundColor,
                                ),
                                enablePullDown: true,
                                enablePullUp: !value.isEnd,
                                footer: kCustomFooter(context),
                                onRefresh: () async {
                                  if (!value.isFetching) {
                                    onRefresh();
                                  }
                                },
                                onLoading: () async {
                                  if (!value.isFetching) {
                                    onLoadMore();
                                  }
                                },
                                controller: _refreshController,
                                child: GridView.builder(
                                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 2,
                                      crossAxisSpacing: 1,
                                      mainAxisSpacing: 1,
                                      childAspectRatio: 1.5 / 2,
                                    ),
                                    primary: false,
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 0),
                                    physics: const BouncingScrollPhysics(),
                                    shrinkWrap: true,
                                    itemCount: value.productsList.length,
                                    itemBuilder: (context, index) {
                                      return InkWell(
                                          onTap: () {
                                            // _showSheet(
                                            //     context, value.productsList[index]);
                                            Navigator.of(
                                              context,
                                              rootNavigator: true,
                                              // rootNavigator: !isBigScreen(context),
                                              // Push in tab for tablet (IPad)
                                            ).pushNamed(
                                              RouteList.productDetail,
                                              arguments: value.productsList[index],
                                            );
                                          },
                                          child: Container(
                                            margin:
                                            const EdgeInsets.only(left: 5,right: 5,top: 10),
                                            decoration: BoxDecoration(
                                                color: Colors.white,
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Colors.grey
                                                        .withOpacity(0.1),
                                                    spreadRadius: 5,
                                                    blurRadius: 7,
                                                    offset: const Offset(0,
                                                        3), // changes position of shadow
                                                  ),
                                                ],
                                                borderRadius:
                                                BorderRadius.circular(
                                                    10)),
                                            child: Column(
                                              crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                              MainAxisAlignment.center,
                                              children: [
                                                Expanded(
                                                  child: Container(
                                                    height: 150,
                                                    width: 200,
                                                    margin: const EdgeInsets
                                                        .symmetric(
                                                      horizontal: 5,
                                                    ),
                                                    child: Padding(
                                                      padding: const EdgeInsets.only(top: 5),
                                                      child: ClipRRect(
                                                          borderRadius:
                                                          BorderRadius
                                                              .circular(
                                                              10),
                                                          child:
                                                          Image.network(
                                                            value.productsList[index]
                                                                .imageFeature,
                                                            fit: BoxFit.cover,
                                                            width: double.infinity,
                                                            height: double.infinity,
                                                          )),
                                                    ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding: const EdgeInsets.symmetric(horizontal: 5),
                                                  child: Row(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .center,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                    children: [
                                                      Flexible(
                                                        child: Text(
                                                          value
                                                              .productsList[
                                                          index]
                                                              .name,
                                                          maxLines: 1,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                          TextAlign.start,
                                                          style:
                                                          const TextStyle(
                                                            color: Colors.black,
                                                            fontWeight:
                                                            FontWeight.bold,
                                                            fontSize: 15,
                                                          ),
                                                        ),
                                                      ),
                                                      HeartButton(
                                                        product:
                                                        value.productsList[
                                                        index],
                                                        size: 18.0,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                // HtmlWidget(
                                                //   productF[index]
                                                //       .description
                                                //       .replaceAll(
                                                //           'src="//',
                                                //           'src="https://'),
                                                //   webView: false,
                                                //   textStyle:
                                                //       TextStyle(
                                                //     fontSize: 13,
                                                //   ),
                                                // ),
                                                const SizedBox(
                                                  height: 5,
                                                ),
                                                Padding(
                                                  padding: const EdgeInsets.only(left: 5,right: 5,bottom: 5),
                                                  child: Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .center,
                                                    children: [
                                                      Text(
                                                        value.productsList[index].price + ' ' +S.of(context).currency,
                                                        maxLines: 2,
                                                        overflow:
                                                        TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                        TextAlign
                                                            .center,
                                                        style:
                                                        const TextStyle(
                                                          color: Colors
                                                              .black,
                                                          fontWeight:
                                                          FontWeight
                                                              .w600,
                                                          fontSize: 15,
                                                        ),
                                                      ),
                                                      Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Text(
                                                            value
                                                                .productsList[
                                                            index]
                                                                .averageRating
                                                                .toString(),
                                                            maxLines: 2,
                                                            overflow:
                                                            TextOverflow
                                                                .ellipsis,
                                                            textAlign:
                                                            TextAlign
                                                                .center,
                                                            style:
                                                            const TextStyle(
                                                              color: Colors
                                                                  .black,
                                                              fontWeight:
                                                              FontWeight
                                                                  .w300,
                                                              fontSize: 11,
                                                            ),
                                                          ),
                                                          SmoothStarRating(
                                                              label:
                                                              const Text(
                                                                  ''),
                                                              allowHalfRating:
                                                              true,
                                                              starCount: 5,
                                                              rating: value
                                                                  .productsList[
                                                              index]
                                                                  .averageRating,
                                                              size: 12.0,
                                                              color: Colors
                                                                  .amber,
                                                              borderColor:
                                                              Colors
                                                                  .amber,
                                                              spacing: 0.0),

                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ));
                                    }
                                ),
                              ),
                            );
                          }),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: Padding(
        padding: Platform.isIOS ?  EdgeInsets.only(bottom:20) : EdgeInsets.only(bottom:20),
        child: SpeedDial(
          foregroundColor: Theme.of(context).primaryColor,
          backgroundColor: Colors.white,
          icon: Icons.phone_rounded,
          activeIcon: Icons.dangerous,
          children: [
            SpeedDialChild(
                backgroundColor: Colors.transparent,
                child: SvgPicture.asset('assets/icons/phonee.svg'),
                label: 'اتصل بنا',
                onTap: (){ShareFunction().launchCaller();}),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/whatsapp.svg'),
                label: 'واتساب',
                onTap: (){ShareFunction().launchWhatApp();}),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/messenger.svg'),
                label: 'ماسنجر',
                onTap: (){ShareFunction().launchMessanger();}),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/ig.svg'),
                label: 'انستجرام',
                onTap: () {
                  ShareFunction().launchInstagram();
                }
            ),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/tiktok.svg'),
                label: 'تيك توك',
                onTap: () {
                  ShareFunction().launchTiktok();
                }
            ),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/facebook.svg'),
                label: 'صفحة الفيس بوك',
                onTap: () {
                  ShareFunction().launchFacebook();
                }
            ),

          ],
        ),
      ),

    );
  }


  Padding buildPaddingAppBAr() {
    var totalCart = Provider.of<CartModel>(context).totalCartQuantity;
    return Padding(
      padding: EdgeInsets.symmetric(
        horizontal: 15,
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  elevation: 5,
                  child: InkWell(
                    onTap: (){
                      Navigator.of(context).pop();
                    },
                    child: Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        // border: Border.all(color: Theme.of(context).primaryColor, width: 1),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Center(child: Icon(
                        Icons.arrow_back_ios,
                        color: Theme.of(context).primaryColor,size: 20,)),
                    ),
                  ),
                ),

                Text(S.of(context).categories,
                    style: GoogleFonts.tajawal(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black)),
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  elevation: 5,
                  child: InkWell(
                    onTap: () {
                      Map appsFlyerOptions = {
                        "afDevKey": "ZZparsHDZ68cKuxsNbvpUJ",
                        "afAppId": "1614618732",
                        "isDebug": true
                      };
                      AppsflyerSdk appsflyerSdk = AppsflyerSdk(appsFlyerOptions);
                      appsflyerSdk.setCurrencyCode("EGP");

                      appsflyerSdk.logEvent(
                        "open_cart",
                        {
                          'open_cart': 'the_clickme_button',
                        },
                      );
                      if (Provider.of<CartModel>(context, listen: false)
                          .totalCartQuantity !=
                          0)
                        Navigator.of(context, rootNavigator: true).push(
                          MaterialPageRoute(builder: (context) => MyCart()),
                        );
                    },
                    child: Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        // border: Border.all(color: Theme.of(context).primaryColor, width: 1),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Center(
                        child: Stack(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: SvgPicture.asset(
                                "assets/fashion/shopping-cart.svg",
                                width: 20,
                                color: Colors.black,

                                // width: 25,
                              ),
                            ),
                            Positioned.fill(
                              child: Align(
                                alignment: Alignment.topRight,
                                child: CircleAvatar(
                                  backgroundColor: Theme.of(context).primaryColor.withOpacity(.9),
                                  child: FittedBox(
                                    child: Padding(
                                      padding: const EdgeInsets.all(1.0),
                                      child: Text(
                                        '${Provider.of<CartModel>(context).totalCartQuantity}',
                                        style: TextStyle(color: Colors.white),
                                      ),
                                    ),
                                  ),
                                  radius: 7,
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                // Container(
                //   height: 50,
                //   width: 50,
                //   decoration: BoxDecoration(
                //     color: Colors.transparent,
                //     borderRadius: BorderRadius.circular(10),
                //   ),
                //
                // ),
              ],
            ),
          ),

          // Row(
          //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //   crossAxisAlignment: CrossAxisAlignment.center,
          //   children: [
          //     IconButton(
          //         icon: Icon(
          //           Icons.arrow_back_ios,
          //           size: 20,
          //           color: Color(0xff4f3933).withOpacity(.9),
          //         ),
          //         onPressed: () {
          //           Navigator.of(context).pop();
          //         }),
          //     Padding(
          //       padding: const EdgeInsets.only(left: 10),
          //       child: Image.asset(
          //         "assets/fashion/fashionLogo.png",
          //         height: 10.0.w,
          //         color: Color(0xff4f3933),
          //         width: 10.0.w,
          //       ),
          //     ),
          //     InkWell(
          //       onTap: () {
          //         Map appsFlyerOptions = {
          //           "afDevKey": "ZZparsHDZ68cKuxsNbvpUJ",
          //           "afAppId": "1614618732",
          //           "isDebug": true
          //         };
          //         AppsflyerSdk appsflyerSdk = AppsflyerSdk(appsFlyerOptions);
          //         appsflyerSdk.setCurrencyCode("EGP");
          //
          //         appsflyerSdk.logEvent(
          //           "open_cart",
          //           {
          //             'open_cart': 'the_clickme_button',
          //           },
          //         );
          //         if (Provider.of<CartModel>(context, listen: false)
          //                 .totalCartQuantity !=
          //             0)
          //           Navigator.of(context, rootNavigator: true).push(
          //             MaterialPageRoute(builder: (context) => MyCart()),
          //           );
          //       },
          //       child: Stack(
          //         children: [
          //           Padding(
          //             padding: const EdgeInsets.all(5.0),
          //             child: SvgPicture.asset(
          //               "assets/fashion/shopping-cart.svg",
          //               width: 20,
          //               color: Colors.black,
          //
          //               // width: 25,
          //             ),
          //           ),
          //           Positioned.fill(
          //             child: Align(
          //               alignment: Alignment.topRight,
          //               child: CircleAvatar(
          //                 backgroundColor: Color(0xff4f3933).withOpacity(.9),
          //                 child: FittedBox(
          //                   child: Padding(
          //                     padding: const EdgeInsets.all(1.0),
          //                     child: Text(
          //                       '${Provider.of<CartModel>(context).totalCartQuantity}',
          //                       style: TextStyle(color: Colors.white),
          //                     ),
          //                   ),
          //                 ),
          //                 radius: 7,
          //               ),
          //             ),
          //           )
          //         ],
          //       ),
          //     ),
          //
          //     // SizedBox(width: getProportionateScreenWidth(10)),
          //   ],
          // ),
        ],
      ),
    );
  }

  Widget renderCategoryAppbar2() {
    final category = Provider.of<CategoryModel>(context);
    String parentCategory = newCategoryId;

    if (category.categories != null && category.categories.isNotEmpty) {
      parentCategory =
          getParentCategories(category.categories, parentCategory) ??
              parentCategory;
      final listSubCategory =
      getSubCategories(category.categories, parentCategory);

      // if (listSubCategory.length < 2)
      return ListenableProvider.value(
        value: category,
        child: Consumer<CategoryModel>(builder: (context, value, child) {
          if (value.isLoading) {
            return Center(child: kLoadingWidget(context));
          }

          if (value.categories != null) {
            List<Widget> _renderListCategory = List();
            _renderListCategory.add(const SizedBox(width: 10));
            //
            // _renderListCategory.add(
            //   _renderItemCategory(
            //     categoryId: parentCategory,
            //     categoryName: S.of(context).seeAll,
            //   ),
            // );
            // categoryPhoto:  'https://image.freepik.com/free-photo/active-woman-being-full-energy-jumps-high-air-wears-sportsclothes-prepares-sport-competitions_176532-9727.jpg'));

            _renderListCategory.addAll([
              for (var category in value.categories
                  .where((item) => item.id != '461' && item.id != "462")
                  .toList())
                _renderItemCategory(
                    categoryId: category.id,
                    categoryName: category.name,
                    )
            ]);

            return Container(
              height: 95,
              // width: 100,
              child: Center(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Container(
                    height: 90,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: _renderListCategory,
                      ),
                    ),
                  ),
                ),
              ),
            );
          }

          return Container();
        }),
      );
    }
    return null;
  }


// Widget build(BuildContext context) {
//   final product = Provider.of<ProductModel>(context, listen: false);
//   final title = S.of(context).products;
//   final layout = widget.config != null && widget.config["layout"] != null
//       ? widget.config["layout"]
//       : Provider.of<AppModel>(context, listen: false).productListLayout;
//
//   final ratioProductImage =
//       Provider.of<AppModel>(context, listen: false).ratioProductImage;
//
//   final isListView = layout != 'horizontal';
//
//   /// load the product base on default 2 columns view or AsymmetricView
//   /// please note that the AsymmetricView is not ready support for loading per page.
//   final backdrop =
//       ({products, isFetching, errMsg, isEnd, width}) => ProductBackdrop(
//             backdrop: Backdrop(
//                 frontLayer:  ProductList(
//                         products: products,
//                         onRefresh: onRefresh,
//                         onLoadMore: onLoadMore,
//                         isFetching: isFetching,
//                         errMsg: errMsg,
//                         isEnd: isEnd,
//                         layout: layout,
//                         ratioProductImage: ratioProductImage,
//                         width: width,
//                         showProgressBar: widget.showCountdown,
//                       ),
//
//                 frontTitle: Text(
//                   "${S.of(context).product}",
//                   style: TextStyle(color: Colors.white),
//                 ),
//                 backTitle: Text(
//                   S.of(context).filter,
//                   style: TextStyle(color: Colors.white),
//                 ),
//                 controller: _controller,
//                 onSort: onSort,
//                 appbarCategory: renderCategoryAppbar()),
//             // expandingBottomSheet:
//             // (!Config().isListingType())
//             //     ? ExpandingBottomSheet(hideController: _controller)
//             //     : null,
//           );
//
//   Widget buildMain = Container(
//     child: LayoutBuilder(
//       builder: (context, constraint) {
//         return FractionallySizedBox(
//           widthFactor: 1.0,
//           child: ListenableProvider.value(
//             value: product,
//             child: Consumer<ProductModel>(builder: (context, value, child) {
//               return backdrop(
//                   products: value.productsList,
//                   isFetching: value.isFetching,
//                   errMsg: value.errMsg,
//                   isEnd: value.isEnd,
//                   width: constraint.maxWidth);
//             }),
//           ),
//         );
//       },
//     ),
//   );
//   return kIsWeb
//       ? WillPopScope(
//           onWillPop: () async {
//             eventBus.fire(const EventOpenCustomDrawer());
//             // LayoutWebCustom.changeStateMenu(true);
//             Navigator.of(context).pop();
//             return false;
//           },
//           child: buildMain,
//         )
//       : buildMain;
// }
}

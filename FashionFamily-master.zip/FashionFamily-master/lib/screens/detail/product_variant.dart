import 'dart:math' as math;
import 'package:shimmer/shimmer.dart';

import '../../widgets/common/tooltip.dart' as tool_tip;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fashion/common/constants/colors.dart';
import 'package:fashion/common/tools.dart';
import 'package:fashion/caco/serv/get_product.dart';
import '../../common/config.dart';
import '../../common/packages.dart' show FlashHelper;
import '../../generated/l10n.dart' show S;
import 'package:fashion/models/product_addons.dart';
import '../../models/index.dart'
    show
        AppModel,
        Attribute,
        Product,
        ProductAttribute,
        ProductModel,
        ProductVariation;
import '../../services/index.dart';
import '../../widgets/common/webview.dart';

class ProductVariant extends StatefulWidget {
  final Product product;
  final Function onSelectVariantImage;

  ProductVariant(
    this.product, {
    this.onSelectVariantImage,
  });

  @override
  _StateProductVariant createState() => _StateProductVariant(product);
}

class _StateProductVariant extends State<ProductVariant> {
  Product product;
  ProductVariation productVariation;
  bool loading = false;
  Map<String, Map<String, AddonsOption>> selectedOptions = {};
  List<AddonsOption> addonsOptions = [];

  _StateProductVariant(this.product);

  final services = Services();
  Map<String, String> mapAttribute = {};
  List<ProductVariation> variations = [];

  int quantity = 1;
  ProductVariation updateVariation(
      List<ProductVariation> variations, Map<String, String> mapAttribute) {
    if (variations != null) {
      var variation = variations.firstWhere((item) {
        bool isCorrect = true;
        for (var attribute in item.attributes) {
          if (attribute.option != mapAttribute[attribute.name] &&
              (attribute.id != null ||
                  checkVariantLengths(variations, mapAttribute))) {
            isCorrect = false;
            break;
          }
        }
        if (isCorrect) {
          for (var key in mapAttribute.keys.toList()) {
            bool check = false;
            for (var attribute in item.attributes) {
              if (key == attribute.name) {
                check = true;
                break;
              }
            }
            if (!check) {
              Attribute att = Attribute()
                ..id = null
                ..name = key
                ..option = mapAttribute[key];
              item.attributes.add(att);
            }
          }
        }
        return isCorrect;
      }, orElse: () {
        return null;
      });
      return variation;
    }
    return null;
  }

  bool checkVariantLengths(variations, mapAttribute) {
    for (var variant in variations) {
      if (variant.attributes.length == mapAttribute.keys.toList().length) {
        bool check = true;
        for (var i = 0; i < variant.attributes.length; i++) {
          if (variant.attributes[i].option !=
              mapAttribute[variant.attributes[i].name]) {
            check = false;
            break;
          }
        }
        if (check) {
          return true;
        }
      }
    }
    return false;
  }

  void updateSelectedOptions(
      Map<String, Map<String, AddonsOption>> selectedOptions) {
    this.selectedOptions = selectedOptions;
    final options = <AddonsOption>[];
    for (var addOns in selectedOptions.values) {
      options.addAll(addOns.values);
    }
    setState(() {
      product.selectedOptions = options;
    });
  }

  /// Get product variants
  Future<void> getProductVariations() async {
    setState(() {
      loading = true;
    });
    await services.widget.getProductVariations(
        context: context,
        product: product,
        onLoad: ({
          Product productInfo,
          List<ProductVariation> variations,
          Map<String, String> mapAttribute,
          ProductVariation variation,
        }) {
          setState(() {
            if (productInfo != null) {
              product = productInfo;
            }
            this.variations = variations;
            this.mapAttribute = mapAttribute;
            if (variation != null) {
              productVariation = variation;

              Provider.of<ProductModel>(context, listen: false)
                  .changeProductVariation(productVariation);
            }
          });
          return;
        });
    setState(() {
      loading = false;
    });
  }

  Future<void> getProductAddons() async {
    await services.widget.getProductAddons(
      context: context,
      product: product,
      selectedOptions: selectedOptions,
      onLoad: (
          {Product productInfo,
          Map<String, Map<String, AddonsOption>> selectedOptions}) {
        if (productInfo != null) {
          product = productInfo;
        }
        if (selectedOptions != null) {
          updateSelectedOptions(selectedOptions);
        }
        setState(() {});
      },
    );
  }

  @override
  void initState() {
    super.initState();
    getProductVariations();
    getProductAddons();
  }

  @override
  void dispose() {
    FlashHelper.dispose();
    super.dispose();
  }

  /// Support Affiliate product
  void openWebView() {
    if (product.affiliateUrl == null || product.affiliateUrl.isEmpty) {
      Navigator.push(context, MaterialPageRoute(builder: (context) {
        return Scaffold(
          appBar: AppBar(
            brightness: Theme.of(context).brightness,
            leading: GestureDetector(
              onTap: () {
                Navigator.pop(context);
              },
              child: const Icon(Icons.arrow_back_ios),
            ),
          ),
          body: Center(
            child: Text(S.of(context).notFound),
          ),
        );
      }));
      return;
    }

    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => WebView(
                  url: product.affiliateUrl,
                  title: product.name,
                )));
  }

  /// Add to Cart & Buy Now function
  void addToCart([bool buyNow = false, bool inStock = false]) {
    services.widget.addToCart(context, product, quantity, productVariation,
        mapAttribute, buyNow, inStock);
  }

  /// check limit select quality by maximum available stock
  int getMaxQuantity() {
    var limitSelectQuantity = kCartDetail['maxAllowQuantity'] ?? 100;
    if (productVariation != null) {
      if (productVariation.stockQuantity != null) {
        limitSelectQuantity = math.min<int>(
            productVariation.stockQuantity, kCartDetail['maxAllowQuantity']);
      }
    } else if (product.stockQuantity != null) {
      limitSelectQuantity =
          math.min<int>(product.stockQuantity, kCartDetail['maxAllowQuantity']);
    }
    return limitSelectQuantity;
  }

  /// Check The product is valid for purchase
  bool couldBePurchased() {
    return services.widget
        .couldBePurchased(variations, productVariation, product, mapAttribute);
  }

  void onSelectProductVariant({
    ProductAttribute attr,
    String val,
    List<ProductVariation> variations,
    Map<String, String> mapAttribute,
    Function onFinish,
  }) {
    services.widget.onSelectProductVariant(
      attr: attr,
      val: val,
      variations: variations == null ? this.variations : variations,
      mapAttribute: mapAttribute,
      onFinish: (Map<String, String> mapAttribute, ProductVariation variation) {
        setState(() {
          this.mapAttribute = mapAttribute;
          productVariation = variation;
        });
        Provider.of<GetProduct>(context, listen: false)
            .updatePrice(nPrice: productVariation.price);
        print("sssssssss" + "${productVariation.price}");
        Provider.of<ProductModel>(context, listen: false)
            .changeProductVariation(variation);
      },
    );
  }

  void onSelectProductAddons({
    Map<String, Map<String, AddonsOption>> selectedOptions,
  }) {
    setState(() {
      updateSelectedOptions(selectedOptions);
    });
  }

  List<Widget> getProductAttributeWidget() {
    final lang = Provider.of<AppModel>(context, listen: false).langCode ?? 'en';
    return services.widget.getProductAttributeWidget(
        lang, product, mapAttribute, onSelectProductVariant, variations);
  }

  List<Widget> getProductAddonsWidget() {
    final lang = Provider.of<AppModel>(context, listen: false).langCode ?? 'en';
    return services.widget.getProductAddonsWidget(
      context: context,
      selectedOptions: selectedOptions,
      lang: lang,
      product: product,
      onSelectProductAddons: onSelectProductAddons,
    );
  }

  List<Widget> getBuyButtonWidget() {
    return services.widget.getBuyButtonWidget(context, productVariation,
        product, mapAttribute, getMaxQuantity(), quantity, addToCart, (val) {
      setState(() {
        quantity = val;
      });
    }, variations);
  }

  List<Widget> getProductTitleWidget() {
    return services.widget
        .getProductTitleWidget(context, productVariation, product);
  }

  var value;
  @override
  Widget build(BuildContext context) {
    FlashHelper.init(context);

    return
      loading == false
        ?
    Column(
            children: <Widget>[
              ...getProductTitleWidget(),
              Column(
                children: [
                  ...getProductAttributeWidget(),
                  ...getProductAddonsWidget(),
                ],
              ),
              ...getBuyButtonWidget(),
            ],
          )
        : Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            // crossAxisAlignment: CrossAxisAlignment.,
            children: <Widget>[
              Shimmer.fromColors(
                period: Duration(milliseconds: 300),
                baseColor: Colors.white,
                highlightColor: Color(0xff4f3933),
                child: Container(
                  width: double.infinity,
                  child: Container(
                    margin: const EdgeInsets.all(8.0),
                    height: 50.0,
                    decoration: BoxDecoration(
                      color: Colors.black
                          .withOpacity(0.2),
                      borderRadius:
                      BorderRadius.circular(12.0),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Shimmer.fromColors(
                period: Duration(milliseconds: 300),
                baseColor: Colors.white,
                highlightColor: Color(0xff4f3933),
                child: Container(
                  width: double.infinity,
                  child: Container(
                    margin: const EdgeInsets.all(8.0),
                    height: 50.0,
                    decoration: BoxDecoration(
                      color: Colors.black
                          .withOpacity(0.2),
                      borderRadius:
                      BorderRadius.circular(12.0),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Shimmer.fromColors(
                period: Duration(milliseconds: 300),
                baseColor: Colors.white,
                highlightColor: Color(0xff4f3933),
                child: Container(
                  width: double.infinity,
                  child: Container(
                    margin: const EdgeInsets.all(8.0),
                    height: 40.0,
                    decoration: BoxDecoration(
                      color: Colors.black
                          .withOpacity(0.2),
                      borderRadius:
                      BorderRadius.circular(12.0),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 5,
              ),
              Shimmer.fromColors(
                period: Duration(milliseconds: 300),
                baseColor: Colors.white,
                highlightColor: Color(0xff4f3933),
                child: Container(
                  width: double.infinity,
                  child: Container(
                    margin: const EdgeInsets.all(8.0),
                    height: 40.0,
                    decoration: BoxDecoration(
                      color: Colors.black
                          .withOpacity(0.2),
                      borderRadius:
                      BorderRadius.circular(12.0),
                    ),
                  ),
                ),
              ),
              // ...getProductTitleWidget(),
              // const SizedBox(
              //   height: 5,
              // ),
              // // Column(
              // //   crossAxisAlignment: CrossAxisAlignment.center,
              // //   mainAxisSize: MainAxisSize.max,
              // //   mainAxisAlignment: MainAxisAlignment.center,
              // //   children: [
              // //     for (ProductAttribute attr in product.infors)
              // //       Padding(
              // //         padding: const EdgeInsets.only(top: 2, bottom: 12,left: 5,right: 5),
              // //         child: Row(
              // //           crossAxisAlignment: CrossAxisAlignment.center,
              // //           mainAxisAlignment: MainAxisAlignment.center,
              // //           children: <Widget>[
              // //             Text(
              // //               "${attr.name}:",
              // //               style: TextStyle(
              // //                   fontSize: 15, fontWeight: FontWeight.bold),
              // //             ),
              // //             for (var item in attr.options)
              // //               // for (var i = 0; i < attr.options.length; i++)
              // //               tool_tip.Tooltip(
              // //                 message: item.toString(),
              // //                 child: Container(
              // //                   //height: type == "color" ? 26 : 30,
              // //                   padding: EdgeInsets.symmetric(horizontal: 3),
              // //                   child: AnimatedContainer(
              // //                     duration: const Duration(milliseconds: 300),
              // //                     curve: Curves.ease,
              // //                     margin:
              // //                         const EdgeInsets.symmetric(horizontal: 1),
              // //                     decoration: attr.name == "color"
              // //                         ? BoxDecoration(
              // //                             color: item == value
              // //                                 ? HexColor(kNameToHex[item
              // //                                         .toString()
              // //                                         .replaceAll(' ', "_")
              // //                                         .toLowerCase()] ??
              // //                                     "#ffffff")
              // //                                 : HexColor(kNameToHex[item
              // //                                             .replaceAll(' ', "_")
              // //                                             .toLowerCase()] ??
              // //                                         "#ffffff")
              // //                                     .withOpacity(0.6),
              // //                             // borderRadius: BorderRadius.circular(),
              // //                             shape: BoxShape.circle,
              // //                           )
              // //                         : BoxDecoration(
              // //                       borderRadius: const BorderRadius
              // //                           .all(
              // //                           const Radius.circular(10)),
              // //                             color: item == value
              // //                                 ? Theme.of(context).primaryColor
              // //                                 : Colors.transparent,
              // //
              // //                           ),
              // //                     child: InkWell(
              // //                       // splashColor: Colors.transparent,
              // //                       // highlightColor: Colors.transparent,
              // //                       onTap: () {
              // //                         setState(() {
              // //                           value = item;
              // //                         });
              // //                         // onChanged(item);
              // //                       },
              // //                       child: attr.name == "color"
              // //                           ? SizedBox(
              // //                               width: 50,
              // //                               height: 50,
              // //                               child: item == value
              // //                                   ? const Icon(
              // //                                       Icons.check,
              // //                                       color: Colors.white,
              // //                                       size: 10,
              // //                                     )
              // //                                   : Container(),
              // //                             )
              // //                           : Container(
              // //                               width: 50,
              // //                               height: 50,
              // //                               decoration: BoxDecoration(
              // //                                 borderRadius: const BorderRadius
              // //                                         .all(
              // //                                     const Radius.circular(10)),
              // //                                 border: Border.all(
              // //                                     width: 1.0,
              // //                                     color: Color(0xff4f3933)),
              // //                               ),
              // //                               padding: const EdgeInsets.all(
              // //                                 5,
              // //                               ),
              // //                               child: Padding(
              // //                                 child: Center(
              // //                                   child: FittedBox(
              // //                                     child: Text(
              // //                                       item,
              // //                                       style: TextStyle(
              // //                                         color: item == value
              // //                                             ? Colors.white
              // //                                             : Theme.of(context)
              // //                                                 .accentColor,
              // //                                         fontSize: 15,
              // //                                       ),
              // //                                     ),
              // //                                   ),
              // //                                 ),
              // //                                 padding: const EdgeInsets.only(
              // //                                     top: 2, bottom: 2),
              // //                               ),
              // //                             ),
              // //                     ),
              // //                   ),
              // //                 ),
              // //               )
              // //           ],
              // //         ),
              // //       ),
              // //   ],
              // // ),
              // const SizedBox(
              //   height: 10,
              // ),
              // ...getBuyButtonWidget(),
              // GestureDetector(
              //   // onTap: () => addToCart(false, inStock),
              //   child: Container(
              //     height: 45,
              //     width: MediaQuery.of(context).size.width - 140,
              //     decoration: BoxDecoration(
              //       borderRadius: BorderRadius.circular(10),
              //       color: Theme.of(context).primaryColor,
              //     ),
              //     child: Center(
              //       child: Text(
              //         S.of(context).addToCart.toUpperCase(),
              //         style: TextStyle(
              //           color: Colors.white,
              //           fontWeight: FontWeight.bold,
              //           fontSize: 12,
              //         ),
              //       ),
              //     ),
              //   ),
              // ),
            ],
          );
  }
}

import 'package:fashion/screens/detail/product_description.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiver/strings.dart';
import 'package:fashion/screens/detail/review.dart';
import '../../common/config.dart';
import '../../common/constants.dart';
import '../../common/tools.dart';
import '../../generated/l10n.dart';
import 'package:flutter_svg/avd.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:fashion/caco/serv/get_product.dart';
import '../../models/index.dart'
    show AppModel, Product, ProductModel, ProductVariation;
import '../../screens/base.dart';
import '../../widgets/common/countdown_timer.dart';
import '../../widgets/common/sale_progress_bar.dart';
import 'package:fashion/widgets/product/heart_button.dart';
import '../../widgets/common/start_rating.dart';

class ProductTitle extends StatefulWidget {
  final Product product;

  ProductTitle(this.product);

  @override
  _ProductTitleState createState() => _ProductTitleState();
}

class _ProductTitleState extends BaseScreen<ProductTitle> {
  var regularPrice;
  var onSale = false;
  int sale = 100;
  String price;
  ProductVariation productVariation;
  String dateOnSaleTo;

  @override
  void afterFirstLayout(BuildContext context) async {
    getProductPrice();
  }

  getProductPrice() {
    try {
      regularPrice = productVariation != null
          ? productVariation.regularPrice
          : widget.product.regularPrice;
      onSale = productVariation != null
          ? productVariation.onSale
          : widget.product.onSale;
      setState(() {
        print("aaa");
        price = productVariation != null
            ? productVariation.price
            : isNotBlank(widget.product.price)
            ? widget.product.price
            : widget.product.regularPrice;
      });


      /// update the Sale price
      if (onSale) {
        price = productVariation != null
            ? productVariation.salePrice
            : isNotBlank(widget.product.salePrice)
                ? widget.product.salePrice
                : widget.product.price;
        dateOnSaleTo = productVariation != null
            ? productVariation.dateOnSaleTo
            : widget.product.dateOnSaleTo;
      }

      if (onSale && regularPrice.isNotEmpty && double.parse(regularPrice) > 0) {
        sale = (100 - (double.parse(price) / double.parse(regularPrice)) * 100)
            .toInt();
      }
      setState(() {

      });
    } catch (e, trace) {
      printLog(trace);
      printLog(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    getProductPrice();
    final ThemeData theme = Theme.of(context);

    productVariation = Provider.of<ProductModel>(context).productVariation;
    getProductPrice();
setState(() {

});
    final String currency = Provider.of<AppModel>(context).currency;
    final Map<String, dynamic> currencyRate =
        Provider.of<AppModel>(context).currencyRate;
    final int dateOnSaleTo = DateTime.tryParse(
            productVariation?.dateOnSaleTo ?? widget.product.dateOnSaleTo ?? "")
        ?.millisecondsSinceEpoch;
    final int countDown =
        (dateOnSaleTo ?? 0) - DateTime.now().millisecondsSinceEpoch;
    bool inStock = (productVariation != null
            ? productVariation.inStock
            : widget.product.inStock) ??
        false;
    String stockQuantity = widget.product.stockQuantity != null
        ? ' (${widget.product.stockQuantity}) '
        : '';
    if (Provider.of<ProductModel>(context, listen: false).productVariation !=
        null) {
      stockQuantity = Provider.of<ProductModel>(context, listen: false)
                  .productVariation
                  .stockQuantity !=
              null
          ? ' (${Provider.of<ProductModel>(context, listen: false).productVariation.stockQuantity}) '
          : '';
    }

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        SizedBox(
          height: 20,
        ),


        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Text(
                widget.product.name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 19,
                ),
              ),


            ],
          ),
        ),
        SizedBox(height: 10,),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                SizedBox(width:5,),
                Text(
                  price??"0.0",
                  style: Theme.of(context).textTheme.headline5.copyWith(
                      fontWeight: FontWeight.w600,
                      fontSize: 17
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 2),
                  child: Text(
                    S.of(context).currency,
                    style: Theme.of(context).textTheme.headline5.copyWith(
                        fontWeight: FontWeight.w600,

                        fontSize: 17
                    ),
                  ),
                ),
              ],
            ),

            // SingleChildScrollView(
            //   child: Row(
            //     crossAxisAlignment: CrossAxisAlignment.center,
            //     mainAxisAlignment: MainAxisAlignment.center,
            //     children: [
            //
            //       ProductDescription(widget.product),
            //     ],
            //   ),
            // ),

            Text(
              S.of(context).discount + " $sale %" ,
              style: Theme.of(context).textTheme.subtitle2.copyWith(
                color:Color(0xff4f3933),
                fontSize: 12,
                fontWeight: FontWeight.w400,
              ),
            ),
          ],
        ),
//         widget.product.name .contains("اصنع توليفتك")?SizedBox():
//         Row(
//           crossAxisAlignment: CrossAxisAlignment.center,
//            mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//
//             SizedBox(width:5,),
//             Text(
//               price??"0.0",
//               style: Theme.of(context).textTheme.headline5.copyWith(
//                 fontWeight: FontWeight.w600,
//                 fontSize: 17
//               ),
//             ),
//             Padding(
//               padding: const EdgeInsets.only(bottom: 2),
//               child: Text(
//                 " جنية ",
//                 style: Theme.of(context).textTheme.headline5.copyWith(
//                     fontWeight: FontWeight.w600,
//
//                     fontSize: 17
//                 ),
//               ),
//             ),
//           ],
//         ), widget.product.name .contains("اصنع توليفتك")?SizedBox():  Row(
//           crossAxisAlignment: CrossAxisAlignment.center,
//            mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//
// //             SizedBox(width:5,),
// //             Text(
// //               regularPrice??"0.0",
// //               style: Theme.of(context).textTheme.headline5.copyWith(
// //                 fontWeight: FontWeight.w600,
// //                 color: Color(0xff4f3933),
// //                   decoration: TextDecoration.lineThrough,
// //                 fontSize: 14
// //               ),
// //             ),
// //             Padding(
// //               padding: const EdgeInsets.only(bottom: 2),
// //               child: Text(
// //                 "جنية",
// //                 style: Theme.of(context).textTheme.headline5.copyWith(
// //                     fontWeight: FontWeight.w600,
// //                     decoration: TextDecoration.lineThrough,
// //
// // color: Color(0xff4f3933),
// //                     fontSize: 12
// //                 ),
// //               ),
// //             ),
// //             SizedBox(width:3,),
//             Container(
//               padding: const EdgeInsets.symmetric(
//                 horizontal: 2,
//                 vertical: 2,
//               ),
//               // decoration: BoxDecoration(
//               // borderRadius:
//               // BorderRadius
//               //     .circular(2),
//               //     border: Border.all(width: 0.5, color: Color(0xff4f3933))),
//               child: Center(
//                 child:
//               ),
//             ),
//           ],
//         ),

        //
        // SizedBox(
        //   height: 5,
        // ),

        // const SizedBox(height: 10),


        // const SizedBox(height: 10),
        // Row(
        //   crossAxisAlignment: CrossAxisAlignment.baseline,
        //   children: [
        //     if (kAdvanceConfig['EnableRating'])
        //       Padding(
        //         padding: const EdgeInsets.only(top: 5.0),
        //         child: SmoothStarRating(
        //           allowHalfRating: true,
        //           starCount: 5,
        //           spacing: 0.0,
        //           rating: widget.product.averageRating,
        //           size: 17.0,
        //           label: Text(
        //             " (${widget.product.ratingCount})",
        //             style: Theme.of(context).textTheme.subtitle1.copyWith(
        //                   fontSize: 12,
        //                   color: Theme.of(context).accentColor.withOpacity(0.8),
        //                 ),
        //           ),
        //         ),
        //       ),
        //     const Spacer(),
        //     if (dateOnSaleTo != null && countDown > 0)
        //       Padding(
        //         padding: const EdgeInsets.only(left: 8.0),
        //         child: SaleProgressBar(
        //           product: widget.product,
        //           productVariation: productVariation,
        //           width: 160,
        //         ),
        //       ),
        //   ],
        // ),
      ],
    );
  }
}

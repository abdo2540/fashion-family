import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:timeago/timeago.dart' as timeago;

import '../../common/config.dart';
import '../../common/constants.dart';
import '../../common/tools.dart';
import '../../generated/l10n.dart';
import '../../models/index.dart' show Review, UserModel;
import '../../services/index.dart';
import '../../widgets/common/start_rating.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shimmer/shimmer.dart';

class Reviews extends StatefulWidget {
  final String productId;

  Reviews(this.productId);

  @override
  _StateReviews createState() => _StateReviews(productId);
}

class _StateReviews extends State<Reviews> {
  final services = Services();
  double rating = 0.0;
  final comment = TextEditingController();
  List<Review> reviews;
  final String productId;

  _StateReviews(this.productId);

  @override
  void initState() {
    super.initState();
    getListReviews();
  }

  @override
  void dispose() {
    comment.dispose();
    super.dispose();
  }

  void updateRating(double index) {
    setState(() {
      rating = index;
    });
  }

  void sendReview() {
    if (rating == 0.0) {
      Tools.showSnackBar(
          Scaffold.of(context), S.of(context).ratingFirst, context);
      return;
    }
    if (comment.text == null || comment.text.isEmpty) {
      Tools.showSnackBar(
          Scaffold.of(context), S.of(context).commentFirst, context);
      return;
    }
    final user = Provider.of<UserModel>(context, listen: false);
    Navigator.pop(context);
    Tools.showSnackBar(
        Scaffold.of(context), S.of(context).waitForLoad, context);

    services.createReview(productId: productId, data: {
      "review": comment.text,
      "reviewer": user.user.name,
      "reviewer_email": user.user.email,
      "rating": rating,
      "status":
          kAdvanceConfig["EnableApprovedReview"] == true ? "approved" : "hold"
    }).then((onValue) {
      getListReviews();
      setState(() {
        rating = 0.0;
        comment.text = "";
      });
      Tools.showSnackBar(Scaffold.of(context), S.of(context).ok, context);
    });
  }

  void getListReviews() {
    services.getReviews(productId).then((onValue) {
      setState(() {
        reviews = onValue;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    bool isLoggedIn = Provider.of<UserModel>(context).loggedIn;
    OutlineInputBorder outlineInputBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(20),
      borderSide: BorderSide(color: Theme.of(context).primaryColor),
      gapPadding: 10,
    );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Row(
                  children: [
                     Text(
                      S.of(context).productRating,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                  ],
                ),
              ),
              InkWell(
                onTap: () {
                  showDialog(
                    barrierDismissible: false,
                    context: context,
                    builder: (contextx) {
                      return rateDialo(contextx, context);
                    },
                  );
                },
                child: Container(
                  height: 30,
                  width: 60,

                  decoration: BoxDecoration(
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.1),
                          spreadRadius: 5,
                          blurRadius: 7,
                          offset: Offset(0, 3), // changes position of shadow
                        ),
                      ],
                      borderRadius:
                      BorderRadius
                          .circular(7)),
                  child: Center(
                    child: Text(
                      S.of(context).rate,
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: Color(0xff4f3933)),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        reviews == null
            ? Container(
                height: 80,
                child: Shimmer.fromColors(
                  period: Duration(milliseconds: 800),
                  baseColor: Colors.grey.withOpacity(0.5),
                  highlightColor: Colors.black.withOpacity(0.5),
                  child: Container(
                    margin: const EdgeInsets.all(8.0),
                    height: 150.0,
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                  ),
                ),
              )
            : (reviews.isEmpty
                ? Container(
                    height: 80,
                    child: Center(
                      child: Text(S.of(context).noReviews),
                    ),
                  )
                : Column(
                    children: [
                      Column(
                        children: <Widget>[
                          for (var i = 0; i < reviews.length; i++)
                            renderItem(context, reviews[i]),
                        ],
                      ),
                    ],
                  )),
        const SizedBox(height: 20),
        // Text(
        //   S.of(context).productRating,
        //   style: const TextStyle(
        //       fontSize: 20, fontWeight: FontWeight.w600),
        // ),
        // if (isLoggedIn)
        //   Row(
        //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //     children: <Widget>[
        //       // Expanded(
        //       //   child:Text(
        //       //     S.of(context).productRating,
        //       //     style: const TextStyle(
        //       //         fontSize: 20, fontWeight: FontWeight.w600),
        //       //   ),
        //       // ),
        //
        //         Flexible(
        //           child: Container(
        //             child: Align(
        //               alignment: Alignment.bottomRight,
        //               child: SmoothStarRating(
        //                 label: const Text(''),
        //                 allowHalfRating: true,
        //                 onRatingChanged: updateRating,
        //                 starCount: 5,
        //                 rating: rating,
        //                 size: 28.0,
        //                 color: Colors.amber,
        //                 borderColor: Colors.amber,
        //                 spacing: 0.0,
        //               ),
        //             ),
        //           ),
        //         ),
        //     ],
        //   ),
        // if (isLoggedIn)
        //
        //   Container(
        //      margin: const EdgeInsets.symmetric(vertical: 10,horizontal: 10),
        //     padding: const EdgeInsets.symmetric(vertical: 10,horizontal: 10),
        //     decoration: BoxDecoration(
        //       color: Theme.of(context).backgroundColor,
        //       borderRadius: BorderRadius.circular(20.0),
        //     ),
        //     child: Row(
        //       crossAxisAlignment: CrossAxisAlignment.end,
        //       children: <Widget>[
        //         Expanded(
        //           child: TextField(
        //
        //             controller: comment,
        //             maxLines: 3,
        //             minLines: 1,
        //             decoration:
        //             InputDecoration(
        //                 labelStyle: GoogleFonts.tajawal(  color: Theme.of(context).primaryColor.withOpacity(.4)),
        //                 labelText: S.of(context).writeComment,
        //                 enabledBorder: outlineInputBorder,
        //                 focusedBorder: outlineInputBorder,
        //                 border: outlineInputBorder,
        //                 //hintStyle: TextStyle(color: _enable ? Colors.grey : Colors.black),
        //                 contentPadding: const EdgeInsets.symmetric(
        //                     vertical: 20, horizontal: 15)),
        //           ),
        //         ),
        //         GestureDetector(
        //           child: Padding(
        //             padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 20),
        //             child: Icon(
        //               Icons.send_outlined,
        //               color: Theme.of(context).primaryColor,
        //             ),
        //           ),
        //           onTap: sendReview,
        //         )
        //       ],
        //     ),
        //   )
      ],
    );
  }

  Widget renderItem(context, Review review) {
    final ThemeData theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
      child: Container(
     decoration: BoxDecoration(
         color: Colors.white,
         boxShadow: [
           BoxShadow(
             color: Colors.grey.withOpacity(0.1),
             spreadRadius: 5,
             blurRadius: 7,
             offset: Offset(0, 3), // changes position of shadow
           ),
         ],
         borderRadius:
         BorderRadius
             .circular(7)),
        child: Container(
          decoration: BoxDecoration(
              // color: Colors.white.withOpacity(.3),
              borderRadius: BorderRadius.circular(20.0)),
          margin: const EdgeInsets.only(bottom: 10.0),
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text(review.name,
                        style: const TextStyle(
                            fontSize: 15, fontWeight: FontWeight.bold)),
                    SmoothStarRating(
                        label:  Text('',

                        ),
                        allowHalfRating: true,
                        starCount: 5,
                        rating: review.rating,
                        size: 12.0,
                        color: Colors.amber,
                        borderColor: Colors.amber,
                        spacing: 0.0),
                  ],
                ),
                const SizedBox(height: 10),
                Text(review.review, style: const TextStyle(fontSize: 14)),
                const SizedBox(height: 12),
                Text(timeago.format(review.createdAt),
                    style: const TextStyle(color: Color(0xff4f3933), fontSize: 14)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  rateDialo(context, contextpar) {
    Size size = MediaQuery.of(context).size;
    return StatefulBuilder(
      builder: (BuildContext context, setStates) => AlertDialog(
        scrollable: true,
        backgroundColor: Theme.of(context).backgroundColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(15.0),
          ),
        ),
        elevation: 5.0,
        contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                height: 10.0,
              ),
              Center(
                child: Text(
                  S.of(context).rate,
                  style: GoogleFonts.tajawal(
                    // color: Colors.black87,
                    fontSize: 15.0,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.3,
                  ),
                ),
              ),
              SizedBox(
                height: 25.0,
              ),
              // Flexible(

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SmoothStarRating(
                    label: const Text(''),
                    allowHalfRating: true,
                    onRatingChanged: (v) {
                      setStates(() {
                        rating = v;
                      });
                    },
                    starCount: 5,
                    rating: rating,
                    size: 28.0,
                    color: Colors.amber,
                    borderColor: Colors.amber,
                    spacing: 0.0,
                  ),
                ],
              ),
              SizedBox(
                height: 25.0,
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10.0, vertical: 10.0),
                decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(.2),
                  borderRadius: BorderRadius.circular(15.0),
                ),
                child: TextFormField(
                  controller: comment,
                  keyboardType: TextInputType.text,
                  textCapitalization: TextCapitalization.sentences,
                  textInputAction: TextInputAction.done,
                  enableInteractiveSelection: false,
                  maxLines: 5,
                  maxLength: 250,
                  style: GoogleFonts.tajawal(
                    fontSize: 14.0,
                    // color: Colors.black87,
                    letterSpacing: 0.5,
                    fontWeight: FontWeight.w500,
                  ),
                  decoration: InputDecoration(
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 5.0, vertical: 8.0),
                    border: InputBorder.none,
                    hintText: '${S.of(context).writeComment}',
                    hintStyle: GoogleFonts.tajawal(
                      fontSize: 14.0,
                      // color: Colors.black54,
                      letterSpacing: 0.5,
                      fontWeight: FontWeight.w400,
                    ),
                    counterStyle: GoogleFonts.cairo(
                      fontSize: 12.5,
                      // color: Colors.black54,
                      letterSpacing: 0.5,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 15.0,
              ),
              Center(
                child: SizedBox(
                  width: size.width * 0.5,
                  child: FlatButton(
                    onPressed: () {
                      if (rating == 0.0) {
                        Tools.showSnackBar(Scaffold.of(contextpar),
                            S.of(contextpar).ratingFirst, contextpar);
                        return;
                      }
                      if (comment.text == null || comment.text.isEmpty) {
                        Tools.showSnackBar(Scaffold.of(contextpar),
                            S.of(contextpar).commentFirst, contextpar);
                        return;
                      }
                      final user =
                          Provider.of<UserModel>(contextpar, listen: false);
                      Navigator.pop(context);
                      Tools.showSnackBar(Scaffold.of(contextpar),
                          S.of(contextpar).loading, contextpar);

                      services.createReview(productId: productId, data: {
                        "review": comment.text,
                        "reviewer": user.user.name,
                        "reviewer_email": user.user.email,
                        "rating": rating,
                        "status": kAdvanceConfig["EnableApprovedReview"] == true
                            ? "approved"
                            : "hold"
                      }).then((onValue) {
                        getListReviews();
                        setStates(() {
                          rating = 0.0;
                          comment.text = "";
                        });
                        Tools.showSnackBar(Scaffold.of(contextpar),
                            S.of(contextpar).ok, contextpar);
                      });
                    },
                    color: Theme.of(context).primaryColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Text(
                      S.of(context).rate,
                      style: GoogleFonts.tajawal(
                        color: Colors.white,
                        fontSize: 14.5,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ),
                ),
              ),
              Center(
                child: SizedBox(
                  width: size.width * 0.5,
                  child: FlatButton(
                    onPressed: () {
                      Navigator.pop(context);
                      setStates(() {
                        rating = 0.0;
                        comment.text = "";
                      });
                    },
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Text(
                      "${S.of(context).cancel}",
                      style: GoogleFonts.tajawal(
                        color: Colors.red,
                        fontSize: 14.5,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'dart:collection';
import 'dart:io';
import 'package:appsflyer_sdk/appsflyer_sdk.dart';
import 'package:expandable/expandable.dart';

import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:provider/provider.dart';
import 'package:fashion/screens/cart/cart.dart';
import 'package:shimmer/shimmer.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../common/config.dart';
import '../../../common/constants.dart';
import '../../../common/index.dart';
import '../../../models/index.dart'
    show Ads, AppModel, CartModel, Product, ProductModel, ProductVariation;
// import '../../../modules/booking/booking.dart';
import '../../../screens/detail/product_grouped.dart';
import '../../../services/index.dart';
import '../../../share.dart';
import '../../../widgets/common/image_galery.dart';
import '../../../widgets/product/heart_button.dart';
import 'package:fashion/screens/cart/my_cart.dart';
import 'package:fashion/screens/detail/review.dart';
import 'package:fashion/caco/size_config.dart';
import 'package:fashion/caco/components/default_button.dart';
import '../image_feature.dart';
import '../index.dart';
import '../listing_booking.dart';
import '../product_description.dart';
import '../product_gallery.dart';
import '../product_title.dart';
import '../product_variant.dart';
import '../related_product.dart';
import '../variant_image_feature.dart';
import '../video_feature.dart';
import 'package:flash/flash.dart';
import 'package:flutter_swiper/src/swiper.dart';
import 'package:sizer/sizer.dart';
import 'package:share/share.dart';
import 'package:fashion/generated/l10n.dart';
import 'package:flutter_styled_toast/src/styled_toast.dart';
import 'package:flutter_styled_toast/src/styled_toast_enum.dart';
import 'package:flutter_swiper/src/swiper_pagination.dart';
import 'package:flutter_svg/svg.dart';
import 'package:carousel_pro/src/carousel_pro.dart';

class SimpleLayout extends StatefulWidget {
  final Product product;

  SimpleLayout({this.product});

  @override
  _SimpleLayoutState createState() => _SimpleLayoutState(product: product);
}

class _SimpleLayoutState extends State<SimpleLayout>
    with SingleTickerProviderStateMixin {
  final _scrollController = ScrollController();

  final services = Services();
  Product product;
  bool _expanded;
  bool isExpanded;

  String selectedUrl;
  bool isVideoSelected = false;
  ExpandableController controller;

  _SimpleLayoutState({this.product});

  Map<String, String> mapAttribute = HashMap();
  AnimationController _hideController;

  var top = 0.0;
  ScrollController scrollController;
  @override
  void initState() {
    super.initState();

    // if (kAdConfig['enable']) Ads().adInit();

    // _hideController = AnimationController(
    //   vsync: this,
    //   duration: const Duration(milliseconds: 450),
    //   value: 1.0,
    // );
  }

  @override
  void dispose() {
    if (kAdConfig['enable']) {
      Ads.hideBanner();
      Ads.hideInterstitialAd();
    }
    super.dispose();
  }

  /// Render product default: booking, group, variant, simple, booking
  renderProductInfo() {
    var body;

    /// enable the woocommerce booking
    // if (product.type == 'appointment') {
    //   ProductBooking(product: product);
    // }

    /// enable the listing booking
    if (product.type == 'booking') {
      body = ListingBooking(product);
    } else if (product.type != 'grouped') {
      body = ProductVariant(product);
    } else {
      body = GroupedProduct(product);
    }

    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15.0),
        child: body,
      ),
    );
  }

  var open = false;
  int h = 2;
  @override
  Widget build(BuildContext context) {
    bool _expanded = false;
    final Size size = MediaQuery.of(context).size;
    final double widthHeight = size.height;
    var totalCart = Provider.of<CartModel>(context).totalCartQuantity;
    ProductVariation productVariation;
    productVariation = Provider.of<ProductModel>(context).productVariation;
    final imageFeature = productVariation != null
        ? productVariation.imageFeature
        : product.imageFeature;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                elevation: 0,
                child: Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    // border: Border.all(color: Theme.of(context).primaryColor, width: 1)
                  ),
                  child: Icon(
                    Icons.arrow_back_ios,
                    color: Theme.of(context).primaryColor,
                    size: 20,
                  ),
                ),
              ),
            ),
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              elevation: 0,
              child: Container(
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  // border: Border.all(color: Theme.of(context).primaryColor, width: 1)
                ),
                child: HeartButton(
                  product: product,
                  size: 18.0,
                ),
              ),
            ),
          ],
        ),
        // leading: InkWell(
        //   onTap: (){
        //     Navigator.pop(context);
        //   },
        //   child: Card(
        //     child: Container(
        //       height: 30,
        //       width: 30,
        //       decoration:
        //       BoxDecoration(borderRadius: BorderRadius.circular(15)),
        //       child: Center(
        //         child: Icon(
        //           Icons.arrow_back_ios, color: Colors.black,size: 20,
        //         ),
        //       ),
        //     ),
        //   ),
        // ),
        // backgroundColor: Colors.grey.shade300,
        // actions: [
        //   Card(
        //     child: Container(
        //       height: 30,
        //       width: 30,
        //       decoration:
        //           BoxDecoration(borderRadius: BorderRadius.circular(15)),
        //       child: HeartButton(
        //         product: product,
        //         size: 18.0,
        //       ),
        //     ),
        //   ),
        // ],
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Container(
          // color: Colors.grey.shade200,
          child: SafeArea(
            bottom: false,
            top: false,
            child: ChangeNotifierProvider(
              create: (_) => ProductModel(),
              child: Container(
                width: double.infinity,
                height: open == true
                    ? MediaQuery.of(context).size.height * 1.80
                    : MediaQuery.of(context).size.height * 1.70,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(30),
                        topRight: Radius.circular(30))),
                child: Column(
                  children: [
                    SizedBox(
                      height: 20,
                    ),

                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: SizedBox(
                          width: double.infinity,
                          height: MediaQuery.of(context).size.height * .42,
                          child: _renderSelectedMedia(context, product, size)
                          // Carousel(
                          //   onImageTap: (int) {
                          //     showDialog<void>(
                          //         context: context,
                          //         builder: (BuildContext context) {
                          //           // final int index = product.images.indexOf(selectedUrl);
                          //           return ImageGalery(
                          //             images: product.images,
                          //             index: int == -1 ? 0 : int,
                          //           );
                          //         });
                          //   },
                          //   images: [
                          //
                          //     Image.network(
                          //       _renderSelectedMedia(
                          //           context, product, size),
                          //       fit: BoxFit.cover,
                          //     ),
                          //
                          //   ],
                          //   autoplay: true,
                          //   dotSize: 5.0,
                          //   dotSpacing: 10.0,
                          //   dotColor: Color(0xffffd900),
                          //   dotIncreasedColor:
                          //   Theme.of(context).primaryColor.withOpacity(0.9),
                          //   indicatorBgPadding: 5.0,
                          //   dotBgColor: Colors.transparent,
                          //   borderRadius: true,
                          //   dotPosition: DotPosition.bottomCenter,
                          //   dotVerticalPadding: 10,
                          //   boxFit: BoxFit.contain,
                          // ),
                          ),
                    ),

                    // Padding(
                    //   padding: const EdgeInsets.all(8.0),
                    //   child: Container(
                    //     width: 90,
                    //     height: 10,
                    //     decoration: BoxDecoration(
                    //       color: Colors.black.withOpacity(.1),
                    //       borderRadius:
                    //           BorderRadius.circular(20),
                    //     ),
                    //     child: Row(
                    //       children: [],
                    //     ),
                    //   ),
                    // ),
                    Expanded(
                      child: ListView(
                        physics: NeverScrollableScrollPhysics(),
                        controller: scrollController,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 10),
                                child: ProductTitle(product),
                              ),
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 15, vertical: 0),
                                child: ProductVariant(product),
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              // Padding(
                              //   padding: const EdgeInsets.symmetric(
                              //       horizontal: 20),
                              //   child: ProductDescription(product),
                              // ),
                              Card(
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(15)),
                                elevation: 5,
                                child: Container(
                                    child: ExpansionTile(
                                      initiallyExpanded: true,
                                      onExpansionChanged: (val) {
                                        setState(() {
                                          if (open == false) {
                                            open = true;
                                          } else {
                                            open = false;
                                          }
                                        });
                                      },
                                  title: Text(
                                    S.of(context).productDescription,
                                    style: TextStyle(
                                        color: Theme.of(context).primaryColor,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 18),
                                  ),
                                  children: <Widget>[
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: ProductDescription(product),
                                    ),
                                  ],
                                )),
                              ),
                              Card(
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(15)),
                                elevation: 5,
                                child: Container(
                                    child: ExpansionTile(
                                  onExpansionChanged: (val) {
                                    setState(() {
                                      if (open == false) {
                                        open = true;
                                      } else {
                                        open = false;
                                      }
                                    });
                                  },
                                  title: Text(
                                    S.of(context).productRating,
                                    style: TextStyle(
                                        color: Theme.of(context).primaryColor,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 18),
                                  ),
                                  children: <Widget>[
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Reviews(product.id),
                                    ),
                                  ],
                                )),
                              ),
                              // Card(
                              //   shape: RoundedRectangleBorder(
                              //       borderRadius: BorderRadius.circular(15)),
                              //   elevation: 5,
                              //   child: Container(
                              //       child: ExpansionTile(
                              //         onExpansionChanged: (val) {
                              //           setState(() {
                              //             if (open == false) {
                              //               open = true;
                              //             } else {
                              //               open = false;
                              //             }
                              //           });
                              //         },
                              //     title: Text(
                              //       S.of(context).aboutBrand,
                              //       style: TextStyle(
                              //           color: Theme.of(context).primaryColor,
                              //           fontWeight: FontWeight.w600,
                              //           fontSize: 18),
                              //     ),
                              //     children: <Widget>[
                              //       Padding(
                              //         padding: const EdgeInsets.all(8.0),
                              //         child: Shimmer.fromColors(
                              //           highlightColor: Colors.white,
                              //           baseColor: Theme.of(context).primaryColor,
                              //           child: Text(
                              //               S.of(context).createdBy,
                              //           style: TextStyle(color: Colors.black),
                              //           ),
                              //         ),
                              //       ),
                              //     ],
                              //   )),
                              // ),
                              Container(child: RelatedProduct(product)),
                            ],
                          ),
                          open == true
                              ? SizedBox(
                                  height: 80,
                                )
                              : SizedBox()
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
      floatingActionButton: Padding(
        padding: Platform.isIOS ?  EdgeInsets.only(bottom:20) : EdgeInsets.only(bottom:20),
        child: SpeedDial(
          foregroundColor: Theme.of(context).primaryColor,
          backgroundColor: Colors.white,
          icon: Icons.phone_rounded,
          activeIcon: Icons.dangerous,
          children: [
            SpeedDialChild(
                backgroundColor: Colors.transparent,
                child: SvgPicture.asset('assets/icons/phonee.svg'),
                label: 'اتصل بنا',
                onTap: (){ShareFunction().launchCaller();}),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/whatsapp.svg'),
                label: 'واتساب',
                onTap: (){ShareFunction().launchWhatApp();}),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/messenger.svg'),
                label: 'ماسنجر',
                onTap: (){ShareFunction().launchMessanger();}),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/ig.svg'),
                label: 'انستجرام',
                onTap: () {
                  ShareFunction().launchInstagram();
                }
            ),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/tiktok.svg'),
                label: 'تيك توك',
                onTap: () {
                  ShareFunction().launchTiktok();
                }
            ),
            SpeedDialChild(
                backgroundColor: Colors.transparent,

                child: SvgPicture.asset('assets/icons/facebook.svg'),
                label: 'صفحة الفيس بوك',
                onTap: () {
                  ShareFunction().launchFacebook();
                }
            ),

          ],
        ),
      ),

    );
  }


  _renderSelectedMedia(BuildContext context, Product product, Size size) {
    /// Render selected image
    if (selectedUrl != null && !isVideoSelected) {
      return GestureDetector(
        // onTap: () {
        //   showDialog<void>(
        //       context: context,
        //       builder: (BuildContext context) {
        //         print("${product.images.indexOf(selectedUrl)}");
        //         final int index = product.images.indexOf(selectedUrl);
        //         return ImageGalery(
        //           images: product.images,
        //           index: index == -1 ? 0 : index,
        //         );
        //       });
        // },
        child: Swiper(
          duration: 5,
          itemCount: product.images.length,
          itemBuilder: (BuildContext context, int indx) {
            return ClipRRect(
              borderRadius: BorderRadius.circular(30),
              child: Tools.image(
                url: product.images[indx],
                fit: BoxFit.cover,
                width: size.width,
                size: kSize.large,
                hidePlaceHolder: true,
              ),
              // child: FadeInImage.assetNetwork(
              //     placeholder: 'assets/icons/Camera.png',
              //     image: product.images[indx],
              //     fit: BoxFit.cover,
              // ),
            );
          },
          scale: .9,

          scrollDirection: Axis.vertical,
          autoplay: true,
          pagination: SwiperPagination(
              alignment: Alignment.center,
              builder: DotSwiperPaginationBuilder(
                  color: Colors.grey, activeColor: Colors.black)),
          // child:
        ),
      );
    }

    /// Render default feature image
    return product.type == 'variable'
        ? VariantImageFeature(product)
        : ImageFeature(product);
  }

  void addToCart(BuildContext context, Product product, int quantity,
      ProductVariation productVariation, Map<String, String> mapAttribute,
      [bool buyNow = false, bool inStock = false]) {
    if (!inStock) {
      return;
    }

    final cartModel = Provider.of<CartModel>(context, listen: false);
    if (product.type == "external") {
      // openWebView(context, product);
      return;
    }

    final Map<String, String> _mapAttribute = Map.from(mapAttribute);
    productVariation =
        Provider.of<ProductModel>(context, listen: false).productVariation;
    String message = cartModel.addProductToCart(
        context: context,
        product: product,
        quantity: quantity,
        variation: productVariation,
        options: _mapAttribute);

    if (message.isNotEmpty) {
      showToast('$message',
          context: context,
          animation: StyledToastAnimation.slideFromTopFade,
          reverseAnimation: StyledToastAnimation.slideToTopFade,
          backgroundColor: Theme.of(context).primaryColor,
          position:
              StyledToastPosition(align: Alignment.topCenter, offset: 6.0),
          startOffset: Offset(0.0, 2),
          reverseEndOffset: Offset(0.0, 2),
          duration: Duration(seconds: 2),
          //Animation duration   animDuration * 2 <= duration
          animDuration: Duration(milliseconds: 500),
          curve: Curves.fastLinearToSlowEaseIn,
          reverseCurve: Curves.fastOutSlowIn);
      // showFlash(
      //   context: context,
      //   duration: const Duration(seconds: 3),
      //   builder: (context, controller) {
      //     return Flash(
      //       borderRadius: BorderRadius.circular(3.0),
      //       backgroundColor: Theme.of(context).errorColor,
      //       controller: controller,
      //       style: FlashStyle.floating,
      //       position: FlashPosition.top,
      //       horizontalDismissDirection: HorizontalDismissDirection.horizontal,
      //       child: FlashBar(
      //         icon: const Icon(
      //           Icons.check,
      //           color: Colors.white,
      //         ),
      //         message: Text(
      //           message,
      //           style: const TextStyle(
      //             color: Colors.white,
      //             fontSize: 18.0,
      //             fontWeight: FontWeight.w700,
      //           ),
      //         ),
      //       ),
      //     );
      //   },
      // );
    } else {
      if (buyNow) {
        Navigator.push(
          context,
          MaterialPageRoute<void>(
            builder: (BuildContext context) => Scaffold(
              backgroundColor: Theme.of(context).backgroundColor,
              body: CartScreen(isModal: true, isBuyNow: true),
            ),
            fullscreenDialog: true,
          ),
        );
      }
      showToast('${S.of(context).addToCartSucessfully}' + "${product.name}",
          context: context,
          animation: StyledToastAnimation.slideFromTopFade,
          reverseAnimation: StyledToastAnimation.slideToTopFade,
          backgroundColor: Theme.of(context).primaryColor,
          position:
              StyledToastPosition(align: Alignment.topCenter, offset: 6.0),
          startOffset: Offset(0.0, 2),
          reverseEndOffset: Offset(0.0, 2),
          duration: Duration(seconds: 2),
          //Animation duration   animDuration * 2 <= duration
          animDuration: Duration(milliseconds: 500),
          curve: Curves.fastLinearToSlowEaseIn,
          reverseCurve: Curves.fastOutSlowIn
          // showFlash(
          //   context: context,
          //   duration: const Duration(seconds: 3),
          //   builder: (context, controller) {
          //     return Flash(
          //       borderRadius: BorderRadius.circular(3.0),
          //       backgroundColor: Theme.of(context).primaryColor,
          //       controller: controller,
          //       style: FlashStyle.floating,
          //       position: FlashPosition.top,
          //       horizontalDismissDirection: HorizontalDismissDirection.horizontal,
          //       child: FlashBar(
          //         icon: const Icon(
          //           Icons.check,
          //           color: Colors.white,
          //         ),
          //         title: Text(
          //           product.name,
          //           style: const TextStyle(
          //             color: Colors.white,
          //             fontWeight: FontWeight.w700,
          //             fontSize: 15.0,
          //           ),
          //         ),
          //         message: Text(
          //           S.of(context).addToCartSucessfully,
          //           style: const TextStyle(
          //             color: Colors.white,
          //             fontSize: 15.0,
          //           ),
          //         ),
          //       ),
          //     );

          );
    }
  }
}

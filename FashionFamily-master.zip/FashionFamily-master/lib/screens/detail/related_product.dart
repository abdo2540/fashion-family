import 'package:async/async.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fashion/caco/home/components/home_featured_list_item.dart';
import '../../common/constants.dart';
import '../../generated/l10n.dart';
import '../../models/index.dart' show AppModel, Product;
import '../../services/index.dart';
import '../../widgets/product/product_card_view.dart';
import 'package:fashion/caco/shimmer_product_list_item.dart';
import 'package:shimmer/shimmer.dart';
import 'package:fashion/customCard.dart';
import 'package:flutter_svg/svg.dart';

class RelatedProduct extends StatelessWidget {
  final Product product;

  RelatedProduct(this.product);

  final _memoizer = AsyncMemoizer<List<Product>>();
  final services = Services();

  @override
  Widget build(BuildContext context) {
    Future<List<Product>> getRelativeProducts() => _memoizer.runOnce(() {
          return services.fetchProductsByCategory(
              categoryId: product.categoryId,
              lang: Provider.of<AppModel>(context).langCode);
        });

    return LayoutBuilder(
      builder: (context, constraint) {
        return FutureBuilder<List<Product>>(
          future: getRelativeProducts(),
          builder:
              (BuildContext context, AsyncSnapshot<List<Product>> snapshot) {
            // print(product.featured);
            if (!snapshot.hasData)
              return Container(
                height: 150,
                child: ListView.builder(
                  itemCount: 3,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) => Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Shimmer.fromColors(
                        period: Duration(milliseconds: 300),
                        baseColor: Theme.of(context).primaryColor,
                        highlightColor: Colors.white,
                        child: Container(
                            width: 150.0,
                            height: 120,
                            child: ShimmerProductListItem()
                        )
                    ),
                  ),
                ),
              );

            if (snapshot.hasError) {
              return Container(
                height: 100,
                child: Center(
                  child: Text(
                    S.of(context).error(snapshot.error),
                    style: TextStyle(color: Theme.of(context).accentColor),
                  ),
                ),
              );
            } else if (snapshot.data.isEmpty) {
              return Container();
            } else {
              return Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(
                      height: 10,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10.0, horizontal: 5),
                      child: Text(
                        S.of(context).youMightAlsoLike,
                        style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.black),
                      ),
                    ),
                    Container(
                        height: 250,
                        // width: 500,
                        child: ListView(
                          shrinkWrap: true,
                          scrollDirection: Axis.horizontal,
                          children: [
                            for (var item in snapshot.data)
                              if (item.id != product.id)
                                Container(
                                  child: custoCard(
                                    product: item,
                                  ),
                                ),

                            // ProductCard(
                            //     item: item,
                            //     width: constraint.maxWidth * 0.35)
                          ],
                        ))
                  ],
                ),
              );
            }

            return Container(); // unreachable
          },
        );
      },
    );
  }
}

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// TODO: 5-Update App Fonts
/// Google fonts constant setting: https://fonts.google.com/
TextTheme kTextTheme(theme, [language = 'en']) {
  switch (language) {
    case 'vi':
      return GoogleFonts.tajawalTextTheme(theme);
    case 'ar':
      return GoogleFonts.tajawalTextTheme(theme);
    default:
      return GoogleFonts.tajawalTextTheme(theme);
  }
}

TextTheme kHeadlineTheme(theme, [language = 'en']) {
  switch (language) {
    case 'vi':
      return GoogleFonts.tajawalTextTheme(theme);
    case 'ar':
      return GoogleFonts.tajawalTextTheme(theme);
    default:
      return GoogleFonts.tajawalTextTheme(theme);
  }
}

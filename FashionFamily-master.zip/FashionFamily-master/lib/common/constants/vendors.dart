/// Default Vendor image
const kDefaultStoreImage = "assets/images/default-store-banner.png";

/// Default status when Add New Product from app
const kNewProductStatus = 'draft'; // support 'draft', 'pending', 'public'

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'dart:math' as math;
import '../../generated/l10n.dart';
import 'package:sizer/sizer.dart';

/// For Loading Widget
Widget kLoadingWidget(context) => Center(
      child: AMAnimatedBuilderScreen(),
      // child: SpinKitFadingCube(
      //   color: Theme.of(context).primaryColor,
      //   size: 30.0,
      // ),
    );

Widget kCustomFooter(context) => CustomFooter(
      builder: (BuildContext context, LoadStatus mode) {
        Widget body;
        if (mode == LoadStatus.idle) {
          body = Text(S.of(context).pullToLoadMore);
        } else if (mode == LoadStatus.loading) {
          body = kLoadingWidget(context);
        } else if (mode == LoadStatus.failed) {
          body = Text(S.of(context).loadFail);
        } else if (mode == LoadStatus.canLoading) {
          body = Text(S.of(context).releaseToLoadMore);
        } else {
          body = Text(S.of(context).noData);
        }
        return Container(
          height: 55.0,
          child: Center(child: body),
        );
      },
    );

class AMAnimatedBuilderScreen extends StatefulWidget {
  static String tag = '/AMAnimatedBuilderScreen';

  @override
  AMAnimatedBuilderScreenState createState() => AMAnimatedBuilderScreenState();
}

class AMAnimatedBuilderScreenState extends State<AMAnimatedBuilderScreen>
    with TickerProviderStateMixin {
  AnimationController _controller;
  Animation _FavouriteAnimation;
  AnimationController _arrowAnimationController, _favouriteAnimationController;

  @override
  void initState() {
    super.initState();
    init();
  }

  init() async {
    _controller = AnimationController(
      duration: const Duration(seconds: 10),
      vsync: this,
    )..repeat();

    _favouriteAnimationController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 100))
          ..repeat();
    _FavouriteAnimation = Tween(begin: 80.0, end: 100.0).animate(
        CurvedAnimation(
            curve: Curves.bounceOut, parent: _favouriteAnimationController));

    _favouriteAnimationController.addStatusListener((AnimationStatus status) {
      if (status == AnimationStatus.completed) {
        _favouriteAnimationController.repeat();
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _arrowAnimationController?.dispose();
    _favouriteAnimationController?.dispose();
    super.dispose();
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: 100.0.w,
        height: 25.0.h,
         color: Colors.white,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SpinKitCircle(
              color: Color(0xff4f3933),
              size: 25.0,
            )
            //   AnimatedBuilder(
            //     animation: _controller,
            //     child: Container(
            //         // height: 80,
            //         // width: 80,
            //         child: Center(
            //             child: Container(
            //                 width: 50,
            //                 height: 10,
            //                 child: Image.asset(
            //                   "assets/icons/cacoLogo.png",
            //                   fit: BoxFit.fill,
            //                 )))),
            //     builder: (BuildContext context, Widget child) {
            //       return Transform.rotate(
            //         angle: _controller.value * 2.0 * math.pi,
            //         child: child,
            //       );
            //     },
            //   ),
            // ),

            // AnimatedBuilder(
            //   animation: _controller,
            //   child: Container(
            //     decoration: BoxDecoration(borderRadius: BorderRadius.only(topLeft: Radius.circular(16), topRight: Radius.circular(16))),
            //     width: 100,
            //     height: 100,
            //     child: Center(child: ()),
            //   ),
            //   builder: (BuildContext context, Widget child) {
            //     return Transform.rotate(
            //       angle: _controller.value - math.pi / 12.0,
            //       child: child,
            //     );
            //   },
            // )
          ],
        ),
      ),
    );
  }

  BoxDecoration boxDecoration(
      {double radius = 2,
      Color color = Colors.transparent,
      Color bgColor = Colors.white,
      var showShadow = false}) {
    return BoxDecoration(
      color: bgColor,
      boxShadow: showShadow
          ? [BoxShadow(color: Colors.green, blurRadius: 5, spreadRadius: 1)]
          : [BoxShadow(color: Colors.transparent)],
      border: Border.all(color: color),
      borderRadius: BorderRadius.all(Radius.circular(radius)),
    );
  }
}

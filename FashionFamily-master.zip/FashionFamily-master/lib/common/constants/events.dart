class EventOpenNativeDrawer {
  const EventOpenNativeDrawer();
}

class EventCloseNativeDrawer {
  const EventCloseNativeDrawer();
}

class EventOpenCustomDrawer {
  const EventOpenCustomDrawer();
}

class EventCloseCustomDrawer {
  const EventCloseCustomDrawer();
}

class EventSwitchStateCustomDrawer {
  const EventSwitchStateCustomDrawer();
}

class EventChangeLanguage {
  const EventChangeLanguage();
}

const kFluxStorePlatform = <String>[
  "woo",
  "strapi",
  "shopify",
  "presta",
  "opencart",
  "magento",
];

const kFluxStoreMV = <String>["dokan", "wcfm"];

enum VendorType { single, multi }

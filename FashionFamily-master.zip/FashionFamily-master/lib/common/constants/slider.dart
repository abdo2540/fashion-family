/// Filter value
const kSliderActiveColor = 0xFFffffff;
const kSliderInactiveColor = 0x99ffffff;
const kMaxPriceFilter = 1000.0;
const kFilterDivision = 10;

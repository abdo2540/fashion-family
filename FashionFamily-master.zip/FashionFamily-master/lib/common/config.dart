export 'config/index.dart';

// const serverConfig = {
//   "type": "woo",
//   "url": "https://mstore.io",
//   "consumerKey": "ck_c16d601d14a44c8080418c1ab9336b72ae8faff2",
//   "consumerSecret": "cs_1c11c4d0ee3bef861421bf3622f20f6b49c8497a",
//   "blog":
//       "https://mstore.io", // Your website woocommerce -remove this line if have the same url
//   "forgetPassword": "http://demo.mstore.io/wp-login.php?action=lostpassword"
// };

// const serverConfig = {
//   "type": "woo",
//   "url": "https://dokkan.store/cacao",
//   "consumerKey": "ck_48c3b5cb9baf2ba92bf90734c5a887f609ff6f7e",
//   "consumerSecret": "cs_34d8a855d2ca3a34be4882fa5f7c028e9c80a539",
//   "blog":
//       "https://dokkan.store/cacao", // Your website woocommerce -remove this line if have the same url
//   "forgetPassword": "http://dokkan.store/cacao/wp-login.php?action=lostpassword"
// };

const serverConfig = {


  "type": "woo",
  "url": "https://fashion-family.net/",
  "consumerKey": "ck_aabb897a1f96dad69a13672364d1999052ea42cf",
  "consumerSecret": "cs_40dc168733893ff75dc0807ef98e5f78c9e786a2",
  "blog": "https://fashion-family.net/",
  "forgetPassword": "https://fashion-family.net/wp-login.php?action=lostpassword",

  // "type": "woo",
  // "url": "https://altorky.store",
  // "consumerKey": "ck_30ec6f14d28fad37741924854087ce0b1af6c948",
  // "consumerSecret": "cs_0c2870ba631e3c87c98ff0b599c34a093d649625",
  // "blog": "https://altorky.store",
  // "forgetPassword":
  // "https://www.altorky.store/wp-login.php?action=lostpassword"
  //   "type": "woo",
  // "url": "https://www.walljeans.com",
  // "consumerKey": "ck_2fbbca2ffd7ddbcf09e267c774c750ebf5fc4de9",
  // "consumerSecret": "cs_b56179b7ece081bdb6b7b3e21edc6f706cb6f5ca",
  // "blog": "https://www.walljeans.com",
  // "forgetPassword": "https://www.walljeans.com/NW21/wp-login.php?action=lostpassword"



  // "type": "woo",
  // "url": "https://arabia-cafe.com",
  // "consumerKey": "ck_d0f5a373480b7b1c3865279306559d40edbbb2c5",
  // "consumerSecret": "cs_a0855c92114be0325f8bd1463b49c9ac4dae1c1a",
  // "blog": "https://arabia-cafe.com/",
  // "forgetPassword": "https://arabia-cafe.com/wp-login.php?action=lostpassword"



  //
  // "type": "woo",
  // "url": "https://cacaoegypt.com",
  // "consumerKey": "ck_c3ec0ed5365757faf8132b130849a83e61a55278",
  // "consumerSecret": "cs_8a5749438394a15cc3e6d13499c6b016e4856afc",
  // "blog":
  //     "https://cacaoegypt.com/",
  // "forgetPassword": "https://cacaoegypt.com/wp-login.php?action=lostpassword"
};

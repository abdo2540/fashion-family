//
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// class AddOnQuantay{
//
//   static void quantaiSelection(
//
//       ){
//
//     int currentQuantity =0;
//     StatefulBuilder(
//         builder: (context, StateSetter setState) {
//           return Container(
//             width:100,
//             height:50,
//             child: Row(
//               mainAxisAlignment:
//               MainAxisAlignment.spaceBetween,
//               crossAxisAlignment:
//               CrossAxisAlignment.center,
//               children: [
//                 InkWell(
//                     onTap: () {
//                       if(currentQuantity>0) {
//                         setState((){ currentQuantity--;});
//
//                       }
//                     },
//                     child: const Center(
//                       child: Icon(
//                         Icons.remove_circle_outline,
//                         size: 20,
//                         color: Color(0xff4f3933),
//                       ),
//                     )),
//                 Text(
//                   '$currentQuantity',
//                   style: const TextStyle(
//                     fontSize: 18,
//                   ),
//                 ),
//                 InkWell(
//                   onTap: () {
//                     setState((){ currentQuantity++;});
//                     selected[item.name] = AddonsOption(
//                       parent: item.name,
//                       label: "text",
//                       price:(double.parse(item.price)*currentQuantity).toString() ,
//                     );
//                     onSelectProductAddons(
//                         selectedOptions: selectedOptions);
//                   }
//                   ,
//
//                   child: const Center(
//                     child: Icon(
//                       Icons.add_circle_outline_sharp,
//                       color: Color(0xff4f3933),
//                       size: 20,
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           );
//         });
//   }
//
// }
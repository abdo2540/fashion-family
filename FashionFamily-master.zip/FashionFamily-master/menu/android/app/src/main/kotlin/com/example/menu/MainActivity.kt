package com.example.menu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

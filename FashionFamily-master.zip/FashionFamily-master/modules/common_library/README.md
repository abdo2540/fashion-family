# inspireui

Common library inhouse inspireui company

# Development
Current Status:
[![coverage report](https://gitlab.com/inspireui/common_library/badges/develop/coverage.svg)](https://gitlab.com/inspireui/common_library/-/commits/develop)


## Run Unit test coverage

```
    https://brewinstall.org/Install-lcov-on-Mac-with-Brew/
```
